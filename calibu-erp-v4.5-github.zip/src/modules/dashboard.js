import { supabase } from '../lib/supabase.js';
import { formatearCLP, mesActualISO, escapeHTML, formatearFecha } from '../lib/calc.js';

const PALETA = { primario: '#D42B00', acento: '#FFC233', info: '#1E5FB6', ok: '#1F8A4C', warn: '#C97A00' };
const NOMBRE_MES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const mesLabel = s => { const [y,m] = s.split('-'); return NOMBRE_MES[parseInt(m,10)-1] + ' ' + y.slice(2); };
function hoyLocal() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

export async function render(root, { perfil }) {
  if (perfil.rol === 'admin') return renderAdmin(root);
  return renderTrabajador(root, perfil);
}

async function renderAdmin(root) {
  root.innerHTML = `
    <div class="dash-hero">
      <div><h1>Calibú · Vista ejecutiva</h1><div class="sub">Estado del negocio en tiempo real</div></div>
    </div>
    <div class="kpi-grid-rich" id="kpis"></div>
    <div class="dash-row">
      <div class="chart-card"><h3>Ventas mensuales por canal</h3><div class="chart-sub">Últimos 12 meses</div><div class="chart-wrap"><canvas id="ch-ventas"></canvas></div></div>
      <div class="list-card"><h3>Top clientes</h3><div id="top-clientes">Cargando...</div></div>
    </div>
    <div class="dash-row equal">
      <div class="chart-card"><h3>Producción diaria — últimos 30 días</h3><div class="chart-sub">Huevos enteros por galpón</div><div class="chart-wrap sm"><canvas id="ch-produccion"></canvas></div></div>
      <div class="chart-card"><h3>Distribución del mes por canal</h3><div class="chart-sub">Mes actual</div><div class="chart-wrap sm"><canvas id="ch-donut"></canvas></div></div>
    </div>
    <div class="dash-row equal">
      <div class="list-card"><h3>Próximas entregas (7 días)</h3><div id="entregas">Cargando...</div></div>
      <div class="list-card"><h3>Alertas</h3><div id="alertas">Cargando...</div></div>
    </div>
    <div class="card"><h3 class="card-title">Estado de lotes en producción</h3><div class="lotes-grid" id="lotes">Cargando...</div></div>`;

  const mesActual = mesActualISO();
  const hoy = hoyLocal();
  const en7 = (() => { const d = new Date(); d.setDate(d.getDate()+7); return d.toISOString().slice(0,10); })();
  const hace30 = (() => { const d = new Date(); d.setDate(d.getDate()-30); return d.toISOString().slice(0,10); })();

  try {
    const [
      ventasMensRes, empleadosRes, ventasMesRes, prodHoyRes, prodUltDiaRes, huevosMesRes,
      suscripActRes, entregasSemRes, stockRes, lotesRes, prodDiariaRes, topClientesRes, ventasCanalMesRes,
      porCobrarRes, porPagarRes, comprasMesRes, prodMesRes
    ] = await Promise.all([
      supabase.from('v_resumen_mensual_ventas').select('*').order('anio_mes'),
      supabase.from('empleados').select('id', { count: 'exact', head: true }).eq('estado', 'activo'),
      supabase.from('ventas').select('total').gte('fecha', mesActual + '-01').lte('fecha', mesActual + '-31').neq('estado_pago', 'anulado'),
      supabase.from('produccion_diaria').select('huevos_enteros, huevos_rotos').eq('fecha', hoy),
      supabase.from('produccion_diaria').select('fecha, huevos_enteros, huevos_rotos').order('fecha', { ascending: false }).limit(3),
      supabase.from('produccion_diaria').select('huevos_enteros').gte('fecha', mesActual + '-01'),
      supabase.from('suscripciones').select('id, valor_mensual').eq('estado', 'activa'),
      supabase.from('entregas').select('id').gte('fecha_planificada', hoy).lte('fecha_planificada', en7).eq('estado','planificada'),
      supabase.from('v_stock_alertas').select('*'),
      supabase.from('lotes').select('*, galpones:galpon_id(nombre)').in('estado',['activo_produccion','activo_pre_pico','activo_prueba']),
      supabase.from('v_produccion_galpon').select('*').gte('fecha', hace30).order('fecha'),
      supabase.from('v_top_clientes').select('*').order('total_comprado',{ascending:false}).limit(7),
      supabase.from('ventas').select('canal, total').gte('fecha', mesActual + '-01').lte('fecha', mesActual + '-31').neq('estado_pago','anulado'),
      // KPIs nuevos:
      supabase.from('ventas').select('total').in('estado_pago', ['pendiente','vencido']),
      supabase.from('compras').select('total_con_iva').in('estado_pago', ['pendiente','vencido']),
      supabase.from('compras').select('total_neto').gte('fecha', mesActual + '-01').lte('fecha', mesActual + '-31'),
      supabase.from('produccion_diaria').select('huevos_enteros, fecha').gte('fecha', mesActual + '-01')
    ]);

    const ventasMes = (ventasMesRes.data || []).reduce((a,r) => a + (r.total||0), 0);
    const numTrans = (ventasMesRes.data || []).length;
    const ticketProm = numTrans > 0 ? ventasMes / numTrans : 0;

    let huevosHoy = (prodHoyRes.data || []).reduce((a,r) => a + (r.huevos_enteros||0), 0);
    let rotosHoy = (prodHoyRes.data || []).reduce((a,r) => a + (r.huevos_rotos||0), 0);
    let labelHoy = 'hoy';
    if (huevosHoy === 0 && prodUltDiaRes.data?.length) {
      const ultFecha = prodUltDiaRes.data[0].fecha;
      const datosUlt = prodUltDiaRes.data.filter(r => r.fecha === ultFecha);
      huevosHoy = datosUlt.reduce((a,r) => a + (r.huevos_enteros||0), 0);
      rotosHoy = datosUlt.reduce((a,r) => a + (r.huevos_rotos||0), 0);
      labelHoy = formatearFecha(ultFecha);
    }
    const huevosMes = (huevosMesRes.data || []).reduce((a,r) => a + (r.huevos_enteros||0), 0);
    const suscripActivas = (suscripActRes.data || []).length;
    const valorSuscrip = (suscripActRes.data || []).reduce((a,r) => a + (r.valor_mensual||0), 0);
    const entregasSem = (entregasSemRes.data || []).length;
    const empleados = empleadosRes.count ?? 0;

    const sumMes = (m) => (ventasMensRes.data || []).filter(r => r.anio_mes === m).reduce((a,r) => a + Number(r.total||0), 0);
    const dt = new Date(mesActual + '-01'); dt.setMonth(dt.getMonth() - 1);
    const mesAnt = dt.toISOString().slice(0,7);
    const deltaPct = sumMes(mesAnt) > 0 ? ((sumMes(mesActual) - sumMes(mesAnt))/sumMes(mesAnt)*100) : 0;

    // KPIs nuevos
    const porCobrar = (porCobrarRes.data || []).reduce((a,r) => a + (r.total||0), 0);
    const porPagar = (porPagarRes.data || []).reduce((a,r) => a + (r.total_con_iva||0), 0);
    const comprasMes = (comprasMesRes.data || []).reduce((a,r) => a + (r.total_neto||0), 0);
    const margenMes = ventasMes - comprasMes;
    const margenPct = ventasMes > 0 ? (margenMes/ventasMes)*100 : 0;
    // Producción promedio diaria del mes
    const diasUnicos = new Set((prodMesRes.data || []).map(r => r.fecha)).size || 1;
    const huevosPromedio = Math.round(huevosMes / diasUnicos);

    document.getElementById('kpis').innerHTML =
      // Fila 1
      kpi('💰','Ventas del mes', formatearCLP(ventasMes), numTrans + ' ventas · ticket ' + formatearCLP(ticketProm), 'bg-red', deltaPct) +
      kpi('🥚','Huevos ' + labelHoy, huevosHoy.toLocaleString('es-CL'), rotosHoy + ' rotos · ' + huevosMes.toLocaleString('es-CL') + ' en mes', 'bg-yellow') +
      kpi('🔁','Suscripciones activas', suscripActivas, formatearCLP(valorSuscrip) + ' / mes recurrente', 'bg-blue') +
      kpi('📦','Entregas próximas', entregasSem, 'En los próximos 7 días', 'bg-purple') +
      kpi('👥','Equipo activo', empleados, 'Trabajadores en planilla', 'bg-green') +
      // Fila 2 (4 nuevos + 1 alertas movido)
      kpi('💸','Por cobrar', formatearCLP(porCobrar), 'Ventas pendientes/vencidas', 'bg-pink') +
      kpi('🧾','Por pagar', formatearCLP(porPagar), 'Compras pendientes', 'bg-yellow') +
      kpi('📈','Margen del mes', formatearCLP(margenMes), margenPct.toFixed(1) + '% · costos ' + formatearCLP(comprasMes), margenMes >= 0 ? 'bg-green' : 'bg-pink') +
      kpi('📊','Producción promedio', huevosPromedio.toLocaleString('es-CL'), 'Huevos/día este mes (' + diasUnicos + ' días)', 'bg-blue') +
      kpi('⚠️','Insumos críticos', countSemaforo(stockRes.data,'rojo'), countSemaforo(stockRes.data,'amarillo') + ' en amarillo', 'bg-red');

    document.getElementById('top-clientes').innerHTML = renderTopClientes(topClientesRes.data || []);
    await renderEntregas('entregas', hoy, en7);
    document.getElementById('alertas').innerHTML = renderAlertas(stockRes.data || [], entregasSem, deltaPct);
    document.getElementById('lotes').innerHTML = renderLotes(lotesRes.data || []);

    setTimeout(() => {
      chartVentasMens(ventasMensRes.data || []);
      chartProduccion(prodDiariaRes.data || []);
      chartDonut(ventasCanalMesRes.data || []);
    }, 50);
  } catch (e) {
    console.error('Dashboard error:', e);
    document.getElementById('kpis').innerHTML = '<div class="kpi-card"><div class="kpi-icon bg-red">⚠️</div><div class="kpi-label">Error</div><div class="kpi-value" style="font-size:14px">' + escapeHTML(e.message || String(e)) + '</div></div>';
  }
}

function kpi(icon, label, value, sub, color, deltaPct) {
  let delta = '';
  if (deltaPct != null && isFinite(deltaPct) && Math.abs(deltaPct) > 0.1) {
    delta = '<div class="kpi-delta ' + (deltaPct >= 0 ? 'up' : 'down') + '">' + (deltaPct >= 0 ? '▲' : '▼') + ' ' + Math.abs(deltaPct).toFixed(1) + '% vs mes anterior</div>';
  }
  return '<div class="kpi-card"><div class="kpi-icon ' + color + '">' + icon + '</div><div class="kpi-label">' + label + '</div><div class="kpi-value">' + value + '</div><div class="kpi-sub">' + sub + '</div>' + delta + '</div>';
}
function countSemaforo(data, sem) { return data ? data.filter(r => r.semaforo === sem).length : 0; }

function renderTopClientes(clientes) {
  if (!clientes.length) return '<div class="empty-state" style="padding:24px"><small>Sin ventas</small></div>';
  return clientes.map(c => {
    const ini = (c.nombre || '?').split(/\s+/).map(w => w[0]).slice(0,2).join('').toUpperCase();
    const canal = c.canal_principal || 'directa';
    return '<div class="list-item"><div class="item-main"><div class="item-avatar canal-' + canal + '">' + escapeHTML(ini) + '</div><div><div class="item-name">' + escapeHTML(c.nombre) + '</div><div class="item-meta">' + escapeHTML(canal) + ' · ' + (c.n_compras || 0) + ' compras</div></div></div><div class="item-value">' + formatearCLP(c.total_comprado || 0) + '</div></div>';
  }).join('');
}

async function renderEntregas(targetId, desde, hasta) {
  const { data } = await supabase.from('entregas')
    .select('fecha_planificada, n_bandejas, tamano_huevo, monto, suscripciones:suscripcion_id(clientes:cliente_id(nombre, canal_principal))')
    .gte('fecha_planificada', desde).lte('fecha_planificada', hasta).eq('estado', 'planificada')
    .order('fecha_planificada').limit(8);
  const el = document.getElementById(targetId);
  if (!el) return;
  if (!data || !data.length) { el.innerHTML = '<div class="empty-state" style="padding:24px"><small>Sin entregas próximas</small></div>'; return; }
  el.innerHTML = data.map(e => {
    const nombre = e.suscripciones?.clientes?.nombre || 'Cliente';
    const canal = e.suscripciones?.clientes?.canal_principal || 'suscripcion';
    const ini = nombre.split(/\s+/).map(w => w[0]).slice(0,2).join('').toUpperCase();
    return '<div class="list-item"><div class="item-main"><div class="item-avatar canal-' + canal + '">' + escapeHTML(ini) + '</div><div><div class="item-name">' + escapeHTML(nombre) + '</div><div class="item-meta">' + formatearFecha(e.fecha_planificada) + ' · ' + e.n_bandejas + '×' + (e.tamano_huevo || '') + '</div></div></div><div class="item-value">' + formatearCLP(e.monto || 0) + '</div></div>';
  }).join('');
}

function renderAlertas(stockData, entregasSem, deltaPct) {
  const rojos = stockData.filter(r => r.semaforo === 'rojo');
  const amar = stockData.filter(r => r.semaforo === 'amarillo');
  const items = [];
  rojos.forEach(r => items.push({tipo:'danger', icon:'🚨', titulo:'Stock crítico: ' + r.nombre, detalle:'Solo ' + Number(r.stock_actual).toFixed(0) + ' ' + r.unidad}));
  amar.forEach(r => items.push({tipo:'warn', icon:'⚠️', titulo:'Reponer: ' + r.nombre, detalle:'Stock ' + Number(r.stock_actual).toFixed(0) + ' ' + r.unidad + ' · ~' + r.dias_stock + ' días'}));
  if (entregasSem > 5) items.push({tipo:'info', icon:'📅', titulo:'Semana movida: ' + entregasSem + ' entregas', detalle:'Revisa el calendario'});
  if (deltaPct < -10) items.push({tipo:'warn', icon:'📉', titulo:'Ventas bajaron ' + Math.abs(deltaPct).toFixed(1) + '%', detalle:'vs mes anterior'});
  if (!items.length) return '<div class="empty-state" style="padding:24px"><div style="font-size:32px">✅</div><small>Sin alertas — todo en orden</small></div>';
  return items.map(a => '<div class="alert-card ' + a.tipo + '"><div class="alert-icon">' + a.icon + '</div><div class="alert-text"><strong>' + escapeHTML(a.titulo) + '</strong>' + escapeHTML(a.detalle) + '</div></div>').join('');
}

function renderLotes(lotes) {
  if (!lotes.length) return '<div class="empty-state"><small>Sin lotes activos</small></div>';
  return lotes.map(l => {
    const pct = Math.round((l.postura_esperada_pct || 0) * 100);
    return '<div class="lote-card"><div class="lote-head"><span class="lote-codigo">' + escapeHTML(l.codigo) + '</span><div class="lote-raza">' + escapeHTML(l.galpones?.nombre || '') + '</div></div><div class="lote-raza">' + escapeHTML(l.raza) + '</div><div class="lote-stats"><div class="lote-stat"><div class="lote-stat-label">Gallinas</div><div class="lote-stat-value">' + (l.gallinas_actuales || 0).toLocaleString('es-CL') + '</div></div><div class="lote-stat"><div class="lote-stat-label">% postura</div><div class="lote-stat-value">' + pct + '%</div></div></div><div class="lote-progress"><div style="width:' + pct + '%"></div></div></div>';
  }).join('');
}

let _chV, _chP, _chD;
function chartVentasMens(rows) {
  const c = document.getElementById('ch-ventas');
  if (!c || !window.Chart) return;
  if (_chV) _chV.destroy();
  const meses = [...new Set(rows.map(r => r.anio_mes))].sort();
  const canales = ['mayorista','suscripcion','directa'];
  const cols = { mayorista: PALETA.primario, suscripcion: PALETA.info, directa: PALETA.ok };
  const datasets = canales.map(canal => ({
    label: canal[0].toUpperCase() + canal.slice(1),
    data: meses.map(m => { const r = rows.find(x => x.anio_mes === m && x.canal === canal); return Math.round(Number(r?.total || 0)); }),
    backgroundColor: cols[canal], borderRadius: 6
  }));
  _chV = new Chart(c, { type: 'bar', data: { labels: meses.map(mesLabel), datasets },
    options: { responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } },
        tooltip: { callbacks: { label: c => c.dataset.label + ': ' + formatearCLP(c.parsed.y) } } },
      scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, ticks: { callback: v => '$' + (v/1000).toFixed(0) + 'k' }, grid: { color: '#F0EDE6' } } } } });
}
function chartProduccion(rows) {
  const c = document.getElementById('ch-produccion');
  if (!c || !window.Chart) return;
  if (_chP) _chP.destroy();
  const fechas = [...new Set(rows.map(r => r.fecha))].sort();
  const galpones = [...new Set(rows.map(r => r.galpon))].sort();
  const cols = [PALETA.primario, PALETA.info, PALETA.acento];
  const datasets = galpones.map((g, i) => ({
    label: g, data: fechas.map(f => { const r = rows.find(x => x.fecha === f && x.galpon === g); return r?.huevos_enteros || 0; }),
    borderColor: cols[i % cols.length], backgroundColor: cols[i % cols.length] + '22',
    fill: true, tension: 0.35, pointRadius: 0, pointHoverRadius: 4, borderWidth: 2
  }));
  _chP = new Chart(c, { type: 'line',
    data: { labels: fechas.map(f => { const d = new Date(f); return d.getDate() + '/' + (d.getMonth()+1); }), datasets },
    options: { responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } },
      scales: { x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 10 } }, y: { beginAtZero: true, grid: { color: '#F0EDE6' } } } } });
}
function chartDonut(rows) {
  const c = document.getElementById('ch-donut');
  if (!c || !window.Chart) return;
  if (_chD) _chD.destroy();
  const acum = {};
  rows.forEach(r => { acum[r.canal] = (acum[r.canal] || 0) + Number(r.total || 0); });
  const labels = Object.keys(acum);
  const data = Object.values(acum);
  if (!data.length) { c.parentElement.innerHTML = '<div class="empty-state" style="padding:40px 0"><small>Sin ventas este mes</small></div>'; return; }
  _chD = new Chart(c, { type: 'doughnut',
    data: { labels: labels.map(l => l[0].toUpperCase() + l.slice(1)),
      datasets: [{ data, backgroundColor: [PALETA.primario, PALETA.info, PALETA.ok, PALETA.acento], borderWidth: 2, borderColor: '#fff' }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: '60%',
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } },
        tooltip: { callbacks: { label: c => c.label + ': ' + formatearCLP(c.parsed) } } } } });
}

async function renderTrabajador(root, perfil) {
  root.innerHTML = `
    <div class="dash-hero">
      <div><h1>Hola, ${perfil.nombre_display.split(/\s+/)[0]}</h1><div class="sub">Tu día de trabajo</div></div>
    </div>
    <div class="kpi-grid-rich">
      <a class="kpi-card" href="#checklist" style="text-decoration:none; color:inherit"><div class="kpi-icon bg-red">✅</div><div class="kpi-label">Checklist del día</div><div class="kpi-value" style="font-size:18px">Tareas diarias</div></a>
      <a class="kpi-card" href="#asistencia" style="text-decoration:none; color:inherit"><div class="kpi-icon bg-yellow">⏰</div><div class="kpi-label">Asistencia</div><div class="kpi-value" style="font-size:18px">Entrada / salida</div></a>
      <a class="kpi-card" href="#cargar-produccion" style="text-decoration:none; color:inherit"><div class="kpi-icon bg-blue">🥚</div><div class="kpi-label">Producción</div><div class="kpi-value" style="font-size:18px">Cargar postura</div></a>
      <a class="kpi-card" href="#mis-vacaciones" style="text-decoration:none; color:inherit"><div class="kpi-icon bg-purple">🏖️</div><div class="kpi-label">Vacaciones</div><div class="kpi-value" style="font-size:18px">Solicitar</div></a>
      <a class="kpi-card" href="#mis-anticipos" style="text-decoration:none; color:inherit"><div class="kpi-icon bg-green">💵</div><div class="kpi-label">Anticipos</div><div class="kpi-value" style="font-size:18px">Solicitar</div></a>
      <a class="kpi-card" href="#mis-liquidaciones" style="text-decoration:none; color:inherit"><div class="kpi-icon bg-pink">📋</div><div class="kpi-label">Liquidaciones</div><div class="kpi-value" style="font-size:18px">Mis pagos</div></a>
    </div>`;
}
