// =====================================================================
// Calibú ERP — Costos y Márgenes
// Bug fixes: import sb→supabase, huevos_totales→huevos_enteros,
//            CSS clases del sistema, root-scoped queries
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, mesActualISO } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

const NOMBRE_MES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const fmt = n => formatearCLP(Math.round(Number(n) || 0));
const pctFmt = x => (isFinite(x) && x !== null) ? (x * 100).toFixed(1) + '%' : '—';

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div>
        <h1>💰 Costos y Márgenes</h1>
        <small>Costo por huevo, margen por canal y desglose por categoría</small>
      </div>
      <div style="display:flex; align-items:center; gap:8px">
        <label style="font-size:12px; color:var(--text-muted)">Rango:</label>
        <select id="rango" style="padding:8px 10px; border:1px solid var(--border-fuerte); border-radius:8px">
          <option value="30">Últimos 30 días</option>
          <option value="90" selected>Últimos 90 días</option>
          <option value="180">Últimos 180 días</option>
          <option value="365">Último año</option>
          <option value="all">Todo el historial</option>
        </select>
      </div>
    </div>

    <div class="kpi-grid-rich" id="kpis-costos"></div>

    <div class="dash-row equal" style="margin-top:16px">
      <div class="chart-card">
        <h3>Costo por huevo (mensual)</h3>
        <div class="chart-sub" id="costo-msg"></div>
        <div class="chart-wrap"><canvas id="ch-costo-huevo"></canvas></div>
      </div>
      <div class="chart-card">
        <h3>Margen por canal</h3>
        <div class="chart-wrap"><canvas id="ch-margen-canal"></canvas></div>
      </div>
    </div>

    <div class="dash-row equal" style="margin-top:16px">
      <div class="card">
        <h3 class="card-title">Gasto por categoría</h3>
        <div id="tabla-categorias"></div>
      </div>
      <div class="chart-card">
        <h3>Ingresos vs Costos (mensual)</h3>
        <div class="chart-wrap"><canvas id="ch-mensual"></canvas></div>
      </div>
    </div>
  `;

  root.querySelector('#rango').addEventListener('change', () => cargar(root));
  await cargar(root);
}

async function cargar(root) {
  const rango = root.querySelector('#rango').value;
  const desde = rango === 'all'
    ? '2020-01-01'
    : (() => { const d = new Date(); d.setDate(d.getDate() - Number(rango)); return d.toISOString().slice(0, 10); })();

  const [vRes, cRes, pRes] = await Promise.all([
    supabase.from('ventas').select('fecha,canal,total,n_huevos').gte('fecha', desde).neq('estado_pago', 'anulado'),
    supabase.from('compras').select('fecha,categoria,total_con_iva,total_neto').gte('fecha', desde),
    supabase.from('produccion_diaria').select('fecha,huevos_enteros').gte('fecha', desde)
  ]);

  if (vRes.error) { toast('Error ventas: ' + vRes.error.message, 'danger'); return; }

  const ventas  = vRes.data  || [];
  const compras = cRes.data  || [];
  const prod    = pRes.data  || [];

  const totalVentas  = ventas.reduce((s, v)  => s + Number(v.total || 0), 0);
  const totalCompras = compras.reduce((s, c) => s + Number(c.total_con_iva || 0), 0);
  const margenBruto  = totalVentas - totalCompras;
  const margenPct    = totalVentas ? margenBruto / totalVentas : 0;

  // Huevos: primero producción, fallback a huevos vendidos
  const huevosProd  = prod.reduce((s, p) => s + Number(p.huevos_enteros || 0), 0);
  const huevosVend  = ventas.reduce((s, v) => s + Number(v.n_huevos || 0), 0);
  const huevosBase  = huevosProd || huevosVend || 1;

  const costoPorHuevo  = totalCompras / huevosBase;
  const precioPromedio = totalVentas / (huevosVend || 1);
  const margenUnit     = precioPromedio - costoPorHuevo;

  // ── KPIs ─────────────────────────────────────────────────────────
  root.querySelector('#kpis-costos').innerHTML = [
    ['💰', 'Ventas', fmt(totalVentas), 'bg-green'],
    ['🧾', 'Costos totales', fmt(totalCompras), 'bg-yellow'],
    ['📈', 'Margen bruto', fmt(margenBruto) + ' · ' + pctFmt(margenPct), margenBruto >= 0 ? 'bg-blue' : 'bg-pink'],
    ['🥚', 'Costo / huevo', '$' + Math.round(costoPorHuevo).toLocaleString('es-CL'), 'bg-red'],
    ['✨', 'Precio prom. / huevo', '$' + Math.round(precioPromedio).toLocaleString('es-CL'), 'bg-purple'],
    ['💎', 'Margen / huevo', '$' + Math.round(margenUnit).toLocaleString('es-CL'), margenUnit >= 0 ? 'bg-green' : 'bg-pink']
  ].map(([icon, label, value, color]) =>
    `<div class="kpi-card">
       <div class="kpi-icon ${color}">${icon}</div>
       <div class="kpi-label">${label}</div>
       <div class="kpi-value">${value}</div>
     </div>`
  ).join('');

  root.querySelector('#costo-msg').textContent =
    `Base: ${huevosProd ? huevosProd.toLocaleString('es-CL') + ' huevos producidos' : huevosVend.toLocaleString('es-CL') + ' huevos vendidos'} · Costos: ${fmt(totalCompras)}`;

  // ── Datos por mes ──────────────────────────────────────────────
  const porMes = {};
  const addMes = m => { if (!porMes[m]) porMes[m] = { compras: 0, prod: 0, ventas: 0, huevos: 0 }; };

  compras.forEach(c => { const m = c.fecha.slice(0, 7); addMes(m); porMes[m].compras += Number(c.total_con_iva || 0); });
  prod.forEach(p    => { const m = p.fecha.slice(0, 7); addMes(m); porMes[m].prod    += Number(p.huevos_enteros || 0); });
  ventas.forEach(v  => {
    const m = v.fecha.slice(0, 7); addMes(m);
    porMes[m].ventas += Number(v.total   || 0);
    porMes[m].huevos += Number(v.n_huevos || 0);
  });

  const labels = Object.keys(porMes).sort();
  const labelsFmt = labels.map(m => {
    const [y, mo] = m.split('-');
    return NOMBRE_MES[parseInt(mo, 10) - 1] + ' ' + y.slice(2);
  });

  // Destruir charts previos si existen (evitar doble canvas)
  ['ch-costo-huevo', 'ch-margen-canal', 'ch-mensual'].forEach(id => {
    const canvas = root.querySelector('#' + id);
    if (canvas && canvas._chart) { canvas._chart.destroy(); canvas._chart = null; }
  });

  if (!window.Chart) return;

  // Chart 1: Costo por huevo mensual
  const costoData = labels.map(m => {
    const r = porMes[m];
    const base = r.prod || r.huevos || 1;
    return Math.round(r.compras / base);
  });
  const ctx1 = root.querySelector('#ch-costo-huevo');
  if (ctx1) {
    ctx1._chart = new Chart(ctx1, {
      type: 'line',
      data: {
        labels: labelsFmt,
        datasets: [{
          label: '$ / huevo',
          data: costoData,
          borderColor: '#D42B00',
          backgroundColor: 'rgba(212,43,0,.12)',
          tension: 0.3,
          fill: true,
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => '$' + c.parsed.y } } },
        scales: { y: { beginAtZero: true, ticks: { callback: v => '$' + v } } }
      }
    });
  }

  // Chart 2: Margen por canal
  const canales = {};
  ventas.forEach(v => {
    if (!canales[v.canal]) canales[v.canal] = { total: 0, huevos: 0 };
    canales[v.canal].total  += Number(v.total    || 0);
    canales[v.canal].huevos += Number(v.n_huevos || 0);
  });
  const cLabels   = Object.keys(canales);
  const ingresos  = cLabels.map(k => canales[k].total);
  const costoCan  = cLabels.map(k => Math.round(canales[k].huevos * costoPorHuevo));
  const margenes  = ingresos.map((v, i) => v - costoCan[i]);
  const ctx2 = root.querySelector('#ch-margen-canal');
  if (ctx2 && cLabels.length) {
    ctx2._chart = new Chart(ctx2, {
      type: 'bar',
      data: {
        labels: cLabels.map(l => l.charAt(0).toUpperCase() + l.slice(1)),
        datasets: [
          { label: 'Ingreso',  data: ingresos, backgroundColor: '#1F8A4C', borderRadius: 4 },
          { label: 'Costo',    data: costoCan,  backgroundColor: '#D42B00', borderRadius: 4 },
          { label: 'Margen',   data: margenes,  backgroundColor: '#1E5FB6', borderRadius: 4 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } },
          tooltip: { callbacks: { label: c => c.dataset.label + ': ' + fmt(c.parsed.y) } }
        },
        scales: { y: { ticks: { callback: v => '$' + Math.round(v / 1000) + 'k' } } }
      }
    });
  }

  // Chart 3: Ventas vs Costos mensual
  const ctx3 = root.querySelector('#ch-mensual');
  if (ctx3 && labels.length) {
    ctx3._chart = new Chart(ctx3, {
      type: 'bar',
      data: {
        labels: labelsFmt,
        datasets: [
          { label: 'Ventas',  data: labels.map(m => porMes[m].ventas),  backgroundColor: '#1F8A4C', borderRadius: 4 },
          { label: 'Costos',  data: labels.map(m => porMes[m].compras), backgroundColor: '#D42B00', borderRadius: 4 },
          {
            label: 'Margen', type: 'line',
            data: labels.map(m => porMes[m].ventas - porMes[m].compras),
            borderColor: '#1E5FB6', backgroundColor: 'rgba(30,95,182,.15)',
            tension: 0.3, fill: true, pointRadius: 3, yAxisID: 'y'
          }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } },
          tooltip: { callbacks: { label: c => c.dataset.label + ': ' + fmt(c.parsed.y) } }
        },
        scales: { y: { ticks: { callback: v => '$' + Math.round(v / 1000) + 'k' } } }
      }
    });
  }

  // ── Tabla categorías ───────────────────────────────────────────
  const cats = {};
  compras.forEach(c => {
    const k = c.categoria || 'Sin categoría';
    cats[k] = (cats[k] || 0) + Number(c.total_con_iva || 0);
  });
  const filas = Object.entries(cats)
    .sort((a, b) => b[1] - a[1])
    .map(([cat, val]) => {
      const pct = totalCompras > 0 ? (val / totalCompras) * 100 : 0;
      return `<tr>
        <td>${cat}</td>
        <td class="num">${fmt(val)}</td>
        <td class="num">${pct.toFixed(1)}%</td>
        <td style="padding: 0 8px; width:120px">
          <div style="background:var(--calibu-primario); height:8px; border-radius:4px; width:${Math.min(pct, 100).toFixed(0)}%"></div>
        </td>
      </tr>`;
    }).join('');

  root.querySelector('#tabla-categorias').innerHTML = `
    <div class="table-wrap">
      <table class="data">
        <thead><tr>
          <th>Categoría</th>
          <th class="num">Gasto</th>
          <th class="num">% del total</th>
          <th></th>
        </tr></thead>
        <tbody>${filas || '<tr><td colspan="4" style="text-align:center;padding:24px"><small>Sin compras en el rango seleccionado</small></td></tr>'}</tbody>
      </table>
    </div>`;
}
