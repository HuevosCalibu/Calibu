import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, hoyISO, mesActualISO } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>💵 Mis anticipos</h1><small>Solicitar y ver historial</small></div>
      <button class="btn" id="btn-solicitar">+ Solicitar anticipo</button>
    </div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><p>Cuenta no vinculada a empleado</p></div></div>';
    return;
  }
  await pintar(root, perfil);
  root.querySelector('#btn-solicitar').addEventListener('click', () => formulario(root, perfil));
}

async function pintar(root, perfil) {
  const { data } = await supabase.from('anticipos').select('*').eq('empleado_id', perfil.empleado_id).order('fecha', { ascending: false });
  const rows = data || [];
  const pendientes = rows.filter(r => !r.descontado).reduce((a,r) => a + r.monto, 0);
  const totalAnio = rows.reduce((a,r) => a + r.monto, 0);
  root.querySelector('#contenido').innerHTML = `
    <div class="kpi-grid" style="margin-bottom: 16px">
      <div class="kpi"><div class="label">Pendientes descuento</div><div class="value">${formatearCLP(pendientes)}</div></div>
      <div class="kpi"><div class="label">Total acumulado</div><div class="value">${formatearCLP(totalAnio)}</div></div>
      <div class="kpi"><div class="label">N° anticipos</div><div class="value">${rows.length}</div></div>
    </div>
    <div class="card" style="padding:0"><div class="table-wrap"><table class="data">
      <thead><tr><th>Fecha</th><th>Descripción</th><th>Mes descuento</th><th class="num">Monto</th><th>Estado</th></tr></thead>
      <tbody>${rows.map(r => `
        <tr>
          <td>${formatearFecha(r.fecha)}</td>
          <td>${escapeHTML(r.descripcion||'—')}</td>
          <td>${escapeHTML(r.mes_descuento||'—')}</td>
          <td class="num">${formatearCLP(r.monto)}</td>
          <td><span class="badge ${r.descontado?'ok':'warn'}">${r.descontado?'Descontado':'Pendiente'}</span></td>
        </tr>`).join('') || '<tr><td colspan="5" style="text-align:center;padding:24px"><small>Sin anticipos</small></td></tr>'}
      </tbody>
    </table></div></div>`;
}

function formulario(root, perfil) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" style="max-width: 480px" id="form-ant">
      <div class="modal-header"><h2>Solicitar anticipo</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1"><label>Monto (CLP) *</label><input type="number" name="monto" required min="1" step="1000" placeholder="50000"></div>
        <div class="field"><label>Fecha</label><input type="date" name="fecha" value="${hoyISO()}" readonly></div>
        <div class="field"><label>Mes para descontar</label><input type="month" name="mes_descuento" value="${mesActualISO()}"></div>
        <div class="field" style="grid-column:1/-1"><label>Motivo *</label><textarea name="descripcion" required rows="2" placeholder="Ej: emergencia familiar"></textarea></div>
      </div>
      <p style="font-size:12px; color:var(--text-muted); margin-top:8px">Tu solicitud queda registrada como pendiente hasta que el administrador la descuente en la próxima liquidación.</p>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Enviar solicitud</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-ant');
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const { error } = await supabase.from('anticipos').insert({
      empleado_id: perfil.empleado_id,
      fecha: form.fecha.value,
      monto: parseInt(form.monto.value, 10),
      descripcion: form.descripcion.value,
      mes_descuento: form.mes_descuento.value,
      descontado: false
    });
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Solicitud enviada', 'ok');
    back.remove();
    await pintar(root, perfil);
  });
}
