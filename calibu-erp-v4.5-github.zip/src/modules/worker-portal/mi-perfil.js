import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, formatearRUT, escapeHTML, calcularSaldoVacaciones } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header"><h1>Mi perfil</h1></div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><div class="icon">🤷</div><p>Tu cuenta no está vinculada a un empleado.<br>Pídele al administrador que actualice tu profile.</p></div></div>';
    return;
  }
  const { data: emp, error } = await supabase.from('empleados').select('*').eq('id', perfil.empleado_id).maybeSingle();
  if (error || !emp) { toast('No se pudieron cargar tus datos', 'danger'); return; }
  const { data: vacs } = await supabase.from('vacaciones').select('dias_habiles, estado').eq('empleado_id', emp.id).in('estado', ['aprobada','tomada']);
  const diasTomados = (vacs||[]).reduce((a, v) => a + parseFloat(v.dias_habiles||0), 0);
  const saldo = emp.fecha_ingreso ? calcularSaldoVacaciones({ fecha_ingreso: emp.fecha_ingreso, dias_tomados: diasTomados }) : null;
  root.querySelector('#contenido').innerHTML = `
    <div class="kpi-grid" style="margin-bottom: 16px">
      <div class="kpi"><div class="label">Sueldo base</div><div class="value">${formatearCLP(emp.sueldo_base)}</div></div>
      <div class="kpi"><div class="label">Vacaciones disponibles</div><div class="value">${saldo !== null ? saldo + ' días' : '—'}</div></div>
      <div class="kpi"><div class="label">Estado</div><div class="value" style="font-size:18px">${escapeHTML(emp.estado)}</div></div>
    </div>
    <div class="card">
      <h3 class="card-title">Datos personales</h3>
      <div style="display:grid; grid-template-columns: max-content 1fr; gap: 10px 24px; font-size: 14px">
        <div style="color:var(--text-muted)">Nombre:</div><div><strong>${escapeHTML(emp.nombre)}</strong></div>
        <div style="color:var(--text-muted)">RUT:</div><div><code>${escapeHTML(formatearRUT(emp.rut))}</code></div>
        <div style="color:var(--text-muted)">Cargo:</div><div>${escapeHTML(emp.cargo||'—')}</div>
        <div style="color:var(--text-muted)">Área:</div><div>${escapeHTML(emp.area||'—')}</div>
        <div style="color:var(--text-muted)">Tipo contrato:</div><div>${escapeHTML(emp.tipo_contrato||'—')}</div>
        <div style="color:var(--text-muted)">Jornada:</div><div>${escapeHTML(emp.tipo_jornada||'—')}</div>
        <div style="color:var(--text-muted)">AFP:</div><div>${escapeHTML(emp.afp||'—')}</div>
        <div style="color:var(--text-muted)">Salud:</div><div>${escapeHTML(emp.prevision_salud||'—')} ${emp.isapre_nombre?'· '+escapeHTML(emp.isapre_nombre):''}</div>
        <div style="color:var(--text-muted)">Email:</div><div>${escapeHTML(emp.email||'—')}</div>
        <div style="color:var(--text-muted)">Teléfono:</div><div>${escapeHTML(emp.telefono||'—')}</div>
        <div style="color:var(--text-muted)">Dirección:</div><div>${escapeHTML(emp.direccion||'—')}</div>
        <div style="color:var(--text-muted)">Fecha ingreso:</div><div>${formatearFecha(emp.fecha_ingreso)}</div>
      </div>
    </div>`;
}
