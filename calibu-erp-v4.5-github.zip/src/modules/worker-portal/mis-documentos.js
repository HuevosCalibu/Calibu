import { supabase } from '../../lib/supabase.js';
import { formatearFecha, escapeHTML } from '../../lib/calc.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header"><h1>📂 Mis documentos</h1></div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><p>Cuenta no vinculada a empleado</p></div></div>';
    return;
  }
  const { data } = await supabase
    .from('documentos_empleado').select('*')
    .eq('empleado_id', perfil.empleado_id).order('fecha', { ascending: false });
  const cont = root.querySelector('#contenido');
  if (!data?.length) {
    cont.innerHTML = '<div class="card"><div class="empty-state"><div class="icon">📄</div><p>Sin documentos en tu carpeta</p></div></div>';
    return;
  }
  const iconos = { contrato: '📜', anexo: '📎', certificado: '🏅', licencia: '🩺', otro: '📄' };
  cont.innerHTML = `
    <div style="display:grid; gap:12px; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr))">
      ${data.map(d => `
        <div class="card">
          <div style="display:flex; gap:12px; align-items:flex-start">
            <div style="font-size:32px">${iconos[d.tipo] || '📄'}</div>
            <div style="flex:1; min-width:0">
              <div style="font-weight:600; margin-bottom:2px">${escapeHTML(d.titulo)}</div>
              <small>${escapeHTML(d.tipo)} · ${formatearFecha(d.fecha)}</small>
              ${d.notas ? `<div style="font-size:12px; color: var(--text-muted); margin-top: 6px">${escapeHTML(d.notas)}</div>` : ''}
              ${d.archivo_url ? `<a href="${escapeHTML(d.archivo_url)}" target="_blank" class="btn ghost sm" style="margin-top:8px">Ver / descargar</a>` : '<small style="color:var(--text-muted)">Sin archivo adjunto</small>'}
            </div>
          </div>
        </div>`).join('')}
    </div>`;
}
