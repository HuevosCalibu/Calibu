import { supabase } from '../../lib/supabase.js';
import { formatearFecha, escapeHTML, hoyISO } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header"><h1>⏰ Asistencia</h1></div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><p>Cuenta no vinculada a empleado</p></div></div>';
    return;
  }
  await pintar(root, perfil);
}

async function pintar(root, perfil) {
  const hoy = hoyISO();
  const { data: hoyReg } = await supabase
    .from('asistencia').select('*').eq('empleado_id', perfil.empleado_id).eq('fecha', hoy).maybeSingle();
  const { data: hist } = await supabase
    .from('asistencia').select('*').eq('empleado_id', perfil.empleado_id)
    .order('fecha', { ascending: false }).limit(20);
  const haEntrada = !!hoyReg?.entrada;
  const haSalida = !!hoyReg?.salida;
  const cont = root.querySelector('#contenido');
  cont.innerHTML = `
    <div class="card" style="background: linear-gradient(135deg, var(--calibu-primario), var(--calibu-primario-dark)); color: #fff; text-align: center">
      <div style="font-size:14px; opacity:.9; margin-bottom:4px">Hoy ${formatearFecha(hoy)}</div>
      <div style="font-size: 42px; font-weight:800; margin: 12px 0" id="reloj"></div>
      <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap">
        <button class="btn ghost" id="btn-entrada" style="background:rgba(255,255,255,.15); color:#fff; border-color:rgba(255,255,255,.4); padding:14px 24px; font-size:16px" ${haEntrada?'disabled':''}>
          ${haEntrada ? '✓ Entrada: ' + new Date(hoyReg.entrada).toLocaleTimeString('es-CL', {hour:'2-digit', minute:'2-digit'}) : 'Marcar entrada'}
        </button>
        <button class="btn ghost" id="btn-salida" style="background:rgba(255,255,255,.15); color:#fff; border-color:rgba(255,255,255,.4); padding:14px 24px; font-size:16px" ${!haEntrada||haSalida?'disabled':''}>
          ${haSalida ? '✓ Salida: ' + new Date(hoyReg.salida).toLocaleTimeString('es-CL', {hour:'2-digit', minute:'2-digit'}) : 'Marcar salida'}
        </button>
      </div>
    </div>
    <div class="card" style="margin-top:16px; padding:0">
      <div style="padding:16px 16px 8px"><h3 class="card-title" style="margin:0">Historial últimos 20 días</h3></div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Fecha</th><th>Entrada</th><th>Salida</th><th class="num">Horas</th></tr></thead>
        <tbody>${(hist||[]).map(r => `
          <tr>
            <td>${formatearFecha(r.fecha)}</td>
            <td>${r.entrada ? new Date(r.entrada).toLocaleTimeString('es-CL', {hour:'2-digit', minute:'2-digit'}) : '—'}</td>
            <td>${r.salida ? new Date(r.salida).toLocaleTimeString('es-CL', {hour:'2-digit', minute:'2-digit'}) : '—'}</td>
            <td class="num">${r.horas_trabajadas != null ? Number(r.horas_trabajadas).toFixed(1) : '—'}</td>
          </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:24px"><small>Sin registros</small></td></tr>'}
        </tbody>
      </table></div>
    </div>`;
  const reloj = cont.querySelector('#reloj');
  const tick = () => { reloj.textContent = new Date().toLocaleTimeString('es-CL', {hour:'2-digit', minute:'2-digit', second:'2-digit'}); };
  tick(); setInterval(tick, 1000);

  cont.querySelector('#btn-entrada').addEventListener('click', () => marcar('entrada', perfil, root));
  cont.querySelector('#btn-salida').addEventListener('click', () => marcar('salida', perfil, root));
}

function obtenerGeo() {
  return new Promise(resolve => {
    if (!navigator.geolocation) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      p => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => resolve(null),
      { timeout: 5000, enableHighAccuracy: false }
    );
  });
}

async function marcar(tipo, perfil, root) {
  const hoy = hoyISO();
  const ahora = new Date().toISOString();
  const geo = await obtenerGeo();
  const { data: existente } = await supabase
    .from('asistencia').select('*').eq('empleado_id', perfil.empleado_id).eq('fecha', hoy).maybeSingle();
  if (existente) {
    const payload = {};
    if (tipo === 'entrada') { payload.entrada = ahora; if (geo) { payload.lat_entrada = geo.lat; payload.lng_entrada = geo.lng; } }
    else {
      payload.salida = ahora;
      if (geo) { payload.lat_salida = geo.lat; payload.lng_salida = geo.lng; }
      if (existente.entrada) {
        const horas = (new Date(ahora) - new Date(existente.entrada)) / 3600000;
        payload.horas_trabajadas = Math.round(horas * 100) / 100;
      }
    }
    const { error } = await supabase.from('asistencia').update(payload).eq('id', existente.id);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
  } else {
    const payload = { empleado_id: perfil.empleado_id, fecha: hoy };
    payload[tipo] = ahora;
    if (geo) {
      payload['lat_' + tipo] = geo.lat;
      payload['lng_' + tipo] = geo.lng;
    }
    const { error } = await supabase.from('asistencia').insert(payload);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
  }
  toast(tipo === 'entrada' ? '✓ Entrada registrada' : '✓ Salida registrada', 'ok');
  await pintar(root, perfil);
}
