import { supabase } from '../../lib/supabase.js';
import { formatearFecha, calcularDiasHabiles, calcularSaldoVacaciones } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>🏖️ Mis vacaciones</h1></div>
      <button class="btn" id="btn-solicitar">+ Solicitar vacaciones</button>
    </div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><p>Cuenta no vinculada a empleado</p></div></div>';
    return;
  }
  await pintar(root, perfil);
  root.querySelector('#btn-solicitar').addEventListener('click', () => formulario(root, perfil));
}

async function pintar(root, perfil) {
  const { data: emp } = await supabase.from('empleados').select('fecha_ingreso').eq('id', perfil.empleado_id).maybeSingle();
  const { data: rows } = await supabase
    .from('vacaciones').select('*').eq('empleado_id', perfil.empleado_id).order('fecha_solicitud', { ascending: false });
  const tomados = (rows||[]).filter(r => ['aprobada','tomada'].includes(r.estado))
    .reduce((a, v) => a + parseFloat(v.dias_habiles||0), 0);
  const saldo = emp?.fecha_ingreso ? calcularSaldoVacaciones({ fecha_ingreso: emp.fecha_ingreso, dias_tomados: tomados }) : null;
  const cont = root.querySelector('#contenido');
  cont.innerHTML = `
    <div class="kpi-grid" style="margin-bottom: 16px">
      <div class="kpi"><div class="label">Saldo disponible</div><div class="value">${saldo !== null ? saldo + ' días' : '—'}</div></div>
      <div class="kpi"><div class="label">Días tomados</div><div class="value">${tomados}</div></div>
      <div class="kpi"><div class="label">Solicitudes</div><div class="value">${(rows||[]).length}</div></div>
    </div>
    <div class="card" style="padding:0"><div class="table-wrap"><table class="data">
      <thead><tr><th>Solicitud</th><th>Desde</th><th>Hasta</th><th class="num">Días</th><th>Estado</th><th>Motivo</th></tr></thead>
      <tbody>${(rows||[]).map(r => {
        const m = { solicitada:'warn', aprobada:'ok', rechazada:'danger', tomada:'info', cancelada:'neutral' };
        return `<tr>
          <td>${formatearFecha(r.fecha_solicitud)}</td>
          <td>${formatearFecha(r.fecha_desde)}</td>
          <td>${formatearFecha(r.fecha_hasta)}</td>
          <td class="num">${r.dias_habiles}</td>
          <td><span class="badge ${m[r.estado]||'neutral'}">${r.estado}</span></td>
          <td>${r.motivo_rechazo || r.notas || '—'}</td>
        </tr>`;
      }).join('') || '<tr><td colspan="6" style="text-align:center;padding:24px"><small>Sin solicitudes</small></td></tr>'}
      </tbody>
    </table></div></div>`;
}

function formulario(root, perfil) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" style="max-width: 480px" id="form-vac">
      <div class="modal-header"><h2>Solicitar vacaciones</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field"><label>Desde *</label><input type="date" name="fecha_desde" required min="${new Date().toISOString().slice(0,10)}"></div>
        <div class="field"><label>Hasta *</label><input type="date" name="fecha_hasta" required></div>
        <div class="field" style="grid-column:1/-1">
          <label>Días hábiles</label>
          <input type="text" id="dias-calc" readonly>
        </div>
        <div class="field" style="grid-column:1/-1"><label>Notas</label><textarea name="notas" rows="2"></textarea></div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Enviar solicitud</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-vac');
  const recalc = () => {
    if (form.fecha_desde.value && form.fecha_hasta.value) {
      form.querySelector('#dias-calc').value = calcularDiasHabiles(form.fecha_desde.value, form.fecha_hasta.value) + ' días hábiles';
    }
  };
  form.fecha_desde.addEventListener('change', recalc);
  form.fecha_hasta.addEventListener('change', recalc);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const dias = calcularDiasHabiles(form.fecha_desde.value, form.fecha_hasta.value);
    if (dias <= 0) { toast('Fechas inválidas', 'danger'); return; }
    const { error } = await supabase.from('vacaciones').insert({
      empleado_id: perfil.empleado_id,
      fecha_desde: form.fecha_desde.value,
      fecha_hasta: form.fecha_hasta.value,
      dias_habiles: dias,
      notas: form.notas.value || null,
      estado: 'solicitada'
    });
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Solicitud enviada al admin', 'ok');
    back.remove();
    await pintar(root, perfil);
  });
}
