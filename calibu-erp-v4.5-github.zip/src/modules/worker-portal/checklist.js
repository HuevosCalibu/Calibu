import { supabase } from '../../lib/supabase.js';
import { escapeHTML, hoyISO, formatearFecha } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>✅ Checklist diario</h1><small>Marca cada tarea conforme la completes</small></div>
      <div style="display:flex; gap:8px; align-items:center">
        <label style="font-size:12px; color:var(--text-muted)">Fecha:</label>
        <input type="date" id="fecha" value="${hoyISO()}" max="${hoyISO()}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
      </div>
    </div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><p>Cuenta no vinculada a empleado</p></div></div>';
    return;
  }
  const cargar = () => pintar(root, perfil, root.querySelector('#fecha').value);
  root.querySelector('#fecha').addEventListener('change', cargar);
  await cargar();
}

async function pintar(root, perfil, fecha) {
  const cont = root.querySelector('#contenido');
  cont.innerHTML = 'Cargando...';
  const [tareasRes, logRes] = await Promise.all([
    supabase.from('checklist_template').select('*').eq('activo', true).order('orden'),
    supabase.from('checklist_log').select('*').eq('fecha', fecha).eq('empleado_id', perfil.empleado_id)
  ]);
  const tareas = tareasRes.data || [];
  const log = logRes.data || [];
  const logMap = {};
  log.forEach(l => logMap[l.tarea_id] = l);
  const turnos = ['mañana','tarde','noche','cualquiera'];
  const tnames = { mañana: '🌅 Mañana', tarde: '🌇 Tarde', noche: '🌙 Noche', cualquiera: '📌 Cualquier momento' };
  const completas = tareas.filter(t => logMap[t.id]?.completada).length;
  const pct = tareas.length > 0 ? Math.round((completas / tareas.length) * 100) : 0;
  cont.innerHTML = `
    <div class="card" style="margin-bottom:16px; background: linear-gradient(135deg, var(--calibu-primario), var(--calibu-primario-dark)); color: #fff">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap">
        <div>
          <div style="font-size:13px; opacity:.9">${formatearFecha(fecha)}</div>
          <div style="font-size:32px; font-weight:800; margin-top:4px">${completas} / ${tareas.length}</div>
          <div style="font-size:13px; opacity:.9">tareas completadas</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:42px; font-weight:800">${pct}%</div>
          <div style="font-size:12px; opacity:.9">cumplimiento</div>
        </div>
      </div>
      <div style="margin-top:12px; background:rgba(255,255,255,.2); height:8px; border-radius:999px; overflow:hidden">
        <div style="background:var(--calibu-acento); height:100%; width:${pct}%; transition: width .3s"></div>
      </div>
    </div>
    ${turnos.map(t => {
      const ts = tareas.filter(x => x.turno === t);
      if (!ts.length) return '';
      return `
        <div class="card" style="margin-bottom: 12px">
          <h3 class="card-title">${tnames[t]}</h3>
          ${ts.map(tarea => {
            const l = logMap[tarea.id];
            const checked = l?.completada ? 'checked' : '';
            const horaTxt = l?.completada && l.hora ? '<span style="font-size:11px;color:var(--text-muted)"> · ' + new Date(l.hora).toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'}) + '</span>' : '';
            return `
              <label style="display:flex; gap:12px; padding:10px 0; border-bottom: 1px solid var(--border); cursor:pointer; align-items: flex-start" data-tarea="${tarea.id}">
                <input type="checkbox" ${checked} style="width:22px; height:22px; margin-top:2px; cursor:pointer">
                <div style="flex:1">
                  <div style="font-weight:500; ${l?.completada?'text-decoration:line-through; opacity:.6':''}">${escapeHTML(tarea.titulo)}${horaTxt}</div>
                  ${tarea.descripcion ? `<div style="font-size:12px; color:var(--text-muted)">${escapeHTML(tarea.descripcion)}</div>` : ''}
                </div>
              </label>`;
          }).join('')}
        </div>`;
    }).join('')}`;

  cont.querySelectorAll('label[data-tarea] input').forEach(chk => {
    chk.addEventListener('change', async (e) => {
      const tareaId = e.target.closest('label').dataset.tarea;
      const completada = e.target.checked;
      const payload = { fecha, empleado_id: perfil.empleado_id, tarea_id: tareaId, completada, hora: completada ? new Date().toISOString() : null };
      const { error } = await supabase.from('checklist_log').upsert(payload, { onConflict: 'fecha,empleado_id,tarea_id' });
      if (error) { toast('Error: ' + error.message, 'danger'); e.target.checked = !completada; return; }
      toast(completada ? '✓ Marcada' : 'Desmarcada', 'ok', 1500);
      pintar(root, perfil, fecha);
    });
  });
}
