import { supabase } from '../../lib/supabase.js';
import { formatearCLP } from '../../lib/calc.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header"><h1>💵 Mis liquidaciones</h1></div>
    <div id="contenido">Cargando...</div>`;
  if (!perfil.empleado_id) {
    root.querySelector('#contenido').innerHTML = '<div class="card"><div class="empty-state"><p>Cuenta no vinculada a empleado</p></div></div>';
    return;
  }
  const { data, error } = await supabase
    .from('liquidaciones').select('*')
    .eq('empleado_id', perfil.empleado_id)
    .order('anio_mes', { ascending: false });
  const cont = root.querySelector('#contenido');
  if (error || !data?.length) {
    cont.innerHTML = '<div class="card"><div class="empty-state"><div class="icon">📋</div><p>Sin liquidaciones disponibles</p></div></div>';
    return;
  }
  cont.innerHTML = `
    <div class="card" style="padding:0"><div class="table-wrap"><table class="data">
      <thead><tr>
        <th>Mes</th><th class="num">Sueldo base</th><th class="num">Total haberes</th>
        <th class="num">AFP</th><th class="num">Salud</th><th class="num">Anticipos</th>
        <th class="num">Líquido</th><th>Estado</th>
      </tr></thead>
      <tbody>${data.map(r => `
        <tr>
          <td>${r.anio_mes}</td>
          <td class="num">${formatearCLP(r.sueldo_base)}</td>
          <td class="num">${formatearCLP(r.total_haberes)}</td>
          <td class="num">${formatearCLP(r.afp_monto + r.afp_comision)}</td>
          <td class="num">${formatearCLP(r.salud_monto)}</td>
          <td class="num">${formatearCLP(r.anticipos_monto)}</td>
          <td class="num" style="font-weight:700; color: var(--calibu-primario)">${formatearCLP(r.liquido)}</td>
          <td><span class="badge ${r.estado==='pagada'?'ok':r.estado==='emitida'?'info':'neutral'}">${r.estado}</span></td>
        </tr>`).join('')}
      </tbody>
    </table></div></div>`;
}
