// Placeholder para módulos pendientes de implementar
export async function render(root) {
  root.innerHTML = `
    <div class="card">
      <div class="empty-state">
        <div class="icon">🚧</div>
        <h2>En construcción</h2>
        <p>Este módulo será implementado en una próxima iteración.</p>
        <p><small>El schema SQL ya está creado, solo falta el frontend.</small></p>
      </div>
    </div>
  `;
}
