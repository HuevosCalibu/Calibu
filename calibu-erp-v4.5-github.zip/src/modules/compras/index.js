// =====================================================================
// Calibú ERP — Compras y gastos
// Fixes: CSV export, KPI panel costo/huevo, listener acumulativo,
//        gráfico categorías, filtros persistentes
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, hoyISO, mesActualISO } from '../../lib/calc.js';
import { toast, confirmar, badgeEstadoPago, exportarCSV } from '../../lib/ui.js';
import { LISTAS } from '../../lib/constantes.js';

let _filtro = { categoria: '', desde: '', hasta: '' };
let _proveedores = [];

function guardarFiltro() { try { localStorage.setItem('filtro_compras', JSON.stringify(_filtro)); } catch(e) {} }
function restaurarFiltro() {
  try { const f = localStorage.getItem('filtro_compras'); if (f) _filtro = { ..._filtro, ...JSON.parse(f) }; } catch(e) {}
}

export async function render(root) {
  restaurarFiltro();
  if (!_filtro.desde) _filtro.desde = mesActualISO() + '-01';
  if (!_filtro.hasta) _filtro.hasta = hoyISO();

  root.innerHTML = `
    <div class="section-header">
      <div><h1>Compras y gastos</h1><small>Registro mensual por categoría</small></div>
      <div style="display:flex; gap:8px">
        <button class="btn ghost" id="btn-csv">📥 CSV</button>
        <button class="btn ghost" id="btn-prov">Proveedores</button>
        <button class="btn" id="btn-nueva">+ Nueva compra</button>
      </div>
    </div>

    <!-- KPI panel -->
    <div class="kpi-grid-rich" id="kpis-compras" style="margin-bottom:16px"></div>

    <!-- Filtros -->
    <div class="card" style="margin-bottom:16px; padding:12px 16px">
      <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap">
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Desde</label><br>
          <input type="date" id="desde" value="${_filtro.desde}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Hasta</label><br>
          <input type="date" id="hasta" value="${_filtro.hasta}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Categoría</label><br>
          <select id="categoria" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
            <option value="">Todas</option>
            ${LISTAS.CATEGORIAS_COMPRA.map(c => `<option value="${escapeHTML(c)}" ${_filtro.categoria === c ? 'selected' : ''}>${escapeHTML(c)}</option>`).join('')}
          </select>
        </div>
        <div style="margin-left:auto" id="resumen-mini"></div>
      </div>
    </div>

    <!-- Barras horizontales por categoría -->
    <div class="card" style="margin-bottom:16px" id="card-cats" hidden>
      <h3 class="card-title" style="margin-bottom:12px">Distribución por categoría</h3>
      <div id="barras-cats"></div>
    </div>

    <!-- Tabla -->
    <div class="card" style="padding:0">
      <div class="table-wrap">
        <table class="data">
          <thead><tr>
            <th>Fecha</th><th>Categoría</th><th>Proveedor</th><th>Descripción</th>
            <th class="num">Neto</th><th class="num">IVA</th><th class="num">Total</th>
            <th>Estado</th><th class="actions">Acciones</th>
          </tr></thead>
          <tbody id="tbody">
            <tr><td colspan="9" style="text-align:center; padding:24px">Cargando...</td></tr>
          </tbody>
        </table>
      </div>
    </div>`;

  const { data: provs } = await supabase.from('proveedores').select('*').order('nombre');
  _proveedores = provs || [];

  ['desde', 'hasta', 'categoria'].forEach(id => {
    root.querySelector('#' + id).addEventListener('change', e => {
      _filtro[id] = e.target.value;
      guardarFiltro();
      recargar(root);
    });
  });
  root.querySelector('#btn-nueva').addEventListener('click', () => abrirFormulario(root));
  root.querySelector('#btn-prov').addEventListener('click', () => modalProveedores(root));
  root.querySelector('#btn-csv').addEventListener('click', () => exportarTabla(root));

  await recargar(root);
}

function reemplazarTbody(root) {
  const viejo = root.querySelector('#tbody');
  const nuevo = viejo.cloneNode(false);
  viejo.parentNode.replaceChild(nuevo, viejo);
  return nuevo;
}

async function recargar(root) {
  let q = supabase.from('compras')
    .select('*, proveedores:proveedor_id(nombre)')
    .gte('fecha', _filtro.desde)
    .lte('fecha', _filtro.hasta);
  if (_filtro.categoria) q = q.eq('categoria', _filtro.categoria);
  q = q.order('fecha', { ascending: false }).limit(500);

  const { data, error } = await q;
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  const rows = data || [];

  // KPIs
  const totalNeto = rows.reduce((a, r) => a + (r.total_neto || 0), 0);
  const totalIVA  = rows.reduce((a, r) => a + (r.iva || 0), 0);
  const totalCIVA = rows.reduce((a, r) => a + (r.total_con_iva || 0), 0);
  const pendiente = rows.filter(r => r.estado_pago === 'pendiente').reduce((a, r) => a + (r.total_con_iva || 0), 0);

  // Costo/huevo del período: necesitamos producción del mismo rango
  const { data: prodData } = await supabase.from('produccion_diaria')
    .select('huevos_enteros').gte('fecha', _filtro.desde).lte('fecha', _filtro.hasta);
  const huevosProd = (prodData || []).reduce((a, p) => a + (p.huevos_enteros || 0), 0);

  // Ingresos del período
  const { data: ventasData } = await supabase.from('ventas')
    .select('total, n_huevos').gte('fecha', _filtro.desde).lte('fecha', _filtro.hasta).neq('estado_pago', 'anulado');
  const totalVentas = (ventasData || []).reduce((a, v) => a + (v.total || 0), 0);
  const huevosVend  = (ventasData || []).reduce((a, v) => a + (v.n_huevos || 0), 0);
  const huevosBase  = huevosProd || huevosVend || 1;
  const costoHuevo  = totalNeto / huevosBase;
  const precioHuevo = totalVentas / (huevosVend || 1);
  const margen      = totalVentas - totalNeto;
  const margenPct   = totalVentas > 0 ? (margen / totalVentas) * 100 : 0;

  root.querySelector('#kpis-compras').innerHTML = [
    ['🧾', 'Total gastos', formatearCLP(totalCIVA), `neto ${formatearCLP(totalNeto)} + IVA ${formatearCLP(totalIVA)}`, 'bg-yellow'],
    ['⏳', 'Por pagar', formatearCLP(pendiente), `${rows.filter(r => r.estado_pago === 'pendiente').length} facturas pendientes`, 'bg-red'],
    ['🥚', 'Costo / huevo', '$' + Math.round(costoHuevo).toLocaleString('es-CL'), `${huevosProd ? huevosProd.toLocaleString('es-CL') + ' producidos' : huevosVend.toLocaleString('es-CL') + ' vendidos'}`, 'bg-blue'],
    ['💎', 'Margen bruto', formatearCLP(margen), `${margenPct.toFixed(1)}% sobre ventas`, margen >= 0 ? 'bg-green' : 'bg-pink']
  ].map(([icon, label, value, sub, color]) =>
    `<div class="kpi-card">
       <div class="kpi-icon ${color}">${icon}</div>
       <div class="kpi-label">${label}</div>
       <div class="kpi-value">${value}</div>
       <div class="kpi-sub">${sub}</div>
     </div>`
  ).join('');

  root.querySelector('#resumen-mini').innerHTML = `
    <div style="text-align:right">
      <div style="font-size:11px; color:var(--text-muted); text-transform:uppercase">Total filtrado</div>
      <div style="font-weight:700; font-size:18px">${formatearCLP(totalCIVA)} <small style="color:var(--text-muted)">(IVA: ${formatearCLP(totalIVA)})</small></div>
    </div>`;

  // Barras por categoría (solo si no hay filtro de categoría)
  const cardCats = root.querySelector('#card-cats');
  if (!_filtro.categoria && rows.length > 0) {
    const cats = {};
    rows.forEach(r => { cats[r.categoria || 'Sin categoría'] = (cats[r.categoria || 'Sin categoría'] || 0) + (r.total_con_iva || 0); });
    const sorted = Object.entries(cats).sort((a, b) => b[1] - a[1]);
    const max = sorted[0][1] || 1;
    root.querySelector('#barras-cats').innerHTML = sorted.map(([cat, val]) => `
      <div style="display:grid; grid-template-columns:160px 1fr auto; align-items:center; gap:12px; margin-bottom:8px">
        <div style="font-size:13px; truncate; white-space:nowrap; overflow:hidden; text-overflow:ellipsis" title="${escapeHTML(cat)}">${escapeHTML(cat)}</div>
        <div style="background:var(--border); border-radius:4px; height:10px; overflow:hidden">
          <div style="background:var(--calibu-primario); height:100%; width:${((val/max)*100).toFixed(0)}%; border-radius:4px"></div>
        </div>
        <div style="font-size:13px; font-weight:600; white-space:nowrap">${formatearCLP(val)}</div>
      </div>`).join('');
    cardCats.hidden = false;
  } else {
    cardCats.hidden = true;
  }

  const tbody = reemplazarTbody(root);
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="9">
      <div class="empty-state"><div class="icon">🧾</div>
        <p>Sin compras en el período</p>
        <button class="btn" id="btn-nueva-empty">+ Registrar compra</button>
      </div></td></tr>`;
    tbody.querySelector('#btn-nueva-empty')?.addEventListener('click', () => abrirFormulario(root));
    return;
  }

  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td>${formatearFecha(r.fecha)}</td>
      <td><span class="badge neutral">${escapeHTML(r.categoria || '—')}</span></td>
      <td>${escapeHTML(r.proveedores?.nombre || '—')}</td>
      <td>${escapeHTML(r.descripcion || '—')}</td>
      <td class="num">${formatearCLP(r.total_neto)}</td>
      <td class="num">${formatearCLP(r.iva || 0)}</td>
      <td class="num" style="font-weight:600">${formatearCLP(r.total_con_iva)}</td>
      <td>${badgeEstadoPago(r.estado_pago)}</td>
      <td class="actions">
        ${r.estado_pago === 'pendiente' ? `<button class="btn ghost sm" data-action="pagar" data-id="${r.id}">Pagar</button>` : ''}
        <button class="btn ghost sm" data-action="del" data-id="${r.id}">Eliminar</button>
      </td>
    </tr>`).join('');

  tbody.addEventListener('click', async ev => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.dataset.id;
    if (btn.dataset.action === 'pagar') {
      const { error } = await supabase.from('compras').update({ estado_pago: 'pagado' }).eq('id', id);
      if (error) { toast('Error: ' + error.message, 'danger'); return; }
      toast('Pago registrado ✅', 'ok');
    } else if (btn.dataset.action === 'del') {
      const fila = btn.closest('tr');
      const desc = fila.cells[3].textContent || 'esta compra';
      if (!await confirmar(`¿Eliminar "${desc}"?`, { peligroso: true })) return;
      const { error } = await supabase.from('compras').delete().eq('id', id);
      if (error) { toast('Error: ' + error.message, 'danger'); return; }
      toast('Eliminada ✅', 'ok');
    }
    await recargar(root);
  });
}

function exportarTabla(root) {
  const filas = [...root.querySelectorAll('#tbody tr[data-id]')].map(tr => ({
    fecha:       tr.cells[0].textContent,
    categoria:   tr.cells[1].textContent.trim(),
    proveedor:   tr.cells[2].textContent,
    descripcion: tr.cells[3].textContent,
    neto:        tr.cells[4].textContent,
    iva:         tr.cells[5].textContent,
    total:       tr.cells[6].textContent,
    estado:      tr.cells[7].textContent.trim()
  }));
  if (!filas.length) { toast('No hay datos para exportar', 'warn'); return; }
  exportarCSV('compras_calibu.csv', [
    { key: 'fecha',       label: 'Fecha' },
    { key: 'categoria',   label: 'Categoría' },
    { key: 'proveedor',   label: 'Proveedor' },
    { key: 'descripcion', label: 'Descripción' },
    { key: 'neto',        label: 'Total neto' },
    { key: 'iva',         label: 'IVA' },
    { key: 'total',       label: 'Total c/IVA' },
    { key: 'estado',      label: 'Estado pago' }
  ], filas);
  toast(`${filas.length} filas exportadas ✅`, 'ok');
}

function abrirFormulario(root) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-compra" style="max-width:620px">
      <div class="modal-header"><h2>Nueva compra</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field"><label>Fecha *</label><input type="date" name="fecha" required value="${hoyISO()}"></div>
        <div class="field">
          <label>Categoría *</label>
          <select name="categoria" required>
            <option value="">— Selecciona —</option>
            ${LISTAS.CATEGORIAS_COMPRA.map(c => `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Proveedor</label>
          <select name="proveedor_id">
            <option value="">—</option>
            ${_proveedores.map(p => `<option value="${p.id}">${escapeHTML(p.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>N° documento</label><input name="numero_documento" placeholder="Factura, boleta..."></div>
        <div class="field" style="grid-column:1/-1"><label>Descripción</label><input name="descripcion" placeholder="Ej: 50 sacos Purina postura"></div>
        <div class="field"><label>Total neto *</label><input type="number" name="total_neto" required step="1" min="0" id="inp-neto"></div>
        <div class="field"><label>IVA (auto 19%)</label><input type="number" name="iva" step="1" min="0" id="inp-iva" value="0"></div>
        <div class="field"><label>Total c/IVA</label><input type="text" id="inp-total" readonly style="background:var(--surface-2); font-weight:700"></div>
        <div class="field">
          <label>Estado pago *</label>
          <select name="estado_pago" required>
            ${['pagado', 'pendiente', 'vencido'].map(e => `<option value="${e}" ${e === 'pagado' ? 'selected' : ''}>${e}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Medio de pago</label>
          <select name="medio_pago">
            <option value="">—</option>
            ${LISTAS.MEDIOS_PAGO.map(m => `<option>${m}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Registrar</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-compra');
  const recalc = () => {
    const neto = parseFloat(form.querySelector('#inp-neto').value) || 0;
    const iva  = parseFloat(form.querySelector('#inp-iva').value)  || 0;
    form.querySelector('#inp-total').value = formatearCLP(neto + iva);
  };
  form.querySelector('#inp-neto').addEventListener('input', () => {
    form.querySelector('#inp-iva').value = Math.round((parseFloat(form.querySelector('#inp-neto').value) || 0) * 0.19);
    recalc();
  });
  form.querySelector('#inp-iva').addEventListener('input', recalc);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const neto = parseInt(fd.get('total_neto'), 10);
    const iva  = parseInt(fd.get('iva'), 10) || 0;
    const btn = form.querySelector('[type=submit]');
    btn.disabled = true; btn.textContent = 'Guardando...';
    const { error } = await supabase.from('compras').insert({
      fecha:            fd.get('fecha'),
      categoria:        fd.get('categoria'),
      proveedor_id:     fd.get('proveedor_id') || null,
      descripcion:      fd.get('descripcion') || null,
      numero_documento: fd.get('numero_documento') || null,
      total_neto: neto, iva, total_con_iva: neto + iva,
      estado_pago: fd.get('estado_pago'),
      medio_pago:  fd.get('medio_pago') || null
    });
    if (error) {
      toast('Error: ' + error.message, 'danger');
      btn.disabled = false; btn.textContent = 'Registrar';
      return;
    }
    toast('Compra registrada ✅', 'ok');
    back.remove();
    await recargar(root);
  });
}

async function modalProveedores(root) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <div class="modal" style="max-width:720px">
      <div class="modal-header"><h2>Proveedores</h2><button type="button" class="modal-close">&times;</button></div>
      <div style="display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap">
        <input id="prov-nombre" placeholder="Nombre *" style="flex:1; min-width:150px; padding:8px 10px; border:1px solid var(--border-fuerte); border-radius:6px">
        <input id="prov-rut" placeholder="RUT" style="width:130px; padding:8px 10px; border:1px solid var(--border-fuerte); border-radius:6px">
        <select id="prov-cat" style="padding:8px; border:1px solid var(--border-fuerte); border-radius:6px">
          <option value="">Categoría</option>
          ${LISTAS.CATEGORIAS_COMPRA.map(c => `<option>${escapeHTML(c)}</option>`).join('')}
        </select>
        <button class="btn" id="prov-add">+ Agregar</button>
      </div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Nombre</th><th>RUT</th><th>Categoría</th><th class="actions">Acciones</th></tr></thead>
        <tbody id="prov-tbody"></tbody>
      </table></div>
    </div>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => { back.remove(); recargar(root); });

  const pintar = async () => {
    const { data } = await supabase.from('proveedores').select('*').order('nombre');
    _proveedores = data || [];
    const tbody = back.querySelector('#prov-tbody');
    tbody.innerHTML = _proveedores.map(p => `
      <tr data-id="${p.id}">
        <td>${escapeHTML(p.nombre)}</td>
        <td><code>${escapeHTML(p.rut || '—')}</code></td>
        <td>${escapeHTML(p.categoria_principal || '—')}</td>
        <td class="actions"><button class="btn ghost sm" data-action="del">Eliminar</button></td>
      </tr>`).join('') || '<tr><td colspan="4" style="text-align:center; padding:16px"><small>Sin proveedores aún</small></td></tr>';
    tbody.querySelectorAll('button[data-action=del]').forEach(b => b.addEventListener('click', async () => {
      const id = b.closest('tr').dataset.id;
      const nombre = b.closest('tr').cells[0].textContent;
      if (!await confirmar(`¿Eliminar proveedor "${nombre}"?`, { peligroso: true })) return;
      await supabase.from('proveedores').delete().eq('id', id);
      await pintar();
    }));
  };
  await pintar();

  back.querySelector('#prov-add').addEventListener('click', async () => {
    const nombre = back.querySelector('#prov-nombre').value.trim();
    if (!nombre) { toast('El nombre es obligatorio', 'warn'); return; }
    const { error } = await supabase.from('proveedores').insert({
      nombre,
      rut: back.querySelector('#prov-rut').value.trim() || null,
      categoria_principal: back.querySelector('#prov-cat').value || null
    });
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    back.querySelector('#prov-nombre').value = '';
    back.querySelector('#prov-rut').value = '';
    toast('Proveedor agregado ✅', 'ok');
    await pintar();
  });
}
