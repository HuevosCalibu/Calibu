// =====================================================================
// Calibú ERP — Gestión de Lotes y Galpones
// Trazabilidad productiva del plantel
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearFecha, escapeHTML, hoyISO, mesActualISO } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';
import { LISTAS } from '../../lib/constantes.js';

let _tab = 'lotes';

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>🐔 Lotes y Galpones</h1><small>Plantel activo, curvas de postura y mortalidades</small></div>
      <div style="display:flex; gap:8px" id="header-acciones"></div>
    </div>
    <div style="display:flex; gap:8px; margin-bottom:16px">
      <button class="btn ghost sm active" data-tab="lotes">🐣 Lotes activos</button>
      <button class="btn ghost sm" data-tab="galpones">🏠 Galpones</button>
      <button class="btn ghost sm" data-tab="produccion">📊 Producción</button>
      <button class="btn ghost sm" data-tab="historial">📋 Historial</button>
    </div>
    <div id="contenido"></div>`;

  root.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
    _tab = b.dataset.tab;
    root.querySelectorAll('[data-tab]').forEach(x => x.classList.toggle('active', x === b));
    cargar(root);
  }));

  await cargar(root);
}

async function cargar(root) {
  const cont = root.querySelector('#contenido');
  const hdr  = root.querySelector('#header-acciones');
  cont.innerHTML = '<div class="empty-state">Cargando...</div>';
  hdr.innerHTML  = '';
  if (_tab === 'lotes')      return renderLotes(root, cont, hdr);
  if (_tab === 'galpones')   return renderGalpones(root, cont, hdr);
  if (_tab === 'produccion') return renderProduccion(root, cont, hdr);
  if (_tab === 'historial')  return renderHistorial(root, cont, hdr);
}

// =====================================================================
// TAB: LOTES ACTIVOS
// =====================================================================
async function renderLotes(root, cont, hdr) {
  hdr.innerHTML = `<button class="btn" id="btn-nuevo-lote">+ Nuevo lote</button>`;
  hdr.querySelector('#btn-nuevo-lote').addEventListener('click', () => modalLote(root, null));

  const { data: lotes, error } = await supabase
    .from('lotes')
    .select('*, galpones:galpon_id(nombre, capacidad_max)')
    .neq('estado', 'terminado')
    .order('fecha_nacimiento', { ascending: false });

  if (error) { cont.innerHTML = `<div class="card"><p style="color:var(--danger)">Error: ${error.message}</p></div>`; return; }
  const rows = lotes || [];

  // KPIs globales
  const totalGallinas = rows.reduce((a, l) => a + (l.gallinas_actuales || 0), 0);
  const lotesPico     = rows.filter(l => l.estado === 'activo_produccion').length;

  cont.innerHTML = `
    <div class="kpi-grid" style="margin-bottom:16px">
      <div class="kpi"><div class="label">Gallinas activas</div><div class="value">${totalGallinas.toLocaleString('es-CL')}</div></div>
      <div class="kpi"><div class="label">Lotes en producción</div><div class="value">${lotesPico}</div></div>
      <div class="kpi"><div class="label">Lotes totales activos</div><div class="value">${rows.length}</div></div>
    </div>
    ${rows.length === 0 ? `<div class="card"><div class="empty-state"><div class="icon">🐔</div><p>No hay lotes activos.<br>Crea el primero con el botón de arriba.</p></div></div>` :
    rows.map(l => tarjetaLote(l)).join('')}`;

  cont.querySelectorAll('[data-action=editar]').forEach(b => {
    b.addEventListener('click', () => {
      const id = b.closest('[data-lote-id]').dataset.loteId;
      const lote = rows.find(l => l.id === id);
      if (lote) modalLote(root, lote);
    });
  });
  cont.querySelectorAll('[data-action=recambio]').forEach(b => {
    b.addEventListener('click', async () => {
      const id = b.closest('[data-lote-id]').dataset.loteId;
      const lote = rows.find(l => l.id === id);
      if (!lote) return;
      if (!await confirmar(`¿Marcar lote ${lote.codigo} para recambio? Esto cambia el estado pero no lo termina.`)) return;
      await supabase.from('lotes').update({ estado: 'recambio' }).eq('id', id);
      toast('Lote marcado para recambio', 'warn');
      await cargar(root);
    });
  });
  cont.querySelectorAll('[data-action=terminar]').forEach(b => {
    b.addEventListener('click', async () => {
      const id = b.closest('[data-lote-id]').dataset.loteId;
      const lote = rows.find(l => l.id === id);
      if (!lote) return;
      if (!await confirmar(`¿Terminar el lote ${lote.codigo}? Quedará en historial y no aparecerá en activos.`, { peligroso: true, textoOk: 'Terminar' })) return;
      await supabase.from('lotes').update({ estado: 'terminado', fecha_termino: hoyISO() }).eq('id', id);
      toast('Lote terminado', 'ok');
      await cargar(root);
    });
  });
  cont.querySelectorAll('[data-action=registrar-prod]').forEach(b => {
    b.addEventListener('click', () => {
      const id = b.closest('[data-lote-id]').dataset.loteId;
      const lote = rows.find(l => l.id === id);
      if (lote) modalProduccion(root, lote);
    });
  });
}

function tarjetaLote(l) {
  const edadDias = Math.floor((Date.now() - new Date(l.fecha_nacimiento)) / 86400000);
  const edadSemanas = Math.floor(edadDias / 7);
  const mortalidad = l.gallinas_ingreso > 0
    ? (((l.gallinas_ingreso - l.gallinas_actuales) / l.gallinas_ingreso) * 100).toFixed(1)
    : '0.0';
  const estadoColor = {
    activo_prueba: 'info',
    activo_produccion: 'ok',
    activo_pre_pico: 'warn',
    recambio: 'danger',
    terminado: 'neutral'
  }[l.estado] || 'neutral';
  const estadoLabel = {
    activo_prueba: 'Prueba / adaptación',
    activo_produccion: 'En producción',
    activo_pre_pico: 'Pre-pico',
    recambio: 'Para recambio',
    terminado: 'Terminado'
  }[l.estado] || l.estado;

  return `
    <div class="card" style="margin-bottom:12px" data-lote-id="${l.id}">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap">
        <div>
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px">
            <strong style="font-size:16px">${escapeHTML(l.codigo)}</strong>
            <span class="badge ${estadoColor}">${estadoLabel}</span>
          </div>
          <div style="font-size:13px; color:var(--text-muted)">
            🏠 ${escapeHTML(l.galpones?.nombre || '—')} · 🐔 ${escapeHTML(l.raza)}
          </div>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap">
          <button class="btn ghost sm" data-action="registrar-prod">+ Producción</button>
          <button class="btn ghost sm" data-action="editar">Editar</button>
          ${l.estado !== 'recambio' ? `<button class="btn ghost sm" data-action="recambio" style="color:var(--warn)">Recambio</button>` : ''}
          <button class="btn ghost sm" data-action="terminar" style="color:var(--danger)">Terminar</button>
        </div>
      </div>
      <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(130px,1fr)); gap:12px; margin-top:16px">
        <div class="kpi" style="padding:8px">
          <div class="label">Edad</div>
          <div class="value" style="font-size:20px">${edadSemanas} sem</div>
          <small>${edadDias} días · nació ${formatearFecha(l.fecha_nacimiento)}</small>
        </div>
        <div class="kpi" style="padding:8px">
          <div class="label">Gallinas actuales</div>
          <div class="value" style="font-size:20px">${(l.gallinas_actuales||0).toLocaleString('es-CL')}</div>
          <small>de ${(l.gallinas_ingreso||0).toLocaleString('es-CL')} en ingreso</small>
        </div>
        <div class="kpi" style="padding:8px">
          <div class="label">Mortalidad acumulada</div>
          <div class="value" style="font-size:20px; color:${parseFloat(mortalidad)>3?'var(--danger)':parseFloat(mortalidad)>1.5?'var(--warn)':'var(--ok)'}">${mortalidad}%</div>
          <small>${(l.gallinas_ingreso - l.gallinas_actuales)} bajas totales</small>
        </div>
        <div class="kpi" style="padding:8px">
          <div class="label">Postura esperada</div>
          <div class="value" style="font-size:20px">${l.postura_esperada_pct != null ? (l.postura_esperada_pct * 100).toFixed(0) + '%' : '—'}</div>
          <small>≈ ${l.postura_esperada_pct != null ? Math.round(l.gallinas_actuales * l.postura_esperada_pct) : '—'} huevos/día</small>
        </div>
      </div>
      ${l.notas ? `<div style="margin-top:10px; font-size:12px; color:var(--text-muted); border-top:1px solid var(--border); padding-top:8px">📝 ${escapeHTML(l.notas)}</div>` : ''}
    </div>`;
}

// =====================================================================
// TAB: GALPONES
// =====================================================================
async function renderGalpones(root, cont, hdr) {
  hdr.innerHTML = `<button class="btn" id="btn-nuevo-galpon">+ Nuevo galpón</button>`;
  hdr.querySelector('#btn-nuevo-galpon').addEventListener('click', () => modalGalpon(root, null));

  const [{ data: galpones }, { data: lotes }] = await Promise.all([
    supabase.from('galpones').select('*').order('nombre'),
    supabase.from('lotes').select('galpon_id, estado, gallinas_actuales').neq('estado', 'terminado')
  ]);

  const rows = galpones || [];
  if (!rows.length) {
    cont.innerHTML = `<div class="card"><div class="empty-state"><div class="icon">🏠</div><p>No hay galpones registrados.</p></div></div>`;
    return;
  }

  const lotesPorGalpon = {};
  (lotes || []).forEach(l => {
    if (!lotesPorGalpon[l.galpon_id]) lotesPorGalpon[l.galpon_id] = [];
    lotesPorGalpon[l.galpon_id].push(l);
  });

  cont.innerHTML = `<div class="card" style="padding:0"><div class="table-wrap"><table class="data">
    <thead><tr>
      <th>Galpón</th><th class="num">Capacidad</th><th class="num">M² galpón</th>
      <th class="num">M² patio</th><th class="num">Lotes activos</th>
      <th class="num">Gallinas actuales</th><th>Ocupación</th><th class="actions">Acciones</th>
    </tr></thead>
    <tbody>
    ${rows.map(g => {
      const lotesG = lotesPorGalpon[g.id] || [];
      const gallinas = lotesG.reduce((a, l) => a + (l.gallinas_actuales || 0), 0);
      const ocupPct = g.capacidad_max > 0 ? Math.round((gallinas / g.capacidad_max) * 100) : 0;
      const colorOcup = ocupPct > 90 ? 'var(--danger)' : ocupPct > 70 ? 'var(--warn)' : 'var(--ok)';
      return `<tr data-galpon-id="${g.id}">
        <td><strong>${escapeHTML(g.nombre)}</strong></td>
        <td class="num">${g.capacidad_max?.toLocaleString('es-CL') || '—'}</td>
        <td class="num">${g.m2_galpon ? g.m2_galpon + ' m²' : '—'}</td>
        <td class="num">${g.m2_patio ? g.m2_patio + ' m²' : '—'}</td>
        <td class="num">${lotesG.length}</td>
        <td class="num">${gallinas.toLocaleString('es-CL')}</td>
        <td>
          <div style="display:flex; align-items:center; gap:8px">
            <div style="flex:1; background:var(--border); height:8px; border-radius:999px; overflow:hidden; min-width:60px">
              <div style="background:${colorOcup}; height:100%; width:${Math.min(ocupPct,100)}%"></div>
            </div>
            <span style="font-size:12px; color:${colorOcup}; font-weight:600">${ocupPct}%</span>
          </div>
        </td>
        <td class="actions">
          <button class="btn ghost sm" data-action="editar-galpon">Editar</button>
        </td>
      </tr>`;
    }).join('')}
    </tbody>
  </table></div></div>`;

  cont.querySelectorAll('[data-action=editar-galpon]').forEach(b => {
    b.addEventListener('click', () => {
      const id = b.closest('[data-galpon-id]').dataset.galponId;
      const g = rows.find(x => x.id === id);
      if (g) modalGalpon(root, g);
    });
  });
}

// =====================================================================
// TAB: PRODUCCIÓN (últimos 30 días por lote)
// =====================================================================
async function renderProduccion(root, cont, hdr) {
  const hoy = hoyISO();
  const hace30 = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);

  hdr.innerHTML = `
    <input type="date" id="prod-desde" value="${hace30}" style="padding:6px 10px; border:1px solid var(--border-fuerte); border-radius:6px">
    <input type="date" id="prod-hasta" value="${hoy}" style="padding:6px 10px; border:1px solid var(--border-fuerte); border-radius:6px">`;

  const cargarProd = async () => {
    const desde = root.querySelector('#prod-desde').value;
    const hasta = root.querySelector('#prod-hasta').value;
    const [{ data: prod }, { data: lotes }] = await Promise.all([
      supabase.from('produccion_diaria')
        .select('*, lotes:lote_id(codigo, raza, gallinas_actuales, galpones:galpon_id(nombre))')
        .gte('fecha', desde).lte('fecha', hasta)
        .order('fecha', { ascending: false }),
      supabase.from('lotes').select('id, codigo, gallinas_actuales').neq('estado', 'terminado')
    ]);
    const rows = prod || [];
    const totalHuevos   = rows.reduce((a, r) => a + (r.huevos_enteros || 0), 0);
    const totalRotos    = rows.reduce((a, r) => a + (r.huevos_rotos || 0), 0);
    const totalBajas    = rows.reduce((a, r) => a + (r.mortalidades || 0), 0);
    const diasConReg    = new Set(rows.map(r => r.fecha)).size;

    cont.querySelector('#prod-kpis').innerHTML = `
      <div class="kpi-grid" style="margin-bottom:16px">
        <div class="kpi"><div class="label">Huevos enteros</div><div class="value">${totalHuevos.toLocaleString('es-CL')}</div><small>${diasConReg} días con registro</small></div>
        <div class="kpi"><div class="label">Huevos rotos</div><div class="value" style="color:var(--warn)">${totalRotos.toLocaleString('es-CL')}</div><small>${totalHuevos > 0 ? ((totalRotos/totalHuevos)*100).toFixed(1) : '0'}% pérdida</small></div>
        <div class="kpi"><div class="label">Bajas totales</div><div class="value" style="color:var(--danger)">${totalBajas}</div><small>en el período</small></div>
        <div class="kpi"><div class="label">Prom. diario</div><div class="value">${diasConReg > 0 ? Math.round(totalHuevos / diasConReg).toLocaleString('es-CL') : '—'}</div><small>huevos/día</small></div>
      </div>`;

    cont.querySelector('#prod-tabla tbody').innerHTML = rows.length ? rows.map(r => {
      const gallinas = r.lotes?.gallinas_actuales || 0;
      const postura = gallinas > 0 ? ((r.huevos_enteros / gallinas) * 100).toFixed(1) : '—';
      const posturaNum = gallinas > 0 ? r.huevos_enteros / gallinas : 0;
      const posturaColor = posturaNum >= 0.80 ? 'var(--ok)' : posturaNum >= 0.65 ? 'var(--warn)' : posturaNum > 0 ? 'var(--danger)' : 'var(--text-muted)';
      return `<tr>
        <td>${formatearFecha(r.fecha)}</td>
        <td><strong>${escapeHTML(r.lotes?.codigo || '—')}</strong><br><small style="color:var(--text-muted)">${escapeHTML(r.lotes?.galpones?.nombre || '')}</small></td>
        <td class="num">${(r.huevos_enteros||0).toLocaleString('es-CL')}</td>
        <td class="num" style="color:var(--warn)">${r.huevos_rotos||0}</td>
        <td class="num" style="font-weight:700; color:${posturaColor}">${postura}%</td>
        <td class="num" style="color:${r.mortalidades>0?'var(--danger)':'var(--text-muted)'}">${r.mortalidades||0}${r.causa_mortalidad ? '<br><small>' + escapeHTML(r.causa_mortalidad) + '</small>' : ''}</td>
        <td style="font-size:var(--fs-xs); color:var(--text-muted)">${escapeHTML(r.observaciones||'')}</td>
      </tr>`;
    }).join('') : '<tr><td colspan="7" style="text-align:center;padding:24px">Sin registros en el período</td></tr>';
  };

  cont.innerHTML = `
    <div id="prod-kpis"></div>
    <div class="card" style="padding:0">
      <div class="table-wrap">
        <table class="data" id="prod-tabla">
          <thead><tr>
            <th>Fecha</th><th>Lote / Galpón</th>
            <th class="num">Enteros</th><th class="num">Rotos</th>
            <th class="num">% postura</th><th class="num">Bajas</th><th>Observaciones</th>
          </tr></thead>
          <tbody><tr><td colspan="7" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
        </table>
      </div>
    </div>`;

  root.querySelector('#prod-desde').addEventListener('change', cargarProd);
  root.querySelector('#prod-hasta').addEventListener('change', cargarProd);
  await cargarProd();
}

// =====================================================================
// TAB: HISTORIAL (lotes terminados)
// =====================================================================
async function renderHistorial(root, cont, hdr) {
  const { data: lotes } = await supabase
    .from('lotes')
    .select('*, galpones:galpon_id(nombre)')
    .eq('estado', 'terminado')
    .order('fecha_termino', { ascending: false });

  const rows = lotes || [];
  if (!rows.length) {
    cont.innerHTML = `<div class="card"><div class="empty-state"><div class="icon">📋</div><p>No hay lotes terminados aún.</p></div></div>`;
    return;
  }

  cont.innerHTML = `<div class="card" style="padding:0"><div class="table-wrap"><table class="data">
    <thead><tr>
      <th>Código</th><th>Galpón</th><th>Raza</th><th>Ingreso</th>
      <th class="num">Gallinas inicio</th><th class="num">Gallinas final</th>
      <th class="num">Mortalidad</th><th>Nacimiento</th><th>Término</th>
    </tr></thead>
    <tbody>
    ${rows.map(l => {
      const mort = l.gallinas_ingreso > 0 ? (((l.gallinas_ingreso - l.gallinas_actuales) / l.gallinas_ingreso) * 100).toFixed(1) : '0.0';
      const edadTerm = l.fecha_termino && l.fecha_nacimiento
        ? Math.floor((new Date(l.fecha_termino) - new Date(l.fecha_nacimiento)) / 86400000)
        : null;
      return `<tr>
        <td><strong>${escapeHTML(l.codigo)}</strong></td>
        <td>${escapeHTML(l.galpones?.nombre || '—')}</td>
        <td>${escapeHTML(l.raza)}</td>
        <td>${formatearFecha(l.fecha_nacimiento)}</td>
        <td class="num">${(l.gallinas_ingreso||0).toLocaleString('es-CL')}</td>
        <td class="num">${(l.gallinas_actuales||0).toLocaleString('es-CL')}</td>
        <td class="num" style="color:${parseFloat(mort)>5?'var(--danger)':parseFloat(mort)>3?'var(--warn)':'var(--ok)'}">${mort}%</td>
        <td>${formatearFecha(l.fecha_nacimiento)}</td>
        <td>${formatearFecha(l.fecha_termino)}${edadTerm ? '<br><small style="color:var(--text-muted)">' + Math.floor(edadTerm/7) + ' semanas</small>' : ''}</td>
      </tr>`;
    }).join('')}
    </tbody>
  </table></div></div>`;
}

// =====================================================================
// MODALES
// =====================================================================
async function modalLote(root, lote) {
  const esNuevo = !lote;
  const l = lote || {};
  const { data: galpones } = await supabase.from('galpones').select('id, nombre').order('nombre');

  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-lote" style="max-width:600px">
      <div class="modal-header">
        <h2>${esNuevo ? 'Nuevo lote' : 'Editar lote ' + escapeHTML(l.codigo)}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div class="form-grid">
        <div class="field">
          <label>Código del lote *</label>
          <input name="codigo" required value="${escapeHTML(l.codigo || '')}" placeholder="Ej: L-2024-01">
        </div>
        <div class="field">
          <label>Galpón *</label>
          <select name="galpon_id" required>
            <option value="">—</option>
            ${(galpones || []).map(g => `<option value="${g.id}" ${l.galpon_id === g.id ? 'selected' : ''}>${escapeHTML(g.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Raza *</label>
          <input name="raza" required value="${escapeHTML(l.raza || '')}" placeholder="Ej: Lohmann Brown">
        </div>
        <div class="field">
          <label>Fecha de nacimiento *</label>
          <input type="date" name="fecha_nacimiento" required value="${l.fecha_nacimiento || ''}">
        </div>
        <div class="field">
          <label>Gallinas en ingreso *</label>
          <input type="number" name="gallinas_ingreso" required min="1" value="${l.gallinas_ingreso || ''}">
        </div>
        <div class="field">
          <label>Gallinas actuales</label>
          <input type="number" name="gallinas_actuales" min="0" value="${l.gallinas_actuales || l.gallinas_ingreso || ''}">
          <div class="hint">Se actualiza automáticamente con mortalidades diarias</div>
        </div>
        <div class="field">
          <label>Postura esperada (%)</label>
          <input type="number" name="postura_esperada_pct" min="0" max="100" step="0.1" value="${l.postura_esperada_pct != null ? (l.postura_esperada_pct * 100).toFixed(1) : ''}">
          <div class="hint">Ej: 85 = 85% de postura esperada al pico</div>
        </div>
        <div class="field">
          <label>Estado</label>
          <select name="estado">
            ${LISTAS.ESTADOS_LOTE.map(e => `<option value="${e}" ${(l.estado || 'activo_prueba') === e ? 'selected' : ''}>${{
              activo_prueba: 'Prueba / adaptación',
              activo_produccion: 'En producción',
              activo_pre_pico: 'Pre-pico',
              recambio: 'Para recambio',
              terminado: 'Terminado'
            }[e]}</option>`).join('')}
          </select>
        </div>
        <div class="field" style="grid-column:1/-1">
          <label>Notas</label>
          <textarea name="notas" rows="2">${escapeHTML(l.notas || '')}</textarea>
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">${esNuevo ? 'Crear lote' : 'Guardar'}</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  back.querySelector('#form-lote').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const postPct = fd.get('postura_esperada_pct');
    const payload = {
      codigo: fd.get('codigo'),
      galpon_id: fd.get('galpon_id'),
      raza: fd.get('raza'),
      fecha_nacimiento: fd.get('fecha_nacimiento'),
      gallinas_ingreso: parseInt(fd.get('gallinas_ingreso'), 10),
      gallinas_actuales: parseInt(fd.get('gallinas_actuales') || fd.get('gallinas_ingreso'), 10),
      postura_esperada_pct: postPct ? parseFloat(postPct) / 100 : null,
      estado: fd.get('estado'),
      notas: fd.get('notas') || null,
    };
    const { error } = esNuevo
      ? await supabase.from('lotes').insert(payload)
      : await supabase.from('lotes').update(payload).eq('id', l.id);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(esNuevo ? 'Lote creado' : 'Lote actualizado', 'ok');
    back.remove();
    await cargar(root);
  });
}

async function modalGalpon(root, galpon) {
  const esNuevo = !galpon;
  const g = galpon || {};
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-galpon" style="max-width:480px">
      <div class="modal-header">
        <h2>${esNuevo ? 'Nuevo galpón' : 'Editar ' + escapeHTML(g.nombre)}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1">
          <label>Nombre del galpón *</label>
          <input name="nombre" required value="${escapeHTML(g.nombre || '')}" placeholder="Ej: Galpón 1, Galpón Norte">
        </div>
        <div class="field"><label>Capacidad máxima (gallinas)</label><input type="number" name="capacidad_max" min="0" value="${g.capacidad_max || ''}"></div>
        <div class="field"><label>M² galpón</label><input type="number" name="m2_galpon" min="0" step="0.01" value="${g.m2_galpon || ''}"></div>
        <div class="field" style="grid-column:1/-1"><label>M² patio / pastoreo</label><input type="number" name="m2_patio" min="0" step="0.01" value="${g.m2_patio || ''}"></div>
        <div class="field" style="grid-column:1/-1">
          <label>Notas</label>
          <textarea name="notas" rows="2">${escapeHTML(g.notas || '')}</textarea>
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">${esNuevo ? 'Crear galpón' : 'Guardar'}</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  back.querySelector('#form-galpon').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = {
      nombre: fd.get('nombre'),
      capacidad_max: fd.get('capacidad_max') ? parseInt(fd.get('capacidad_max'), 10) : null,
      m2_galpon: fd.get('m2_galpon') ? parseFloat(fd.get('m2_galpon')) : null,
      m2_patio: fd.get('m2_patio') ? parseFloat(fd.get('m2_patio')) : null,
      notas: fd.get('notas') || null,
    };
    const { error } = esNuevo
      ? await supabase.from('galpones').insert(payload)
      : await supabase.from('galpones').update(payload).eq('id', g.id);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(esNuevo ? 'Galpón creado' : 'Galpón actualizado', 'ok');
    back.remove();
    await cargar(root);
  });
}

async function modalProduccion(root, lote) {
  const hoy = hoyISO();
  // Buscar si ya existe registro hoy
  const { data: existente } = await supabase.from('produccion_diaria')
    .select('*').eq('lote_id', lote.id).eq('fecha', hoy).maybeSingle();
  const p = existente || {};

  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-prod" style="max-width:480px">
      <div class="modal-header">
        <h2>Registrar producción — ${escapeHTML(lote.codigo)}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div style="background:var(--surface-2); border-radius:8px; padding:10px 12px; margin-bottom:14px; font-size:13px">
        🐔 ${(lote.gallinas_actuales||0).toLocaleString('es-CL')} gallinas actuales
        ${lote.postura_esperada_pct != null ? ` · Postura esperada: ${(lote.postura_esperada_pct*100).toFixed(0)}% (≈${Math.round(lote.gallinas_actuales*lote.postura_esperada_pct)} huevos)` : ''}
      </div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1"><label>Fecha *</label><input type="date" name="fecha" value="${hoy}" max="${hoy}" required></div>
        <div class="field">
          <label>Huevos enteros *</label>
          <input type="number" name="huevos_enteros" required min="0" value="${p.huevos_enteros ?? ''}">
        </div>
        <div class="field">
          <label>Huevos rotos</label>
          <input type="number" name="huevos_rotos" min="0" value="${p.huevos_rotos ?? 0}">
        </div>
        <div class="field">
          <label>Mortalidades</label>
          <input type="number" name="mortalidades" min="0" value="${p.mortalidades ?? 0}" id="inp-mort">
        </div>
        <div class="field" id="causa-wrap" style="${(p.mortalidades||0)>0?'':'display:none'}">
          <label>Causa mortalidad</label>
          <input name="causa_mortalidad" value="${escapeHTML(p.causa_mortalidad||'')}" placeholder="Ej: Enfermedad respiratoria, calor...">
        </div>
        <div class="field" style="grid-column:1/-1">
          <label>Observaciones</label>
          <input name="observaciones" value="${escapeHTML(p.observaciones||'')}" placeholder="Ej: Se cambió alimento, llegó nueva cama...">
        </div>
        <div class="field" style="grid-column:1/-1; background:var(--surface-2); border-radius:8px; padding:10px 12px; font-size:13px">
          % postura hoy: <strong id="preview-postura">—</strong>
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">${existente ? 'Actualizar' : 'Registrar'}</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());

  const inpMort = back.querySelector('#inp-mort');
  const causaWrap = back.querySelector('#causa-wrap');
  const inpEnteros = back.querySelector('[name=huevos_enteros]');
  const previewPost = back.querySelector('#preview-postura');

  const actualizarPreview = () => {
    const enteros = parseInt(inpEnteros.value) || 0;
    const gallinas = lote.gallinas_actuales || 0;
    previewPost.textContent = gallinas > 0 ? ((enteros / gallinas) * 100).toFixed(1) + '%' : '—';
    const pct = gallinas > 0 ? enteros / gallinas : 0;
    previewPost.style.color = pct >= 0.80 ? 'var(--ok)' : pct >= 0.60 ? 'var(--warn)' : 'var(--danger)';
  };
  inpEnteros.addEventListener('input', actualizarPreview);
  actualizarPreview();

  inpMort.addEventListener('input', () => {
    causaWrap.style.display = parseInt(inpMort.value) > 0 ? '' : 'none';
  });

  back.querySelector('#form-prod').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = {
      lote_id: lote.id,
      fecha: fd.get('fecha'),
      huevos_enteros: parseInt(fd.get('huevos_enteros'), 10) || 0,
      huevos_rotos: parseInt(fd.get('huevos_rotos'), 10) || 0,
      mortalidades: parseInt(fd.get('mortalidades'), 10) || 0,
      causa_mortalidad: fd.get('causa_mortalidad') || null,
      observaciones: fd.get('observaciones') || null,
    };
    const { error } = existente
      ? await supabase.from('produccion_diaria').update(payload).eq('id', existente.id)
      : await supabase.from('produccion_diaria').insert(payload);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(existente ? 'Producción actualizada' : 'Producción registrada', 'ok');
    back.remove();
    await cargar(root);
  });
}
