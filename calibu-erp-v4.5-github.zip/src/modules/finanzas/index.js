import { supabase } from '../../lib/supabase.js';
import { formatearCLP, mesActualISO, escapeHTML } from '../../lib/calc.js';

const NOMBRE_MES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Finanzas</h1><small>P&L mensual y márgenes por canal</small></div>
    </div>
    <div class="kpi-grid-rich" id="kpis-fin"></div>
    <div class="dash-row equal">
      <div class="chart-card">
        <h3>Ingresos vs Costos (12 meses)</h3>
        <div class="chart-wrap"><canvas id="ch-pyl"></canvas></div>
      </div>
      <div class="chart-card">
        <h3>Margen mensual</h3>
        <div class="chart-wrap"><canvas id="ch-margen"></canvas></div>
      </div>
    </div>
    <div class="card">
      <h3 class="card-title">P&L mensual detallado</h3>
      <div class="table-wrap"><table class="data" id="tabla-pyl">
        <thead><tr>
          <th>Mes</th>
          <th class="num">Ventas mayorista</th>
          <th class="num">Ventas suscripción</th>
          <th class="num">Ventas directa</th>
          <th class="num">Total ingresos</th>
          <th class="num">Compras netas</th>
          <th class="num">Margen bruto</th>
          <th class="num">%</th>
        </tr></thead>
        <tbody id="pyl-body"></tbody>
      </table></div>
    </div>
  `;

  // Fetch últimos 12 meses
  const desde = new Date();
  desde.setMonth(desde.getMonth() - 11);
  const mesDesde = desde.toISOString().slice(0,7) + '-01';
  const [{ data: ventas }, { data: compras }] = await Promise.all([
    supabase.from('v_resumen_mensual_ventas').select('*').gte('anio_mes', mesDesde.slice(0,7)),
    supabase.from('compras').select('fecha, categoria, total_neto, total_con_iva').gte('fecha', mesDesde)
  ]);

  // Agregar por mes
  const meses = [];
  for (let i = -11; i <= 0; i++) {
    const d = new Date();
    d.setMonth(d.getMonth() + i);
    meses.push(d.toISOString().slice(0,7));
  }

  const data = meses.map(m => {
    const v = (ventas || []).filter(x => x.anio_mes === m);
    const c = (compras || []).filter(x => x.fecha.startsWith(m));
    const mayorista = v.filter(x => x.canal === 'mayorista').reduce((a,x) => a + Number(x.total||0), 0);
    const suscrip = v.filter(x => x.canal === 'suscripcion').reduce((a,x) => a + Number(x.total||0), 0);
    const directa = v.filter(x => x.canal === 'directa').reduce((a,x) => a + Number(x.total||0), 0);
    const ingresos = mayorista + suscrip + directa;
    const costos = c.reduce((a,x) => a + (x.total_neto||0), 0);
    const margen = ingresos - costos;
    const pct = ingresos > 0 ? (margen/ingresos)*100 : 0;
    return { mes: m, mayorista, suscrip, directa, ingresos, costos, margen, pct };
  });

  // KPIs
  const ultMes = data[data.length-1];
  const totalAnual = data.reduce((a,d) => a + d.ingresos, 0);
  const totalCostos = data.reduce((a,d) => a + d.costos, 0);
  const margenAnual = totalAnual - totalCostos;
  root.querySelector('#kpis-fin').innerHTML = `
    <div class="kpi-card"><div class="kpi-icon bg-red">💰</div><div class="kpi-label">Ingresos 12m</div><div class="kpi-value">${formatearCLP(totalAnual)}</div></div>
    <div class="kpi-card"><div class="kpi-icon bg-yellow">🧾</div><div class="kpi-label">Costos 12m</div><div class="kpi-value">${formatearCLP(totalCostos)}</div></div>
    <div class="kpi-card"><div class="kpi-icon bg-green">📈</div><div class="kpi-label">Margen 12m</div><div class="kpi-value">${formatearCLP(margenAnual)}</div><div class="kpi-sub">${totalAnual > 0 ? ((margenAnual/totalAnual)*100).toFixed(1) : 0}%</div></div>
    <div class="kpi-card"><div class="kpi-icon bg-blue">📊</div><div class="kpi-label">Ingresos último mes</div><div class="kpi-value">${formatearCLP(ultMes.ingresos)}</div></div>`;

  // Tabla
  root.querySelector('#pyl-body').innerHTML = data.map(d => {
    const [y,m] = d.mes.split('-');
    const lbl = NOMBRE_MES[parseInt(m,10)-1] + ' ' + y.slice(2);
    return `<tr>
      <td><strong>${lbl}</strong></td>
      <td class="num">${formatearCLP(d.mayorista)}</td>
      <td class="num">${formatearCLP(d.suscrip)}</td>
      <td class="num">${formatearCLP(d.directa)}</td>
      <td class="num" style="font-weight:600">${formatearCLP(d.ingresos)}</td>
      <td class="num">${formatearCLP(d.costos)}</td>
      <td class="num" style="font-weight:600; color: ${d.margen >= 0 ? 'var(--ok)' : 'var(--danger)'}">${formatearCLP(d.margen)}</td>
      <td class="num">${d.pct.toFixed(1)}%</td>
    </tr>`;
  }).join('');

  // Charts
  setTimeout(() => {
    const ctx1 = root.querySelector('#ch-pyl');
    if (ctx1 && window.Chart) {
      new Chart(ctx1, {
        type: 'bar',
        data: {
          labels: data.map(d => { const [y,m] = d.mes.split('-'); return NOMBRE_MES[parseInt(m,10)-1] + ' ' + y.slice(2); }),
          datasets: [
            { label: 'Ingresos', data: data.map(d => d.ingresos), backgroundColor: '#1F8A4C', borderRadius: 4 },
            { label: 'Costos', data: data.map(d => d.costos), backgroundColor: '#C97A00', borderRadius: 4 }
          ]
        },
        options: { responsive: true, maintainAspectRatio: false,
          plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: c => c.dataset.label + ': ' + formatearCLP(c.parsed.y) } } },
          scales: { y: { beginAtZero: true, ticks: { callback: v => '$' + (v/1000).toFixed(0) + 'k' } } } }
      });
    }
    const ctx2 = root.querySelector('#ch-margen');
    if (ctx2 && window.Chart) {
      new Chart(ctx2, {
        type: 'line',
        data: {
          labels: data.map(d => { const [y,m] = d.mes.split('-'); return NOMBRE_MES[parseInt(m,10)-1] + ' ' + y.slice(2); }),
          datasets: [{
            label: 'Margen bruto', data: data.map(d => d.margen),
            borderColor: '#D42B00', backgroundColor: 'rgba(212,43,0,.15)', fill: true, tension: 0.3
          }]
        },
        options: { responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => formatearCLP(c.parsed.y) } } },
          scales: { y: { ticks: { callback: v => '$' + (v/1000).toFixed(0) + 'k' } } } }
      });
    }
  }, 50);
}
