import { supabase } from '../../lib/supabase.js';
import { escapeHTML, hoyISO, formatearFecha } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';

let _vista = 'resumen'; // 'resumen' | 'empleado'

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Checklist operativo</h1><small>Cumplimiento diario de tareas por empleado</small></div>
      <div style="display:flex; gap:8px">
        <button class="btn ghost" id="btn-template">⚙️ Configurar tareas</button>
        <input type="date" id="fecha" value="${hoyISO()}" max="${hoyISO()}" style="padding:8px 10px; border:1px solid var(--border-fuerte); border-radius:6px">
      </div>
    </div>
    <div style="display:flex; gap:8px; margin-bottom:16px">
      <button class="btn ghost sm active" data-tab="resumen">📊 Resumen general</button>
      <button class="btn ghost sm" data-tab="empleado">✅ Marcar por empleado</button>
    </div>
    <div id="resumen"></div>
    <div class="card" style="margin-top:16px; padding:0" id="card-detalle">
      <div style="padding:16px 16px 8px; display:flex; justify-content:space-between; align-items:center">
        <h3 class="card-title" style="margin:0">Detalle por tarea</h3>
        <div id="sel-empleado-wrap" style="display:none">
          <select id="sel-empleado" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
            <option value="">— Seleccionar empleado —</option>
          </select>
        </div>
      </div>
      <div class="table-wrap"><table class="data" id="tabla-detalle">
        <thead id="tabla-thead">
          <tr><th>Orden</th><th>Tarea</th><th>Turno</th><th class="num">Completadas</th><th>Estado</th></tr>
        </thead>
        <tbody id="tbody">
          <tr><td colspan="5" style="text-align:center; padding:24px">Cargando...</td></tr>
        </tbody>
      </table></div>
    </div>`;

  // Cargar empleados para selector
  const { data: empleados } = await supabase.from('empleados').select('id, nombre').eq('estado', 'activo').order('nombre');
  const selEmp = root.querySelector('#sel-empleado');
  (empleados || []).forEach(e => {
    const opt = document.createElement('option');
    opt.value = e.id;
    opt.textContent = e.nombre;
    selEmp.appendChild(opt);
  });

  // Cambio de tab
  root.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
    _vista = b.dataset.tab;
    root.querySelectorAll('[data-tab]').forEach(x => x.classList.toggle('active', x === b));
    const wrap = root.querySelector('#sel-empleado-wrap');
    wrap.style.display = _vista === 'empleado' ? 'block' : 'none';
    // Actualizar cabecera tabla
    const thead = root.querySelector('#tabla-thead');
    if (_vista === 'empleado') {
      thead.innerHTML = '<tr><th>Orden</th><th>Tarea</th><th>Turno</th><th style="text-align:center">Completada</th><th>Hora</th></tr>';
    } else {
      thead.innerHTML = '<tr><th>Orden</th><th>Tarea</th><th>Turno</th><th class="num">Completadas</th><th>Estado</th></tr>';
    }
    cargar(root, empleados || []);
  }));

  root.querySelector('#sel-empleado').addEventListener('change', () => cargar(root, empleados || []));
  root.querySelector('#fecha').addEventListener('change', () => cargar(root, empleados || []));
  root.querySelector('#btn-template').addEventListener('click', () => modalTemplate(root));

  await cargar(root, empleados || []);
}

async function cargar(root, empleados) {
  if (_vista === 'empleado') return pintarEmpleado(root, empleados);
  return pintarResumen(root, empleados);
}

async function pintarResumen(root, empleados) {
  const fecha = root.querySelector('#fecha').value;
  const [tareasRes, logRes] = await Promise.all([
    supabase.from('checklist_template').select('*').eq('activo', true).order('orden'),
    supabase.from('checklist_log').select('*, empleados:empleado_id(nombre)').eq('fecha', fecha),
  ]);
  const tareas = tareasRes.data || [];
  const log = logRes.data || [];

  // Resumen por empleado
  const porEmp = {};
  empleados.forEach(e => { porEmp[e.id] = { nombre: e.nombre, completas: 0 }; });
  log.filter(l => l.completada).forEach(l => { if (porEmp[l.empleado_id]) porEmp[l.empleado_id].completas++; });
  const totalTareas = tareas.length;

  root.querySelector('#resumen').innerHTML = `
    <div class="kpi-grid" style="margin-bottom:16px">
      ${Object.values(porEmp).map(e => {
        const pct = totalTareas > 0 ? Math.round((e.completas / totalTareas) * 100) : 0;
        const color = pct >= 90 ? 'var(--ok)' : pct >= 60 ? 'var(--warn)' : 'var(--danger)';
        return `<div class="kpi">
          <div class="label">${escapeHTML(e.nombre)}</div>
          <div class="value" style="color:${color}">${e.completas}/${totalTareas}</div>
          <small>${pct}% cumplimiento</small>
        </div>`;
      }).join('') || '<div class="empty-state">Sin empleados activos</div>'}
    </div>`;

  const completadasPorTarea = {};
  log.filter(l => l.completada).forEach(l => {
    completadasPorTarea[l.tarea_id] = (completadasPorTarea[l.tarea_id] || 0) + 1;
  });
  const tnames = { mañana: '🌅', tarde: '🌇', noche: '🌙', cualquiera: '📌' };
  const tbody = root.querySelector('#tbody');
  tbody.innerHTML = tareas.map(t => {
    const c = completadasPorTarea[t.id] || 0;
    const total = empleados.length;
    const cls = c === 0 ? 'danger' : c < total ? 'warn' : 'ok';
    return `<tr>
      <td>${t.orden}</td>
      <td><strong>${escapeHTML(t.titulo)}</strong>${t.descripcion ? '<br><small>' + escapeHTML(t.descripcion) + '</small>' : ''}</td>
      <td>${tnames[t.turno] || ''} ${escapeHTML(t.turno || '')}</td>
      <td class="num">${c}/${total}</td>
      <td><span class="badge ${cls}">${c === 0 ? 'pendiente' : c < total ? 'parcial' : 'completado'}</span></td>
    </tr>`;
  }).join('') || '<tr><td colspan="5" style="text-align:center;padding:24px">Sin tareas configuradas</td></tr>';
}

async function pintarEmpleado(root, empleados) {
  const fecha = root.querySelector('#fecha').value;
  const empId = root.querySelector('#sel-empleado').value;
  const tbody = root.querySelector('#tbody');

  if (!empId) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:24px; color:var(--text-muted)">Selecciona un empleado para ver y marcar sus tareas</td></tr>';
    root.querySelector('#resumen').innerHTML = '';
    return;
  }

  const [tareasRes, logRes] = await Promise.all([
    supabase.from('checklist_template').select('*').eq('activo', true).order('orden'),
    supabase.from('checklist_log').select('*').eq('fecha', fecha).eq('empleado_id', empId),
  ]);
  const tareas = tareasRes.data || [];
  const log = logRes.data || [];
  const logMap = {};
  log.forEach(l => { logMap[l.tarea_id] = l; });

  const completas = tareas.filter(t => logMap[t.id]?.completada).length;
  const pct = tareas.length > 0 ? Math.round((completas / tareas.length) * 100) : 0;
  const emp = empleados.find(e => e.id === empId);
  root.querySelector('#resumen').innerHTML = `
    <div class="card" style="padding:12px 16px; margin-bottom:4px; background: var(--surface-2)">
      <div style="display:flex; align-items:center; gap:16px">
        <div><span style="font-weight:600">${escapeHTML(emp?.nombre || '')}</span> — ${formatearFecha(fecha)}</div>
        <div style="font-size:22px; font-weight:800; color:${pct>=90?'var(--ok)':pct>=60?'var(--warn)':'var(--danger)'}">${completas}/${tareas.length} · ${pct}%</div>
        <div style="flex:1; background:var(--border); height:8px; border-radius:999px; overflow:hidden">
          <div style="background:var(--calibu-primario); height:100%; width:${pct}%; transition:.3s"></div>
        </div>
      </div>
    </div>`;

  const tnames = { mañana: '🌅', tarde: '🌇', noche: '🌙', cualquiera: '📌' };
  tbody.innerHTML = tareas.map(t => {
    const l = logMap[t.id];
    const checked = l?.completada ? 'checked' : '';
    const hora = l?.completada && l.hora ? new Date(l.hora).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }) : '—';
    return `<tr data-tarea="${t.id}">
      <td>${t.orden}</td>
      <td>
        <strong style="${l?.completada ? 'text-decoration:line-through;opacity:.6' : ''}">${escapeHTML(t.titulo)}</strong>
        ${t.descripcion ? '<br><small>' + escapeHTML(t.descripcion) + '</small>' : ''}
      </td>
      <td>${tnames[t.turno] || ''} ${escapeHTML(t.turno || '')}</td>
      <td style="text-align:center">
        <input type="checkbox" ${checked} data-action="toggle"
          style="width:20px; height:20px; cursor:pointer; accent-color:var(--calibu-primario)">
      </td>
      <td style="color:var(--text-muted); font-size:var(--fs-xs)">${hora}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="5" style="text-align:center;padding:24px">Sin tareas configuradas</td></tr>';

  tbody.querySelectorAll('input[data-action=toggle]').forEach(chk => {
    chk.addEventListener('change', async (e) => {
      const tareaId = e.target.closest('tr').dataset.tarea;
      const completada = e.target.checked;
      const payload = {
        fecha,
        empleado_id: empId,
        tarea_id: tareaId,
        completada,
        hora: completada ? new Date().toISOString() : null
      };
      const { error } = await supabase.from('checklist_log')
        .upsert(payload, { onConflict: 'fecha,empleado_id,tarea_id' });
      if (error) {
        toast('Error: ' + error.message, 'danger');
        e.target.checked = !completada;
        return;
      }
      toast(completada ? '✓ Marcada' : 'Desmarcada', 'ok', 1500);
      await pintarEmpleado(root, empleados);
    });
  });
}

async function modalTemplate(root) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <div class="modal" style="max-width: 720px">
      <div class="modal-header"><h2>Configurar tareas</h2><button class="modal-close">&times;</button></div>
      <div style="display:flex; gap:6px; margin-bottom:12px; flex-wrap:wrap">
        <input id="t-titulo" placeholder="Nueva tarea..." style="flex:1; min-width:200px; padding:8px; border:1px solid var(--border-fuerte); border-radius:6px">
        <select id="t-turno" style="padding:8px; border:1px solid var(--border-fuerte); border-radius:6px">
          <option value="mañana">🌅 Mañana</option>
          <option value="tarde">🌇 Tarde</option>
          <option value="noche">🌙 Noche</option>
          <option value="cualquiera">📌 Cualquiera</option>
        </select>
        <button class="btn" id="t-add">+ Agregar</button>
      </div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Orden</th><th>Tarea</th><th>Turno</th><th>Activa</th><th class="actions">Acciones</th></tr></thead>
        <tbody id="t-tbody"></tbody>
      </table></div>
    </div>`;
  document.body.appendChild(back);
  const { data: empleados } = await supabase.from('empleados').select('id, nombre').eq('estado', 'activo').order('nombre');
  back.querySelector('.modal-close').addEventListener('click', () => { back.remove(); cargar(root, empleados || []); });
  back.addEventListener('click', (e) => { if (e.target === back) { back.remove(); cargar(root, empleados || []); } });
  const pintarT = async () => {
    const { data } = await supabase.from('checklist_template').select('*').order('orden');
    back.querySelector('#t-tbody').innerHTML = (data || []).map(t => `
      <tr data-id="${t.id}">
        <td>${t.orden}</td>
        <td>${escapeHTML(t.titulo)}</td>
        <td>${escapeHTML(t.turno || '')}</td>
        <td><input type="checkbox" ${t.activo ? 'checked' : ''} data-action="toggle"></td>
        <td class="actions"><button class="btn ghost sm" data-action="del">Eliminar</button></td>
      </tr>`).join('') || '<tr><td colspan="5" style="text-align:center;padding:16px"><small>Sin tareas</small></td></tr>';
    back.querySelectorAll('input[data-action=toggle]').forEach(chk => chk.addEventListener('change', async (e) => {
      await supabase.from('checklist_template').update({ activo: e.target.checked }).eq('id', e.target.closest('tr').dataset.id);
      toast('Actualizado', 'ok', 1500);
    }));
    back.querySelectorAll('button[data-action=del]').forEach(b => b.addEventListener('click', async () => {
      if (await confirmar('¿Eliminar esta tarea? Los registros históricos se mantendrán.', { peligroso: true })) {
        await supabase.from('checklist_template').delete().eq('id', b.closest('tr').dataset.id);
        await pintarT();
      }
    }));
  };
  await pintarT();
  back.querySelector('#t-add').addEventListener('click', async () => {
    const titulo = back.querySelector('#t-titulo').value.trim();
    if (!titulo) { toast('Falta el título', 'warn'); return; }
    const { data } = await supabase.from('checklist_template').select('orden').order('orden', { ascending: false }).limit(1);
    const orden = (data?.[0]?.orden || 0) + 1;
    await supabase.from('checklist_template').insert({ orden, titulo, turno: back.querySelector('#t-turno').value, activo: true });
    back.querySelector('#t-titulo').value = '';
    toast('Tarea agregada', 'ok');
    await pintarT();
  });
}
