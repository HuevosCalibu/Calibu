// =====================================================================
// Calibú ERP — Guías de Despacho (SII-compliant)
// RUT Calibú: 78.139.511-0
// Requisitos: folio correlativo, receptor, ítems, motivo traslado
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, hoyISO } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';

const EMISOR = {
  razon_social: 'Calibú Avícola SpA',
  rut:          '78.139.511-0',
  giro:         'Cría y explotación de aves de corral',
  direccion:    'Sector Pishuinco, Valdivia',
  ciudad:       'Valdivia',
  region:       'Los Ríos',
  telefono:     '',
  email:        'contacto@calibu.cl'
};

const MOTIVOS = ['Venta','Traslado interno','Consignación','Otros'];

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>📋 Guías de Despacho</h1><small>Folio correlativo — SII Chile</small></div>
      <div style="display:flex;gap:8px">
        <button class="btn ghost" id="btn-config">⚙️ Folio inicial</button>
        <button class="btn" id="btn-nueva">+ Nueva guía</button>
      </div>
    </div>

    <div class="kpi-grid" style="margin-bottom:16px" id="kpis-guias"></div>

    <div class="card" style="padding:0">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Folio</th><th>Fecha</th><th>Receptor</th><th>RUT</th>
          <th>Motivo</th><th class="num">Total</th><th>Estado</th>
          <th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="8" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;

  await recargar(root);
  root.querySelector('#btn-nueva').addEventListener('click', () => abrirFormulario(root));
  root.querySelector('#btn-config').addEventListener('click', () => configFolio(root));
}

async function recargar(root) {
  const { data } = await supabase.from('guias_despacho')
    .select('*').order('folio', { ascending: false }).limit(200);
  const rows = data || [];

  // KPIs
  const emitidas = rows.filter(r => r.estado === 'emitida');
  const totalMes = emitidas
    .filter(r => r.fecha >= new Date().toISOString().slice(0,7) + '-01')
    .reduce((a, r) => a + (r.total_bruto || 0), 0);
  root.querySelector('#kpis-guias').innerHTML = [
    ['📋', 'Total emitidas', emitidas.length, ''],
    ['💰', 'Ventas mes c/guía', formatearCLP(totalMes), ''],
    ['🔢', 'Último folio', rows[0]?.folio ?? '—', ''],
    ['🚫', 'Anuladas', rows.filter(r => r.estado === 'anulada').length, '']
  ].map(([ic, lb, vl, sub]) =>
    `<div class="kpi"><div class="label">${lb}</div><div class="value">${vl}</div></div>`
  ).join('');

  const tbody = root.querySelector('#tbody');
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="icon">📋</div>
      <p>Sin guías emitidas</p><small>Crea la primera con el botón "+ Nueva guía"</small></div></td></tr>`;
    return;
  }
  const estColor = { emitida: 'ok', borrador: 'warn', anulada: 'neutral' };
  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td><strong>#${r.folio}</strong></td>
      <td>${formatearFecha(r.fecha)}</td>
      <td>${escapeHTML(r.receptor_nombre)}</td>
      <td><code>${escapeHTML(r.receptor_rut || '—')}</code></td>
      <td>${escapeHTML(r.motivo)}</td>
      <td class="num">${formatearCLP(r.total_bruto)}</td>
      <td><span class="badge ${estColor[r.estado] || 'neutral'}">${r.estado}</span></td>
      <td class="actions">
        <button class="btn ghost sm" data-action="ver">Ver/Imprimir</button>
        ${r.estado === 'emitida' ? `<button class="btn ghost sm" data-action="anular">Anular</button>` : ''}
      </td>
    </tr>`).join('');

  // Listeners
  const viejo = tbody;
  viejo.addEventListener('click', async ev => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.closest('tr').dataset.id;
    const guia = rows.find(r => r.id === id);
    if (btn.dataset.action === 'ver') await verGuia(id);
    if (btn.dataset.action === 'anular') {
      if (await confirmar(`¿Anular guía #${guia.folio}? Esta acción no se puede deshacer.`, { peligroso: true })) {
        await supabase.from('guias_despacho').update({ estado: 'anulada' }).eq('id', id);
        toast('Guía anulada', 'ok');
        await recargar(root);
      }
    }
  });
}

// ── Formulario nueva guía ────────────────────────────────────────────
async function abrirFormulario(root) {
  const [{ data: clientes }, folioData] = await Promise.all([
    supabase.from('clientes').select('id,nombre,rut,canal_principal').order('nombre'),
    proximoFolio()
  ]);
  const folio = folioData;

  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-guia" style="max-width:760px">
      <div class="modal-header">
        <h2>Nueva Guía de Despacho — Folio #${folio}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:0 0 16px">
        <div>
          <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:8px">Emisor</h3>
          <div style="font-size:13px;line-height:1.8;background:var(--surface-2);border-radius:8px;padding:10px 12px">
            <strong>${EMISOR.razon_social}</strong><br>
            RUT: ${EMISOR.rut}<br>
            Giro: ${EMISOR.giro}<br>
            ${EMISOR.direccion}, ${EMISOR.ciudad}
          </div>
        </div>
        <div>
          <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:8px">Datos generales</h3>
          <div class="form-grid" style="grid-template-columns:1fr 1fr;gap:8px">
            <div class="field"><label>Fecha *</label><input type="date" name="fecha" required value="${hoyISO()}"></div>
            <div class="field"><label>Motivo traslado *</label>
              <select name="motivo" required>
                ${MOTIVOS.map(m => `<option value="${m}">${m}</option>`).join('')}
              </select>
            </div>
            <div class="field" style="grid-column:1/-1">
              <label><input type="checkbox" name="emite_factura" checked> Se emitirá factura posterior</label>
            </div>
          </div>
        </div>
      </div>

      <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:10px;border-top:1px solid var(--border);padding-top:16px">Receptor</h3>
      <div class="form-grid" style="gap:8px;margin-bottom:16px">
        <div class="field" style="grid-column:1/-1">
          <label>Cliente (opcional — rellena los campos)</label>
          <select id="sel-cliente">
            <option value="">— Seleccionar cliente existente —</option>
            ${(clientes||[]).filter(c=>c.canal_principal==='mayorista').map(c =>
              `<option value="${c.id}" data-nombre="${escapeHTML(c.nombre||'')}" data-rut="${escapeHTML(c.rut||'')}">
                ${escapeHTML(c.nombre)} ${c.rut?'('+c.rut+')':''}</option>`
            ).join('')}
            <optgroup label="────────────"></optgroup>
            ${(clientes||[]).filter(c=>c.canal_principal!=='mayorista').map(c =>
              `<option value="${c.id}" data-nombre="${escapeHTML(c.nombre||'')}" data-rut="${escapeHTML(c.rut||'')}">
                ${escapeHTML(c.nombre)}</option>`
            ).join('')}
          </select>
        </div>
        <div class="field"><label>Razón social / Nombre *</label><input name="receptor_nombre" required id="inp-recnombre"></div>
        <div class="field"><label>RUT receptor</label><input name="receptor_rut" id="inp-recrut" placeholder="12.345.678-9"></div>
        <div class="field"><label>Giro</label><input name="receptor_giro" id="inp-recgiro"></div>
        <div class="field"><label>Dirección entrega</label><input name="receptor_direccion" id="inp-recdir"></div>
        <div class="field"><label>Ciudad</label><input name="receptor_ciudad" id="inp-recciudad"></div>
        <div class="field"><label>Transportista</label><input name="transportista" placeholder="Nombre conductor"></div>
        <div class="field"><label>Patente vehículo</label><input name="patente_vehiculo" placeholder="AB-CD-12"></div>
      </div>

      <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:10px;border-top:1px solid var(--border);padding-top:16px">Detalle de mercadería</h3>
      <div id="items-container"></div>
      <button type="button" class="btn ghost sm" id="btn-add-item" style="margin-bottom:16px">+ Agregar ítem</button>

      <div style="background:var(--surface-2);border-radius:8px;padding:12px 16px;text-align:right;border-top:1px solid var(--border)">
        <div style="font-size:13px;margin-bottom:4px">Subtotal neto: <strong id="sub-neto">$0</strong></div>
        <div style="font-size:13px;margin-bottom:4px">IVA (19%): <strong id="sub-iva">$0</strong></div>
        <div style="font-size:16px;font-weight:700">Total: <strong id="sub-total" style="color:var(--calibu-primario)">$0</strong></div>
      </div>

      <div class="form-actions" style="justify-content:flex-end;margin-top:16px">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Emitir guía #${folio}</button>
      </div>
    </form>`;
  document.body.appendChild(back);

  const form = back.querySelector('#form-guia');
  // Autocompletar desde cliente seleccionado
  back.querySelector('#sel-cliente').addEventListener('change', e => {
    const opt = e.target.options[e.target.selectedIndex];
    if (opt.value) {
      form.querySelector('#inp-recnombre').value = opt.dataset.nombre;
      form.querySelector('#inp-recrut').value    = opt.dataset.rut;
    }
  });

  // Agregar ítems
  let itemCount = 0;
  function agregarItem(desc = '', qty = 1, precio = 0, unidad = 'bandeja') {
    itemCount++;
    const div = document.createElement('div');
    div.className = 'item-row';
    div.style.cssText = 'display:grid;grid-template-columns:3fr 1fr 1fr 1fr auto;gap:8px;align-items:end;margin-bottom:8px';
    div.dataset.idx = itemCount;
    div.innerHTML = `
      <div class="field"><label style="font-size:11px">Descripción</label>
        <input name="desc_${itemCount}" required value="${escapeHTML(desc)}" placeholder="Ej: Huevos talla L bandeja 30"></div>
      <div class="field"><label style="font-size:11px">Cantidad</label>
        <input type="number" name="qty_${itemCount}" required min="0.01" step="0.5" value="${qty}" style="text-align:right"></div>
      <div class="field"><label style="font-size:11px">Unidad</label>
        <select name="unidad_${itemCount}">
          <option value="bandeja" ${unidad==='bandeja'?'selected':''}>bandeja</option>
          <option value="unidad" ${unidad==='unidad'?'selected':''}>unidad</option>
          <option value="caja" ${unidad==='caja'?'selected':''}>caja</option>
          <option value="kg" ${unidad==='kg'?'selected':''}>kg</option>
        </select></div>
      <div class="field"><label style="font-size:11px">Precio unit. neto</label>
        <input type="number" name="pu_${itemCount}" required min="0" step="100" value="${precio}" style="text-align:right"></div>
      <button type="button" class="btn ghost sm" onclick="this.closest('.item-row').remove();recalcGuia()" style="margin-bottom:0;color:var(--danger)">✕</button>`;
    back.querySelector('#items-container').appendChild(div);
    div.querySelectorAll('input').forEach(i => i.addEventListener('input', recalcGuia));
  }
  // Ítem inicial
  agregarItem('Huevos frescos', 1, 0, 'bandeja');
  back.querySelector('#btn-add-item').addEventListener('click', () => agregarItem());

  function recalcGuia() {
    let neto = 0;
    back.querySelectorAll('.item-row').forEach(row => {
      const idx = row.dataset.idx;
      const qty = parseFloat(row.querySelector(`[name=qty_${idx}]`)?.value || 0);
      const pu  = parseInt(row.querySelector(`[name=pu_${idx}]`)?.value  || 0, 10);
      neto += qty * pu;
    });
    const iva   = Math.round(neto * 0.19);
    const total = neto + iva;
    back.querySelector('#sub-neto').textContent  = formatearCLP(neto);
    back.querySelector('#sub-iva').textContent   = formatearCLP(iva);
    back.querySelector('#sub-total').textContent = formatearCLP(total);
  }
  window.recalcGuia = recalcGuia;

  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    // Armar ítems
    const items = [];
    let neto = 0;
    back.querySelectorAll('.item-row').forEach((row, i) => {
      const idx = row.dataset.idx;
      const desc  = fd.get(`desc_${idx}`)  || '';
      const qty   = parseFloat(fd.get(`qty_${idx}`) || 0);
      const unid  = fd.get(`unidad_${idx}`) || 'bandeja';
      const pu    = parseInt(fd.get(`pu_${idx}`) || 0, 10);
      const tot   = Math.round(qty * pu);
      neto += tot;
      items.push({ orden: i+1, descripcion: desc, cantidad: qty, unidad: unid, precio_unitario: pu, total: tot });
    });
    if (!items.length) { toast('Agrega al menos un ítem', 'warn'); return; }
    const iva   = Math.round(neto * 0.19);
    const total = neto + iva;

    const btn = form.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Emitiendo...';
    const guiaPayload = {
      folio:              folio,
      fecha:              fd.get('fecha'),
      receptor_nombre:    fd.get('receptor_nombre'),
      receptor_rut:       fd.get('receptor_rut') || null,
      receptor_giro:      fd.get('receptor_giro') || null,
      receptor_direccion: fd.get('receptor_direccion') || null,
      receptor_ciudad:    fd.get('receptor_ciudad') || null,
      motivo:             fd.get('motivo'),
      emite_factura:      fd.get('emite_factura') === 'on',
      transportista:      fd.get('transportista') || null,
      patente_vehiculo:   fd.get('patente_vehiculo') || null,
      total_neto:  neto,
      iva:         iva,
      total_bruto: total,
      estado: 'emitida'
    };

    const { data: guia, error } = await supabase.from('guias_despacho').insert(guiaPayload).select().single();
    if (error) { toast('Error: ' + error.message, 'danger'); btn.disabled=false; btn.textContent='Emitir guía #'+folio; return; }
    // Insertar ítems
    await supabase.from('guias_despacho_items').insert(items.map(it => ({ ...it, guia_id: guia.id })));
    toast(`Guía #${folio} emitida ✅`, 'ok');
    back.remove();
    await recargar(root);
    // Abrir vista de impresión
    await verGuia(guia.id);
  });
}

// ── Vista imprimible (ventana nueva) ────────────────────────────────
async function verGuia(id) {
  const [{ data: guia }, { data: items }] = await Promise.all([
    supabase.from('guias_despacho').select('*').eq('id', id).single(),
    supabase.from('guias_despacho_items').select('*').eq('guia_id', id).order('orden')
  ]);
  if (!guia) { toast('Guía no encontrada', 'danger'); return; }

  const win = window.open('', '_blank', 'width=800,height=600');
  const itemsHtml = (items || []).map((it, i) => `
    <tr>
      <td style="text-align:center">${i+1}</td>
      <td>${escapeHTML(it.descripcion)}</td>
      <td style="text-align:center">${it.cantidad}</td>
      <td style="text-align:center">${escapeHTML(it.unidad)}</td>
      <td style="text-align:right">${formatearCLP(it.precio_unitario)}</td>
      <td style="text-align:right"><strong>${formatearCLP(it.total)}</strong></td>
    </tr>`).join('');

  win.document.write(`<!DOCTYPE html><html lang="es"><head>
  <meta charset="UTF-8"><title>Guía de Despacho #${guia.folio}</title>
  <style>
    @page { size: letter; margin: 15mm 18mm; }
    body { font-family: Arial, sans-serif; font-size: 11px; color: #000; margin: 0; }
    .page { max-width: 170mm; margin: 0 auto; }
    h1 { font-size: 16px; text-align: center; margin: 0; }
    .folio-box { border: 3px solid #000; padding: 6px 12px; text-align: center; min-width: 100px; }
    .folio-box .tipo { font-size: 11px; font-weight: bold; }
    .folio-box .num  { font-size: 18px; font-weight: bold; }
    .header-grid { display: grid; grid-template-columns: 1fr auto; gap: 16px; border: 1px solid #999; padding: 10px; margin-bottom: 8px; }
    .emisor-name { font-size: 14px; font-weight: bold; }
    .section { border: 1px solid #999; padding: 8px 10px; margin-bottom: 6px; }
    .section-title { font-size: 10px; font-weight: bold; text-transform: uppercase; color: #666; margin-bottom: 4px; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 16px; }
    .grid3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 4px 12px; }
    .field-row { margin-bottom: 3px; }
    .field-label { font-size: 9px; color: #555; text-transform: uppercase; display: block; }
    .field-val { font-weight: 600; font-size: 11px; border-bottom: 1px solid #ccc; padding-bottom: 1px; min-width: 80px; display: inline-block; }
    table.items { width: 100%; border-collapse: collapse; margin: 6px 0; }
    table.items th { background: #f0f0f0; border: 1px solid #999; padding: 4px 6px; font-size: 10px; text-transform: uppercase; }
    table.items td { border: 1px solid #ccc; padding: 5px 6px; vertical-align: top; }
    .totales { text-align: right; margin-top: 4px; }
    .totales div { margin-bottom: 3px; }
    .total-final { font-size: 14px; font-weight: bold; border-top: 2px solid #000; padding-top: 4px; }
    .firmas { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-top: 16px; }
    .firma-box { border-top: 1px solid #000; padding-top: 4px; text-align: center; font-size: 10px; padding-top: 36px; }
    .anulada-stamp { position: fixed; top: 40%; left: 50%; transform: translate(-50%,-50%) rotate(-30deg);
      font-size: 72px; font-weight: 900; color: rgba(200,0,0,0.25); pointer-events: none; border: 8px solid rgba(200,0,0,0.25);
      padding: 10px 24px; border-radius: 8px; }
    @media print { .no-print { display:none; } }
  </style>
  </head><body>
  <div class="page">
    ${guia.estado === 'anulada' ? '<div class="anulada-stamp">ANULADA</div>' : ''}

    <!-- Encabezado -->
    <div class="header-grid">
      <div>
        <div class="emisor-name">${EMISOR.razon_social}</div>
        <div>RUT: <strong>${EMISOR.rut}</strong></div>
        <div>Giro: ${EMISOR.giro}</div>
        <div>${EMISOR.direccion}</div>
        <div>${EMISOR.ciudad}, Región de ${EMISOR.region}</div>
      </div>
      <div>
        <div class="folio-box">
          <div class="tipo">GUÍA DE DESPACHO</div>
          <div class="tipo">ELECTRÓNICA Nº</div>
          <div class="num">${guia.folio}</div>
          <div style="font-size:10px;margin-top:4px">S.I.I. — ${EMISOR.ciudad}</div>
        </div>
        <div style="text-align:center;margin-top:6px;font-size:11px">
          Fecha: <strong>${formatearFecha(guia.fecha)}</strong>
        </div>
      </div>
    </div>

    <!-- Receptor -->
    <div class="section">
      <div class="section-title">Receptor</div>
      <div class="grid2">
        <div class="field-row">
          <span class="field-label">Señor(es)</span>
          <span class="field-val" style="min-width:200px">${escapeHTML(guia.receptor_nombre)}</span>
        </div>
        <div class="field-row">
          <span class="field-label">RUT</span>
          <span class="field-val">${escapeHTML(guia.receptor_rut || '—')}</span>
        </div>
        <div class="field-row">
          <span class="field-label">Giro</span>
          <span class="field-val" style="min-width:200px">${escapeHTML(guia.receptor_giro || '')}</span>
        </div>
        <div class="field-row">
          <span class="field-label">Ciudad</span>
          <span class="field-val">${escapeHTML(guia.receptor_ciudad || '')}</span>
        </div>
        <div class="field-row" style="grid-column:1/-1">
          <span class="field-label">Dirección</span>
          <span class="field-val" style="min-width:400px">${escapeHTML(guia.receptor_direccion || '')}</span>
        </div>
      </div>
    </div>

    <!-- Traslado -->
    <div class="section">
      <div class="section-title">Traslado</div>
      <div class="grid3">
        <div class="field-row">
          <span class="field-label">Motivo traslado</span>
          <span class="field-val">${escapeHTML(guia.motivo)}</span>
        </div>
        <div class="field-row">
          <span class="field-label">Transportista</span>
          <span class="field-val">${escapeHTML(guia.transportista || '')}</span>
        </div>
        <div class="field-row">
          <span class="field-label">Patente vehículo</span>
          <span class="field-val">${escapeHTML(guia.patente_vehiculo || '')}</span>
        </div>
      </div>
      ${guia.emite_factura ? '<div style="margin-top:6px;font-size:10px;font-style:italic">⚠️ El vendedor declara que se emitirá factura con posterioridad.</div>' : ''}
    </div>

    <!-- Detalle -->
    <table class="items">
      <thead><tr>
        <th style="width:30px">N°</th>
        <th>Descripción del producto o servicio</th>
        <th style="width:60px">Cantidad</th>
        <th style="width:60px">Unidad</th>
        <th style="width:90px">Precio Unit.</th>
        <th style="width:90px">Total</th>
      </tr></thead>
      <tbody>
        ${itemsHtml}
        ${Array(Math.max(0, 5 - (items||[]).length)).fill('<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td></tr>').join('')}
      </tbody>
    </table>

    <!-- Totales -->
    <div class="totales">
      <div>Subtotal Neto: <strong>${formatearCLP(guia.total_neto)}</strong></div>
      <div>IVA (19%): <strong>${formatearCLP(guia.iva)}</strong></div>
      <div class="total-final">TOTAL: ${formatearCLP(guia.total_bruto)}</div>
    </div>

    ${guia.observaciones ? `<div class="section" style="margin-top:8px"><div class="section-title">Observaciones</div>${escapeHTML(guia.observaciones)}</div>` : ''}

    <!-- Firmas -->
    <div class="firmas">
      <div class="firma-box">Firma Emisor<br><small>${EMISOR.razon_social}</small></div>
      <div class="firma-box">Firma Transportista<br><small>${escapeHTML(guia.transportista || '_______________')}</small></div>
      <div class="firma-box">Firma Receptor<br><small>${escapeHTML(guia.receptor_nombre)}</small></div>
    </div>

    <div style="text-align:center;font-size:9px;margin-top:16px;color:#666;border-top:1px solid #ccc;padding-top:6px">
      Timbre Electrónico SII — Verifique en www.sii.cl
    </div>
  </div>
  <div class="no-print" style="text-align:center;padding:16px">
    <button onclick="window.print()" style="padding:12px 28px;background:#D42B00;color:#fff;border:none;border-radius:8px;font-size:15px;cursor:pointer;font-weight:600">🖨️ Imprimir / Guardar PDF</button>
    <button onclick="window.close()" style="padding:12px 20px;background:#f0ede8;border:none;border-radius:8px;font-size:15px;cursor:pointer;margin-left:8px">Cerrar</button>
  </div>
  <script>window.onload=function(){window.print();}<\/script>
  </body></html>`);
  win.document.close();
}

// ── Próximo folio ────────────────────────────────────────────────────
async function proximoFolio() {
  const { data } = await supabase.from('guias_despacho')
    .select('folio').order('folio', { ascending: false }).limit(1);
  return data && data.length ? data[0].folio + 1 : 1;
}

// ── Config folio inicial ─────────────────────────────────────────────
async function configFolio(root) {
  const actual = await proximoFolio();
  const nuevo = prompt(`Próximo folio a usar: ${actual}\n\nIngresa el folio de inicio autorizado por SII\n(deja en blanco para continuar con ${actual}):`);
  if (!nuevo || !nuevo.trim()) return;
  const n = parseInt(nuevo.trim(), 10);
  if (isNaN(n) || n < 1) { toast('Folio inválido', 'warn'); return; }
  // Crear entrada ficticia para forzar el contador (si quieren partir desde N)
  if (n > actual) {
    toast(`Próximo folio configurado: #${n}`, 'ok');
    // Guardar en supuestos
    await supabase.from('supuestos_mensuales')
      .upsert({ anio_mes: '2099-12', concepto: 'folio_guia_proximo', valor: n, notas: 'Folio SII' });
  } else {
    toast('El folio nuevo debe ser mayor al actual', 'warn');
  }
}
