// =====================================================================
// Calibú ERP — Ventas
// Fixes: CSV export, event listener acumulativo, filtro estado_pago
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, mesActualISO, hoyISO } from '../../lib/calc.js';
import { toast, confirmar, badgeEstadoPago, exportarCSV } from '../../lib/ui.js';
import { LISTAS } from '../../lib/constantes.js';

let _filtro = { canal: '', estado: '', desde: '', hasta: '' };
// Guardar filtros en localStorage
function guardarFiltro() { try { localStorage.setItem('filtro_ventas', JSON.stringify(_filtro)); } catch(e) {} }
function restaurarFiltro() {
  try { const f = localStorage.getItem('filtro_ventas'); if (f) _filtro = { ..._filtro, ...JSON.parse(f) }; } catch(e) {}
}

export async function render(root) {
  restaurarFiltro();
  if (!_filtro.desde) _filtro.desde = mesActualISO() + '-01';
  if (!_filtro.hasta) _filtro.hasta = hoyISO();

  root.innerHTML = `
    <div class="section-header">
      <div><h1>Ventas</h1><small>Registro y seguimiento</small></div>
      <div style="display:flex; gap:8px">
        <button class="btn ghost" id="btn-csv">📥 CSV</button>
        <button class="btn" id="btn-nueva">+ Nueva venta</button>
      </div>
    </div>

    <div class="card" style="margin-bottom:16px; padding:12px 16px">
      <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap">
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Desde</label><br>
          <input type="date" id="desde" value="${_filtro.desde}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Hasta</label><br>
          <input type="date" id="hasta" value="${_filtro.hasta}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Canal</label><br>
          <select id="canal" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
            <option value="">Todos</option>
            ${LISTAS.CANALES_VENTA.map(c => `<option value="${c}" ${_filtro.canal === c ? 'selected' : ''}>${c}</option>`).join('')}
          </select>
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Estado pago</label><br>
          <select id="estado" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
            <option value="">Todos</option>
            ${LISTAS.ESTADOS_PAGO.map(e => `<option value="${e}" ${_filtro.estado === e ? 'selected' : ''}>${e}</option>`).join('')}
          </select>
        </div>
        <div style="margin-left:auto" id="resumen-mini"></div>
      </div>
    </div>

    <div class="card" style="padding:0">
      <div class="table-wrap">
        <table class="data">
          <thead><tr>
            <th>Fecha</th><th>Cliente</th><th>Canal</th><th>Bandejas</th>
            <th class="num"># huevos</th><th class="num">Total</th>
            <th>Estado</th><th>Medio</th><th class="actions">Acciones</th>
          </tr></thead>
          <tbody id="tbody">
            <tr><td colspan="9" style="text-align:center; padding:24px">Cargando...</td></tr>
          </tbody>
        </table>
      </div>
    </div>`;

  ['desde', 'hasta', 'canal', 'estado'].forEach(id => {
    root.querySelector('#' + id).addEventListener('change', e => {
      _filtro[id] = e.target.value;
      guardarFiltro();
      recargar(root);
    });
  });

  root.querySelector('#btn-nueva').addEventListener('click', () => abrirFormulario(root));
  root.querySelector('#btn-csv').addEventListener('click', () => exportarTabla(root));

  await recargar(root);
}

// Evitar listeners acumulativos con clone+replace
function reemplazarTbody(root) {
  const viejo = root.querySelector('#tbody');
  const nuevo = viejo.cloneNode(false);
  viejo.parentNode.replaceChild(nuevo, viejo);
  return nuevo;
}

async function recargar(root) {
  let q = supabase.from('ventas')
    .select('*, clientes:cliente_id(nombre)')
    .gte('fecha', _filtro.desde)
    .lte('fecha', _filtro.hasta);
  if (_filtro.canal)  q = q.eq('canal', _filtro.canal);
  if (_filtro.estado) q = q.eq('estado_pago', _filtro.estado);
  q = q.order('fecha', { ascending: false }).limit(500);

  const { data, error } = await q;
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  const rows = data || [];

  // KPI mini
  const noAnuladas = rows.filter(r => r.estado_pago !== 'anulado');
  const totalMes    = noAnuladas.reduce((a, r) => a + (r.total || 0), 0);
  const huevos      = noAnuladas.reduce((a, r) => a + (r.n_huevos || 0), 0);
  const pendiente   = rows.filter(r => ['pendiente', 'vencido'].includes(r.estado_pago))
                          .reduce((a, r) => a + (r.total || 0), 0);
  const ticketProm  = noAnuladas.length > 0 ? totalMes / noAnuladas.length : 0;

  root.querySelector('#resumen-mini').innerHTML = `
    <div style="text-align:right; display:flex; gap:20px; flex-wrap:wrap; justify-content:flex-end">
      <div><div style="font-size:11px;color:var(--text-muted);text-transform:uppercase">Total</div>
           <div style="font-weight:700;font-size:16px">${formatearCLP(totalMes)}</div></div>
      <div><div style="font-size:11px;color:var(--text-muted);text-transform:uppercase">Ticket prom.</div>
           <div style="font-weight:700;font-size:16px">${formatearCLP(ticketProm)}</div></div>
      <div><div style="font-size:11px;color:var(--text-muted);text-transform:uppercase">Huevos</div>
           <div style="font-weight:700;font-size:16px">${huevos.toLocaleString('es-CL')}</div></div>
      <div><div style="font-size:11px;color:var(--text-muted);text-transform:uppercase">Por cobrar</div>
           <div style="font-weight:700;font-size:16px;color:${pendiente > 0 ? 'var(--warn)' : 'inherit'}">${formatearCLP(pendiente)}</div></div>
    </div>`;

  const tbody = reemplazarTbody(root);
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="9">
      <div class="empty-state"><div class="icon">💰</div>
        <p>Sin ventas en el período</p>
        <button class="btn" id="btn-nueva-empty">+ Registrar venta</button>
      </div></td></tr>`;
    tbody.querySelector('#btn-nueva-empty')?.addEventListener('click', () => abrirFormulario(root));
    return;
  }

  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td>${formatearFecha(r.fecha)}</td>
      <td>${escapeHTML(r.clientes?.nombre || '—')}</td>
      <td><span class="badge ${r.canal === 'mayorista' ? 'danger' : r.canal === 'suscripcion' ? 'info' : 'ok'}">${escapeHTML(r.canal)}</span></td>
      <td>${r.n_bandejas} × ${r.tipo_bandeja}${r.tamano_huevo ? ' ' + r.tamano_huevo : ''}</td>
      <td class="num">${(r.n_huevos || 0).toLocaleString('es-CL')}</td>
      <td class="num" style="font-weight:600">${formatearCLP(r.total)}</td>
      <td>${badgeEstadoPago(r.estado_pago)}</td>
      <td>${escapeHTML(r.medio_pago || '—')}</td>
      <td class="actions">
        ${r.estado_pago === 'pendiente' ? `<button class="btn ghost sm" data-action="pagar" data-id="${r.id}">Cobrar</button>` : ''}
        <button class="btn ghost sm" data-action="del" data-id="${r.id}">Eliminar</button>
      </td>
    </tr>`).join('');

  tbody.addEventListener('click', async ev => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.dataset.id;
    if (btn.dataset.action === 'pagar') {
      const { error } = await supabase.from('ventas').update({ estado_pago: 'pagado', fecha_pago: hoyISO() }).eq('id', id);
      if (error) { toast('Error: ' + error.message, 'danger'); return; }
      toast('Venta marcada pagada ✅', 'ok');
      await recargar(root);
    } else if (btn.dataset.action === 'del') {
      const fila = btn.closest('tr');
      const cliente = fila.cells[1].textContent;
      const total   = fila.cells[5].textContent;
      if (!await confirmar(`¿Eliminar venta de ${cliente} por ${total}?`, { peligroso: true })) return;
      const { error } = await supabase.from('ventas').delete().eq('id', id);
      if (error) { toast('Error: ' + error.message, 'danger'); return; }
      toast('Venta eliminada', 'ok');
      await recargar(root);
    }
  });
}

function exportarTabla(root) {
  // Recolectar datos actuales del tbody
  const filas = [...root.querySelectorAll('#tbody tr[data-id]')].map(tr => ({
    fecha:    tr.cells[0].textContent,
    cliente:  tr.cells[1].textContent,
    canal:    tr.cells[2].textContent.trim(),
    bandejas: tr.cells[3].textContent,
    huevos:   tr.cells[4].textContent,
    total:    tr.cells[5].textContent,
    estado:   tr.cells[6].textContent.trim(),
    medio:    tr.cells[7].textContent
  }));
  if (!filas.length) { toast('No hay datos para exportar', 'warn'); return; }
  exportarCSV('ventas_calibu.csv', [
    { key: 'fecha',    label: 'Fecha' },
    { key: 'cliente',  label: 'Cliente' },
    { key: 'canal',    label: 'Canal' },
    { key: 'bandejas', label: 'Bandejas' },
    { key: 'huevos',   label: 'N° huevos' },
    { key: 'total',    label: 'Total' },
    { key: 'estado',   label: 'Estado pago' },
    { key: 'medio',    label: 'Medio de pago' }
  ], filas);
  toast(`${filas.length} filas exportadas ✅`, 'ok');
}

async function abrirFormulario(root) {
  const [{ data: clientes }, { data: planes }] = await Promise.all([
    supabase.from('clientes').select('id, nombre, canal_principal').order('nombre'),
    supabase.from('planes').select('id, nombre, tipo, tamano_huevo, huevos_bandeja, precio_entrega, precio_con_iva').order('nombre')
  ]);
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-venta" style="max-width:640px">
      <div class="modal-header"><h2>Nueva venta</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field"><label>Fecha *</label><input type="date" name="fecha" required value="${hoyISO()}"></div>
        <div class="field">
          <label>Cliente *</label>
          <select name="cliente_id" required>
            <option value="">— Selecciona —</option>
            ${(clientes || []).map(c => `<option value="${c.id}">${escapeHTML(c.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Canal *</label>
          <select name="canal" required>
            ${LISTAS.CANALES_VENTA.map(c => `<option value="${c}">${c}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Plan (opcional)</label>
          <select name="plan_id" id="plan-sel">
            <option value="">—</option>
            ${(planes || []).map(p => `<option value="${p.id}" data-precio="${p.precio_con_iva || p.precio_entrega || 0}" data-tamano="${p.tamano_huevo || ''}" data-huevos="${p.huevos_bandeja || 30}" data-bands="${p.bandejas_entrega || p.bandejas_mes || ''}">${escapeHTML(p.nombre)}${p.tamano_huevo ? ' (' + p.tamano_huevo + ')' : ''} ${(p.precio_con_iva||p.precio_entrega) ? '— $' + (p.precio_con_iva||p.precio_entrega).toLocaleString('es-CL') + '/bdj' : ''}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Tipo bandeja (huevos) *</label>
          <select name="tipo_bandeja" required>
            ${LISTAS.TIPOS_BANDEJA.map(b => `<option value="${b}">${b} huevos</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>N° bandejas *</label><input type="number" name="n_bandejas" required min="1" step="1" value="1"></div>
        <div class="field">
          <label>Tamaño huevo</label>
          <select name="tamano_huevo">
            <option value="">—</option>
            ${LISTAS.TAMANOS_HUEVO.map(t => `<option value="${t}">${t}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Precio unitario (CLP) *</label><input type="number" name="precio_unitario" required min="0" step="1" id="precio-input"></div>
        <div class="field">
          <label>Estado pago *</label>
          <select name="estado_pago" required>
            ${LISTAS.ESTADOS_PAGO.filter(x => x !== 'anulado').map(e => `<option value="${e}">${e}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Medio de pago</label>
          <select name="medio_pago">
            <option value="">—</option>
            ${LISTAS.MEDIOS_PAGO.map(m => `<option value="${m}">${m}</option>`).join('')}
          </select>
        </div>
        <div class="field" style="grid-column:1/-1">
          <label>Total calculado</label>
          <input type="text" id="total-calc" readonly style="font-weight:700; background:var(--surface-2)">
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Registrar venta</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-venta');
  const recalc = () => {
    const nB = parseFloat(form.n_bandejas.value) || 0;
    const p  = parseFloat(form.precio_unitario.value) || 0;
    form.querySelector('#total-calc').value = formatearCLP(nB * p);
  };
  form.n_bandejas.addEventListener('input', recalc);
  form.precio_unitario.addEventListener('input', recalc);
  form.querySelector('#plan-sel').addEventListener('change', e => {
    const opt = e.target.options[e.target.selectedIndex];
    if (opt.value) {
      form.precio_unitario.value = opt.dataset.precio;
      form.tipo_bandeja.value = opt.dataset.huevos;
      if (opt.dataset.tamano) form.tamano_huevo.value = opt.dataset.tamano;
      if (opt.dataset.bands) form.n_bandejas.value = opt.dataset.bands;
      recalc();
    }
  });
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const nB    = parseFloat(fd.get('n_bandejas')) || 1;
    const tipoB = parseInt(fd.get('tipo_bandeja'), 10);
    const precio = parseInt(fd.get('precio_unitario'), 10);
    const payload = {
      fecha:         fd.get('fecha'),
      cliente_id:    fd.get('cliente_id'),
      canal:         fd.get('canal'),
      plan_id:       fd.get('plan_id') || null,
      tipo_bandeja:  tipoB,
      n_bandejas:    nB,
      tamano_huevo:  fd.get('tamano_huevo') || null,
      n_huevos:      Math.round(nB * tipoB),
      precio_unitario: precio,
      total:         Math.round(nB * precio),
      estado_pago:   fd.get('estado_pago'),
      medio_pago:    fd.get('medio_pago') || null,
      fecha_pago:    fd.get('estado_pago') === 'pagado' ? hoyISO() : null
    };
    const btn = form.querySelector('[type=submit]');
    btn.disabled = true; btn.textContent = 'Guardando...';
    const { error } = await supabase.from('ventas').insert(payload);
    if (error) {
      toast('Error: ' + error.message, 'danger');
      btn.disabled = false; btn.textContent = 'Registrar venta';
      return;
    }
    toast('Venta registrada ✅', 'ok');
    back.remove();
    await recargar(root);
  });
}
