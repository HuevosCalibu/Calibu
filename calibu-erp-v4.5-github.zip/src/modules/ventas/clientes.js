import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';
import { LISTAS } from '../../lib/constantes.js';

let _rows = [];
let _filtro = { canal: '', busqueda: '' };

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Clientes</h1><small>Maestro de clientes con ranking por volumen</small></div>
      <button class="btn" id="btn-nuevo">+ Nuevo cliente</button>
    </div>
    <div class="card" style="margin-bottom: 16px; padding: 12px 16px">
      <div style="display:flex; gap: 12px; align-items: center; flex-wrap: wrap">
        <input type="search" id="busqueda" placeholder="Buscar por nombre..." style="flex:1; min-width: 200px; padding: 8px 10px; border: 1px solid var(--border-fuerte); border-radius: 8px">
        <select id="filtro-canal" style="padding: 8px 10px; border: 1px solid var(--border-fuerte); border-radius: 8px">
          <option value="">Todos los canales</option>
          ${LISTAS.CANALES_VENTA.map(c => `<option value="${c}">${c}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="card" style="padding: 0">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Cliente</th><th>Canal</th><th>Teléfono</th><th class="num"># compras</th>
          <th class="num">Total comprado</th><th>Última compra</th>
          <th>Estado</th><th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="8" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  await recargar(root);
  root.querySelector('#btn-nuevo').addEventListener('click', () => abrirFormulario(root, null));
  root.querySelector('#busqueda').addEventListener('input', (e) => {
    _filtro.busqueda = e.target.value.toLowerCase();
    pintar(root);
  });
  root.querySelector('#filtro-canal').addEventListener('change', (e) => {
    _filtro.canal = e.target.value;
    pintar(root);
  });
}

async function recargar(root) {
  const { data, error } = await supabase
    .from('v_top_clientes')
    .select('*')
    .order('total_comprado', { ascending: false });
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  _rows = data || [];
  pintar(root);
}

function pintar(root) {
  const tbody = root.querySelector('#tbody');
  let filtered = _rows;
  if (_filtro.canal) filtered = filtered.filter(c => c.canal_principal === _filtro.canal);
  if (_filtro.busqueda) filtered = filtered.filter(c => (c.nombre || '').toLowerCase().includes(_filtro.busqueda));
  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="icon">👥</div><p>Sin clientes que coincidan</p></div></td></tr>`;
    return;
  }
  tbody.innerHTML = filtered.slice(0, 200).map(c => `
    <tr data-id="${c.id}">
      <td><strong>${escapeHTML(c.nombre)}</strong></td>
      <td><span class="badge ${c.canal_principal==='mayorista'?'danger':c.canal_principal==='suscripcion'?'info':'ok'}">${escapeHTML(c.canal_principal||'—')}</span></td>
      <td>—</td>
      <td class="num">${c.n_compras||0}</td>
      <td class="num">${formatearCLP(c.total_comprado||0)}</td>
      <td>${c.ultima_compra ? formatearFecha(c.ultima_compra) : '—'}</td>
      <td><span class="badge ok">activo</span></td>
      <td class="actions">
        <button class="btn ghost sm" data-action="edit">Editar</button>
        <button class="btn ghost sm" data-action="del">Eliminar</button>
      </td>
    </tr>`).join('');
  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.closest('tr').dataset.id;
    if (btn.dataset.action === 'edit') {
      const { data: cli } = await supabase.from('clientes').select('*').eq('id', id).maybeSingle();
      if (cli) abrirFormulario(root, cli);
    } else if (btn.dataset.action === 'del') {
      if (await confirmar('¿Eliminar este cliente? Sus ventas históricas seguirán pero quedarán huérfanas.', { peligroso: true })) {
        const { error } = await supabase.from('clientes').delete().eq('id', id);
        if (error) toast('Error: ' + error.message, 'danger');
        else { toast('Cliente eliminado', 'ok'); await recargar(root); }
      }
    }
  });
}

function abrirFormulario(root, cliente) {
  const esNuevo = !cliente;
  const c = cliente || {};
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" style="max-width: 620px" id="form-cli">
      <div class="modal-header"><h2>${esNuevo?'Nuevo':'Editar'} cliente</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1"><label>Nombre *</label><input name="nombre" required value="${escapeHTML(c.nombre||'')}"></div>
        <div class="field"><label>RUT</label><input name="rut" value="${escapeHTML(c.rut||'')}"></div>
        <div class="field"><label>Razón social</label><input name="razon_social" value="${escapeHTML(c.razon_social||'')}"></div>
        <div class="field">
          <label>Canal principal</label>
          <select name="canal_principal">
            <option value="">—</option>
            ${LISTAS.CANALES_VENTA.map(x => `<option value="${x}" ${c.canal_principal===x?'selected':''}>${x}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Teléfono</label><input name="telefono" value="${escapeHTML(c.telefono||'')}"></div>
        <div class="field"><label>Email</label><input type="email" name="email" value="${escapeHTML(c.email||'')}"></div>
        <div class="field"><label>Comuna</label><input name="comuna" value="${escapeHTML(c.comuna||'')}"></div>
        <div class="field" style="grid-column:1/-1"><label>Dirección</label><input name="direccion" value="${escapeHTML(c.direccion||'')}"></div>
        <div class="field" style="grid-column:1/-1"><label>Notas</label><textarea name="notas" rows="2">${escapeHTML(c.notas||'')}</textarea></div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">${esNuevo?'Crear':'Guardar'}</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-cli');
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const payload = Object.fromEntries(fd.entries());
    for (const k of Object.keys(payload)) if (payload[k] === '') payload[k] = null;
    const op = esNuevo
      ? supabase.from('clientes').insert(payload)
      : supabase.from('clientes').update(payload).eq('id', c.id);
    const { error } = await op;
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(esNuevo?'Cliente creado':'Cambios guardados', 'ok');
    back.remove();
    await recargar(root);
  });
}
