// Finiquitos — calculadora + registro
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML } from '../../lib/calc.js';
import { calcularFiniquito } from '../../lib/calc.js';
import { CONSTANTES } from '../../lib/constantes.js';
import { toast, confirmar } from '../../lib/ui.js';

let _empleados = [];

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Finiquitos</h1><small>Cálculo según Código del Trabajo</small></div>
      <button class="btn" id="btn-nuevo">+ Nuevo finiquito</button>
    </div>
    <div class="card" style="padding:0">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Fecha término</th><th>Empleado</th><th>Causal</th><th class="num">Años</th>
          <th class="num">IAS</th><th class="num">Aviso previo</th><th class="num">Feriado</th>
          <th class="num">Sueldo prop.</th><th class="num">Total</th><th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="10" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  const { data: emps } = await supabase.from('empleados').select('*');
  _empleados = emps || [];
  await recargar(root);
  root.querySelector('#btn-nuevo').addEventListener('click', () => abrirFormulario(root));
}

async function recargar(root) {
  const { data } = await supabase
    .from('finiquitos')
    .select('*, empleados:empleado_id(id, nombre)')
    .order('fecha_termino', { ascending: false });
  const rows = data || [];
  const tbody = root.querySelector('#tbody');
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="10"><div class="empty-state"><div class="icon">📑</div><p>Sin finiquitos registrados</p></div></td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td>${formatearFecha(r.fecha_termino)}</td>
      <td>${escapeHTML(r.empleados?.nombre || '—')}</td>
      <td title="${escapeHTML(r.causal_descripcion || '')}">${r.causal_articulo}</td>
      <td class="num">${r.anios_servicio}</td>
      <td class="num">${formatearCLP(r.ias)}</td>
      <td class="num">${formatearCLP(r.aviso_previo)}</td>
      <td class="num">${formatearCLP(r.feriado_proporcional)}</td>
      <td class="num">${formatearCLP(r.sueldo_proporcional)}</td>
      <td class="num" style="font-weight:700">${formatearCLP(r.total_a_pagar)}</td>
      <td class="actions"><button class="btn ghost sm" data-action="del">Eliminar</button></td>
    </tr>`).join('');
  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    if (btn.dataset.action === 'del') {
      if (await confirmar('¿Eliminar finiquito?', { peligroso: true })) {
        await supabase.from('finiquitos').delete().eq('id', btn.closest('tr').dataset.id);
        await recargar(root);
      }
    }
  });
}

function abrirFormulario(root) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  const causales = Object.entries(CONSTANTES.CAUSALES_FINIQUITO);
  back.innerHTML = `
    <form class="modal" style="max-width:680px" id="form-fin">
      <div class="modal-header"><h2>Calcular finiquito</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1">
          <label>Empleado *</label>
          <select name="empleado_id" required>
            <option value="">—</option>
            ${_empleados.map(e => `<option value="${e.id}" data-fecha-ingreso="${e.fecha_ingreso||''}" data-sueldo="${e.sueldo_base}">${escapeHTML(e.nombre)} — ${formatearCLP(e.sueldo_base)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Fecha término *</label><input type="date" name="fecha_termino" required value="${new Date().toISOString().slice(0,10)}"></div>
        <div class="field">
          <label>Causal *</label>
          <select name="causal_articulo" required>
            <option value="">—</option>
            ${causales.map(([k,v]) => `<option value="${k}">${k} — ${escapeHTML(v)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Días vacaciones tomados (período)</label><input type="number" name="dias_tomados" min="0" step="0.5" value="0"></div>
        <div class="field"><label>Otros haberes (CLP)</label><input type="number" name="otros_haberes" min="0" step="1000" value="0"></div>
      </div>
      <div id="preview" style="margin-top:20px"></div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="button" class="btn ghost" id="btn-calc">Calcular preview</button>
        <button type="submit" class="btn" id="btn-guardar" disabled>Guardar finiquito</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-fin');
  let calcResult = null;
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());

  back.querySelector('#btn-calc').addEventListener('click', () => {
    const empSel = form.empleado_id.options[form.empleado_id.selectedIndex];
    if (!empSel.value) { toast('Selecciona empleado', 'warn'); return; }
    const emp = {
      sueldo_base: parseInt(empSel.dataset.sueldo, 10),
      fecha_ingreso: empSel.dataset.fechaIngreso
    };
    if (!emp.fecha_ingreso) { toast('Empleado sin fecha de ingreso', 'danger'); return; }
    if (!form.causal_articulo.value) { toast('Selecciona causal', 'warn'); return; }
    calcResult = calcularFiniquito({
      empleado: emp,
      fecha_termino: form.fecha_termino.value,
      causal_articulo: form.causal_articulo.value,
      dias_tomados_periodo: parseFloat(form.dias_tomados.value) || 0,
      otros_haberes: parseInt(form.otros_haberes.value, 10) || 0
    });
    form.querySelector('#preview').innerHTML = `
      <div class="card" style="background: var(--surface-2); margin: 0">
        <h3 style="margin-top:0">Preview del cálculo</h3>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 13px">
          <div>Causal:</div><div><strong>${calcResult.causal_articulo}</strong> — ${escapeHTML(calcResult.causal_descripcion)}</div>
          <div>Años de servicio:</div><div>${calcResult.anios_servicio}</div>
          <div>IAS:</div><div>${formatearCLP(calcResult.ias)} ${calcResult.ias_topeado?'<span class="badge warn">topeado</span>':''}</div>
          <div>Aviso previo (Art. 161):</div><div>${formatearCLP(calcResult.aviso_previo)}</div>
          <div>Feriado proporcional:</div><div>${formatearCLP(calcResult.feriado_proporcional)} (${calcResult.feriado_dias_habiles} días)</div>
          <div>Sueldo proporcional:</div><div>${formatearCLP(calcResult.sueldo_proporcional)}</div>
          <div>Otros haberes:</div><div>${formatearCLP(calcResult.otros_haberes)}</div>
          <div style="border-top:1px solid var(--border); padding-top:8px; font-weight:700">TOTAL:</div>
          <div style="border-top:1px solid var(--border); padding-top:8px; font-weight:700; color: var(--calibu-primario)">${formatearCLP(calcResult.total_a_pagar)}</div>
        </div>
      </div>`;
    form.querySelector('#btn-guardar').disabled = false;
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!calcResult) { toast('Calcula primero', 'warn'); return; }
    const payload = {
      empleado_id: form.empleado_id.value,
      fecha_termino: form.fecha_termino.value,
      causal_articulo: calcResult.causal_articulo,
      causal_descripcion: calcResult.causal_descripcion,
      anios_servicio: calcResult.anios_servicio,
      ias: calcResult.ias,
      ias_topeado: calcResult.ias_topeado,
      feriado_proporcional: calcResult.feriado_proporcional,
      aviso_previo: calcResult.aviso_previo,
      sueldo_proporcional: calcResult.sueldo_proporcional,
      otros_haberes: calcResult.otros_haberes,
      total_a_pagar: calcResult.total_a_pagar
    };
    const { error } = await supabase.from('finiquitos').insert(payload);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    // Marcar empleado como desvinculado
    await supabase.from('empleados').update({ estado: 'desvinculado', fecha_termino: form.fecha_termino.value }).eq('id', form.empleado_id.value);
    toast('Finiquito registrado', 'ok');
    back.remove();
    await recargar(root);
  });
}
