// =====================================================================
// Módulo Empleados — CRUD completo
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearRUT, validarRUT, formatearCLP, escapeHTML, hoyISO } from '../../lib/calc.js';
import { LISTAS } from '../../lib/constantes.js';
import { toast, confirmar, badgeEstadoEmpleado } from '../../lib/ui.js';

let _empleados = [];

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div>
        <h1>Empleados</h1>
        <small>Gestión del equipo de Calibú</small>
      </div>
      <div>
        <button class="btn" id="btn-nuevo">+ Nuevo empleado</button>
      </div>
    </div>

    <div class="card" style="padding: 0">
      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>RUT</th>
              <th>Cargo</th>
              <th>Jornada</th>
              <th class="num">Sueldo base</th>
              <th>AFP</th>
              <th>Estado</th>
              <th class="actions">Acciones</th>
            </tr>
          </thead>
          <tbody id="tbody">
            <tr><td colspan="8" style="text-align:center; padding: 24px">Cargando...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;

  await recargar(root);

  root.querySelector('#btn-nuevo').addEventListener('click', () => abrirFormulario(root, null));
}

async function recargar(root) {
  const { data, error } = await supabase
    .from('empleados')
    .select('*')
    .order('nombre');
  if (error) {
    toast('Error cargando empleados: ' + error.message, 'danger');
    return;
  }
  _empleados = data || [];
  const tbody = root.querySelector('#tbody');
  if (_empleados.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8">
      <div class="empty-state">
        <div class="icon">👥</div>
        <p>Aún no hay empleados registrados.<br>Crea el primero usando el botón de arriba.</p>
      </div>
    </td></tr>`;
    return;
  }
  tbody.innerHTML = _empleados.map(e => `
    <tr data-id="${e.id}">
      <td>
        <div style="font-weight:500">${escapeHTML(e.nombre)}</div>
        <div style="font-size: var(--fs-xs); color: var(--text-muted)">${escapeHTML(e.area || '')}</div>
      </td>
      <td><code>${escapeHTML(formatearRUT(e.rut))}</code></td>
      <td>${escapeHTML(e.cargo || '—')}</td>
      <td>${escapeHTML(legibleJornada(e.tipo_jornada))}</td>
      <td class="num">${formatearCLP(e.sueldo_base)}</td>
      <td>${escapeHTML(e.afp || '—')}</td>
      <td>${badgeEstadoEmpleado(e.estado)}</td>
      <td class="actions">
        <button class="btn ghost sm" data-action="edit">Editar</button>
        <button class="btn ghost sm" data-action="del">Eliminar</button>
      </td>
    </tr>
  `).join('');

  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const tr = btn.closest('tr');
    const id = tr.dataset.id;
    const emp = _empleados.find(x => x.id === id);
    if (btn.dataset.action === 'edit') abrirFormulario(root, emp);
    else if (btn.dataset.action === 'del') eliminarEmpleado(root, emp);
  });
}

function legibleJornada(t) {
  return ({
    completa_42hrs: 'Completa (42 hrs)',
    parcial: 'Parcial',
    por_dia: 'Por día',
    honorarios: 'Honorarios'
  })[t] || '—';
}

function abrirFormulario(root, empleado) {
  const esNuevo = !empleado;
  const e = empleado || {};
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-emp" style="max-width: 760px">
      <div class="modal-header">
        <h2>${esNuevo ? 'Nuevo empleado' : 'Editar empleado'}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div class="form-grid">
        <div class="field">
          <label>Nombre completo *</label>
          <input name="nombre" required value="${escapeHTML(e.nombre || '')}">
        </div>
        <div class="field">
          <label>RUT *</label>
          <input name="rut" required value="${escapeHTML(e.rut || '')}" placeholder="12.345.678-9">
          <div class="hint">Formato libre, se valida automáticamente</div>
        </div>
        <div class="field">
          <label>Cargo</label>
          <input name="cargo" value="${escapeHTML(e.cargo || '')}">
        </div>
        <div class="field">
          <label>Área</label>
          <input name="area" value="${escapeHTML(e.area || '')}">
        </div>
        <div class="field">
          <label>Tipo de contrato</label>
          <select name="tipo_contrato">
            <option value="">—</option>
            ${LISTAS.TIPOS_CONTRATO.map(t => `<option value="${t}" ${e.tipo_contrato === t ? 'selected' : ''}>${t}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Tipo de jornada</label>
          <select name="tipo_jornada">
            <option value="">—</option>
            ${LISTAS.TIPOS_JORNADA.map(t => `<option value="${t}" ${e.tipo_jornada === t ? 'selected' : ''}>${legibleJornada(t)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Horas semanales</label>
          <input type="number" step="0.5" min="0" max="60" name="horas_semanales" value="${e.horas_semanales ?? ''}">
        </div>
        <div class="field">
          <label>Sueldo base (CLP)</label>
          <input type="number" min="0" step="1000" name="sueldo_base" value="${e.sueldo_base ?? 0}">
        </div>
        <div class="field">
          <label>AFP</label>
          <select name="afp">
            <option value="">—</option>
            ${LISTAS.AFPS.map(a => `<option value="${a}" ${e.afp === a ? 'selected' : ''}>${a}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Previsión salud</label>
          <select name="prevision_salud">
            <option value="">—</option>
            ${LISTAS.PREVISIONES_SALUD.map(p => `<option value="${p}" ${e.prevision_salud === p ? 'selected' : ''}>${p}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Isapre (si aplica)</label>
          <input name="isapre_nombre" value="${escapeHTML(e.isapre_nombre || '')}">
        </div>
        <div class="field">
          <label>Plan Isapre (UF)</label>
          <input type="number" step="0.01" min="0" name="isapre_plan_uf" value="${e.isapre_plan_uf ?? ''}">
        </div>
        <div class="field">
          <label>Fecha ingreso</label>
          <input type="date" name="fecha_ingreso" value="${e.fecha_ingreso || ''}">
        </div>
        <div class="field">
          <label>Estado</label>
          <select name="estado">
            ${LISTAS.ESTADOS_EMPLEADO.map(s => `<option value="${s}" ${(e.estado || 'activo') === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Teléfono</label>
          <input name="telefono" value="${escapeHTML(e.telefono || '')}">
        </div>
        <div class="field">
          <label>Email</label>
          <input type="email" name="email" value="${escapeHTML(e.email || '')}">
        </div>
        <div class="field">
          <label>PIN Kiosk (4 dígitos)</label>
          <input type="password" name="pin_kiosk" maxlength="4" pattern="[0-9]{4}"
                 value="${escapeHTML(e.pin_kiosk || '')}"
                 placeholder="Para marcaje de asistencia"
                 autocomplete="new-password">
          <div class="hint">PIN que la trabajadora usa en la pantalla de marcaje (kiosk.html)</div>
        </div>
        <div class="field" style="grid-column: 1 / -1">
          <label>Dirección</label>
          <input name="direccion" value="${escapeHTML(e.direccion || '')}">
        </div>
        <div class="field" style="grid-column: 1 / -1">
          <label>Notas</label>
          <textarea name="notas">${escapeHTML(e.notas || '')}</textarea>
        </div>
      </div>
      <div id="form-error" class="field error" style="display:none; margin-top:8px"></div>
      <div class="form-actions" style="justify-content: flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">${esNuevo ? 'Crear empleado' : 'Guardar cambios'}</button>
      </div>
    </form>`;
  document.body.appendChild(back);

  const form = back.querySelector('#form-emp');
  const cerrar = () => back.remove();
  back.querySelector('.modal-close').addEventListener('click', cerrar);
  back.querySelector('[data-action=cancel]').addEventListener('click', cerrar);

  // Formato RUT en vivo
  const inputRUT = form.querySelector('input[name=rut]');
  inputRUT.addEventListener('blur', () => { inputRUT.value = formatearRUT(inputRUT.value); });

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const errEl = form.querySelector('#form-error');
    errEl.style.display = 'none';

    const fd = new FormData(form);
    const payload = Object.fromEntries(fd.entries());

    // Limpieza y validación
    payload.rut = formatearRUT(payload.rut);
    if (!validarRUT(payload.rut)) {
      errEl.textContent = 'RUT inválido (revisa dígito verificador)';
      errEl.style.display = 'block';
      return;
    }
    // Tipos numéricos
    payload.sueldo_base    = payload.sueldo_base ? parseInt(payload.sueldo_base, 10) : 0;
    payload.horas_semanales = payload.horas_semanales || null;
    payload.isapre_plan_uf = payload.isapre_plan_uf || null;
    // PIN kiosk: solo actualizar si se ingresó algo
    if (!payload.pin_kiosk) delete payload.pin_kiosk;
    // Limpiar vacíos
    for (const k of Object.keys(payload)) if (payload[k] === '') payload[k] = null;

    const submitBtn = form.querySelector('button[type=submit]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Guardando...';
    try {
      if (esNuevo) {
        const { error } = await supabase.from('empleados').insert(payload);
        if (error) throw error;
        toast('Empleado creado', 'ok');
      } else {
        const { error } = await supabase.from('empleados').update(payload).eq('id', e.id);
        if (error) throw error;
        toast('Cambios guardados', 'ok');
      }
      cerrar();
      await recargar(root);
    } catch (err) {
      errEl.textContent = err.message || 'Error guardando';
      errEl.style.display = 'block';
      submitBtn.disabled = false;
      submitBtn.textContent = esNuevo ? 'Crear empleado' : 'Guardar cambios';
    }
  });
}

async function eliminarEmpleado(root, emp) {
  const ok = await confirmar(`¿Eliminar a ${emp.nombre}? Esta acción no se puede deshacer y borrará también sus vacaciones, anticipos y documentos asociados.`, {
    textoOk: 'Eliminar', peligroso: true
  });
  if (!ok) return;
  const { error } = await supabase.from('empleados').delete().eq('id', emp.id);
  if (error) {
    toast('Error eliminando: ' + error.message, 'danger');
    return;
  }
  toast('Empleado eliminado', 'ok');
  await recargar(root);
}
