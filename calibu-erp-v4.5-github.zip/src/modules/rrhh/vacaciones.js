// =====================================================================
// Vacaciones (admin) — lista de solicitudes + alta + aprobación
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearFecha, escapeHTML, calcularDiasHabiles, calcularSaldoVacaciones } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';

let _rows = [];
let _empleados = [];

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Vacaciones</h1><small>Solicitudes de todo el equipo</small></div>
      <button class="btn" id="btn-nueva">+ Nueva solicitud</button>
    </div>
    <div class="card" style="padding:0">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Empleado</th><th>Solicitud</th><th>Desde</th><th>Hasta</th>
          <th class="num">Días hábiles</th><th>Estado</th><th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="7" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  await recargar(root);
  root.querySelector('#btn-nueva').addEventListener('click', () => abrirFormulario(root));
}

async function recargar(root) {
  const [{ data: rows }, { data: emps }] = await Promise.all([
    supabase.from('vacaciones').select('*, empleados:empleado_id(id, nombre)').order('fecha_solicitud', { ascending: false }),
    supabase.from('empleados').select('id, nombre').order('nombre')
  ]);
  _rows = rows || [];
  _empleados = emps || [];
  const tbody = root.querySelector('#tbody');
  if (!_rows.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="icon">🏖️</div><p>Sin solicitudes de vacaciones</p></div></td></tr>`;
    return;
  }
  const badgeEst = e => {
    const m = { solicitada:'warn', aprobada:'ok', rechazada:'danger', tomada:'info', cancelada:'neutral' };
    return `<span class="badge ${m[e]||'neutral'}">${e}</span>`;
  };
  tbody.innerHTML = _rows.map(r => `
    <tr data-id="${r.id}">
      <td>${escapeHTML(r.empleados?.nombre || '—')}</td>
      <td>${formatearFecha(r.fecha_solicitud)}</td>
      <td>${formatearFecha(r.fecha_desde)}</td>
      <td>${formatearFecha(r.fecha_hasta)}</td>
      <td class="num">${r.dias_habiles}</td>
      <td>${badgeEst(r.estado)}</td>
      <td class="actions">
        ${r.estado === 'solicitada' ? `
          <button class="btn ghost sm" data-action="aprobar">Aprobar</button>
          <button class="btn ghost sm" data-action="rechazar">Rechazar</button>` : ''}
        <button class="btn ghost sm" data-action="del">Eliminar</button>
      </td>
    </tr>`).join('');
  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.closest('tr').dataset.id;
    const accion = btn.dataset.action;
    if (accion === 'aprobar') await cambiarEstado(id, 'aprobada');
    else if (accion === 'rechazar') {
      const motivo = prompt('Motivo de rechazo (opcional):') || '';
      await cambiarEstado(id, 'rechazada', motivo);
    } else if (accion === 'del') {
      if (await confirmar('¿Eliminar esta solicitud?', { peligroso: true })) {
        await supabase.from('vacaciones').delete().eq('id', id);
        toast('Solicitud eliminada', 'ok');
      }
    }
    await recargar(root);
  });
}

async function cambiarEstado(id, nuevoEstado, motivo) {
  const payload = { estado: nuevoEstado, fecha_aprobacion: new Date().toISOString() };
  if (motivo) payload.motivo_rechazo = motivo;
  const { error } = await supabase.from('vacaciones').update(payload).eq('id', id);
  if (error) toast('Error: ' + error.message, 'danger');
  else toast(`Solicitud ${nuevoEstado}`, 'ok');
}

function abrirFormulario(root) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-vac" style="max-width:560px">
      <div class="modal-header"><h2>Nueva solicitud</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field">
          <label>Empleado *</label>
          <select name="empleado_id" required>
            <option value="">—</option>
            ${_empleados.map(e => `<option value="${e.id}">${escapeHTML(e.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Desde *</label>
          <input type="date" name="fecha_desde" required>
        </div>
        <div class="field">
          <label>Hasta *</label>
          <input type="date" name="fecha_hasta" required>
        </div>
        <div class="field">
          <label>Días hábiles (calculado)</label>
          <input type="text" id="dias-calc" readonly>
        </div>
        <div class="field" style="grid-column:1/-1">
          <label>Notas</label>
          <textarea name="notas" rows="2"></textarea>
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Crear solicitud</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-vac');
  const inDesde = form.querySelector('[name=fecha_desde]');
  const inHasta = form.querySelector('[name=fecha_hasta]');
  const inDias = form.querySelector('#dias-calc');
  const recalc = () => {
    if (inDesde.value && inHasta.value) {
      inDias.value = calcularDiasHabiles(inDesde.value, inHasta.value) + ' días hábiles';
    }
  };
  inDesde.addEventListener('change', recalc);
  inHasta.addEventListener('change', recalc);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const payload = {
      empleado_id: fd.get('empleado_id'),
      fecha_desde: fd.get('fecha_desde'),
      fecha_hasta: fd.get('fecha_hasta'),
      dias_habiles: calcularDiasHabiles(fd.get('fecha_desde'), fd.get('fecha_hasta')),
      notas: fd.get('notas') || null,
      estado: 'solicitada'
    };
    if (payload.dias_habiles <= 0) { toast('Fechas inválidas', 'danger'); return; }
    const { error } = await supabase.from('vacaciones').insert(payload);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Solicitud creada', 'ok');
    back.remove();
    await recargar(root);
  });
}
