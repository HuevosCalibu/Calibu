// =====================================================================
// Calibú ERP — Registro de Asistencia (Admin)
// Vista completa para inspección del trabajo
// =====================================================================
import { supabase } from '../../lib/supabase.js';
import { formatearFecha, escapeHTML, hoyISO } from '../../lib/calc.js';
import { toast, exportarCSV } from '../../lib/ui.js';

export async function render(root) {
  const hoy = hoyISO();
  const hace30 = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);

  root.innerHTML = `
    <div class="section-header">
      <div>
        <h1>📋 Registro de Asistencia</h1>
        <small>Marcajes de entrada y salida · Inspección del Trabajo</small>
      </div>
      <div style="display:flex; gap:8px">
        <button class="btn ghost" id="btn-csv">📥 Exportar CSV</button>
        <button class="btn ghost" id="btn-manual">+ Registro manual</button>
      </div>
    </div>

    <div class="card" style="margin-bottom:16px; padding:12px 16px">
      <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap">
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Desde</label><br>
          <input type="date" id="desde" value="${hace30}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Hasta</label><br>
          <input type="date" id="hasta" value="${hoy}" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
        </div>
        <div>
          <label style="font-size:12px; color:var(--text-muted)">Empleado/a</label><br>
          <select id="empleado-filtro" style="padding:6px 8px; border:1px solid var(--border-fuerte); border-radius:6px">
            <option value="">Todos</option>
          </select>
        </div>
        <div style="margin-left:auto" id="kpi-resumen"></div>
      </div>
    </div>

    <div class="card" style="padding:0">
      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Empleado/a</th>
              <th>Entrada</th>
              <th>Salida</th>
              <th class="num">Horas</th>
              <th>Observaciones</th>
              <th class="actions">Acciones</th>
            </tr>
          </thead>
          <tbody id="tbody">
            <tr><td colspan="7" style="text-align:center; padding:24px">Cargando...</td></tr>
          </tbody>
        </table>
      </div>
    </div>`;

  const { data: empleados } = await supabase.from('empleados').select('id, nombre').order('nombre');
  const sel = root.querySelector('#empleado-filtro');
  (empleados || []).forEach(e => {
    const opt = document.createElement('option');
    opt.value = e.id;
    opt.textContent = e.nombre;
    sel.appendChild(opt);
  });

  const cargar = () => recargar(root);
  root.querySelector('#desde').addEventListener('change', cargar);
  root.querySelector('#hasta').addEventListener('change', cargar);
  root.querySelector('#empleado-filtro').addEventListener('change', cargar);
  root.querySelector('#btn-csv').addEventListener('click', () => exportarRegistros(root));
  root.querySelector('#btn-manual').addEventListener('click', () => modalManual(root, empleados || []));

  await recargar(root);
}

async function recargar(root) {
  const desde = root.querySelector('#desde').value;
  const hasta = root.querySelector('#hasta').value;
  const empId = root.querySelector('#empleado-filtro').value;

  let q = supabase
    .from('asistencia')
    .select('*, empleados:empleado_id(nombre, rut)')
    .gte('fecha', desde)
    .lte('fecha', hasta)
    .order('fecha', { ascending: false });

  if (empId) q = q.eq('empleado_id', empId);

  const { data, error } = await q;
  if (error) { toast('Error cargando asistencia: ' + error.message, 'danger'); return; }
  const rows = data || [];

  const conHoras = rows.filter(r => r.horas_trabajadas != null);
  const totalHoras = conHoras.reduce((a, r) => a + Number(r.horas_trabajadas), 0);
  const diasCompletos = rows.filter(r => r.entrada && r.salida).length;
  root.querySelector('#kpi-resumen').innerHTML = `
    <div style="display:flex; gap:16px; font-size:13px; color:var(--text-muted)">
      <span><strong style="color:var(--text)">${rows.length}</strong> registros</span>
      <span><strong style="color:var(--text)">${diasCompletos}</strong> días completos</span>
      <span><strong style="color:var(--text)">${totalHoras.toFixed(1)}</strong> hrs totales</span>
    </div>`;

  const tbody = root.querySelector('#tbody');
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="icon">⏰</div><p>Sin registros en el período seleccionado</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map(r => {
    const entrada = r.entrada ? new Date(r.entrada).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }) : '—';
    const salida  = r.salida  ? new Date(r.salida).toLocaleTimeString('es-CL',  { hour: '2-digit', minute: '2-digit' }) : '—';
    const horas   = r.horas_trabajadas != null ? Number(r.horas_trabajadas).toFixed(1) : '—';
    const incompleto = r.entrada && !r.salida;
    return `<tr data-id="${r.id}">
      <td>${formatearFecha(r.fecha)}</td>
      <td>
        <div style="font-weight:500">${escapeHTML(r.empleados?.nombre || '—')}</div>
        <div style="font-size:var(--fs-xs); color:var(--text-muted)">${escapeHTML(r.empleados?.rut || '')}</div>
      </td>
      <td style="color:${r.entrada ? 'var(--ok)' : 'var(--text-muted)'}">
        ${entrada}
        ${r.lat_entrada ? `<br><small style="color:var(--text-muted)">📍 ${Number(r.lat_entrada).toFixed(4)}, ${Number(r.lng_entrada).toFixed(4)}</small>` : ''}
      </td>
      <td style="color:${r.salida ? 'var(--ok)' : incompleto ? 'var(--warn)' : 'var(--text-muted)'}">
        ${salida}
        ${r.lat_salida ? `<br><small style="color:var(--text-muted)">📍 ${Number(r.lat_salida).toFixed(4)}, ${Number(r.lng_salida).toFixed(4)}</small>` : ''}
      </td>
      <td class="num" style="font-weight:600">${horas}</td>
      <td style="font-size:var(--fs-xs); color:var(--text-muted)">${escapeHTML(r.observaciones || '')}</td>
      <td class="actions">
        <button class="btn ghost sm" data-action="editar">Editar</button>
      </td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('button[data-action=editar]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('tr').dataset.id;
      const row = rows.find(r => r.id === id);
      if (row) modalEditar(root, row);
    });
  });
}

async function modalManual(root, empleados) {
  const hoy = hoyISO();
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-asist" style="max-width:480px">
      <div class="modal-header"><h2>Registro manual de asistencia</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1">
          <label>Empleado/a *</label>
          <select name="empleado_id" required>
            <option value="">—</option>
            ${empleados.map(e => `<option value="${e.id}">${escapeHTML(e.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Fecha *</label><input type="date" name="fecha" value="${hoy}" required></div>
        <div class="field"><label>Hora entrada</label><input type="time" name="hora_entrada"></div>
        <div class="field"><label>Hora salida</label><input type="time" name="hora_salida"></div>
        <div class="field" style="grid-column:1/-1">
          <label>Observaciones</label>
          <input name="observaciones" placeholder="Ej: Tardanza justificada, licencia médica...">
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Guardar registro</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  back.querySelector('#form-asist').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const fecha = fd.get('fecha');
    const hE = fd.get('hora_entrada');
    const hS = fd.get('hora_salida');
    const payload = {
      empleado_id: fd.get('empleado_id'),
      fecha,
      observaciones: fd.get('observaciones') || null,
      entrada: hE ? `${fecha}T${hE}:00` : null,
      salida:  hS ? `${fecha}T${hS}:00` : null,
    };
    if (payload.entrada && payload.salida) {
      payload.horas_trabajadas = Math.round((new Date(payload.salida) - new Date(payload.entrada)) / 36000) / 100;
    }
    const { error } = await supabase.from('asistencia').upsert(payload, { onConflict: 'empleado_id,fecha' });
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Registro guardado', 'ok');
    back.remove();
    await recargar(root);
  });
}

async function modalEditar(root, row) {
  const fmt = t => t ? new Date(t).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit', hour12: false }) : '';
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-edit" style="max-width:480px">
      <div class="modal-header">
        <h2>Editar — ${escapeHTML(row.empleados?.nombre || '')} · ${formatearFecha(row.fecha)}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div class="form-grid">
        <div class="field"><label>Hora entrada</label><input type="time" name="hora_entrada" value="${fmt(row.entrada)}"></div>
        <div class="field"><label>Hora salida</label><input type="time" name="hora_salida" value="${fmt(row.salida)}"></div>
        <div class="field" style="grid-column:1/-1">
          <label>Observaciones</label>
          <input name="observaciones" value="${escapeHTML(row.observaciones || '')}">
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" style="color:var(--danger)" data-action="eliminar">Eliminar</button>
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Guardar</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=eliminar]').addEventListener('click', async () => {
    if (!confirm('¿Eliminar este registro?')) return;
    await supabase.from('asistencia').delete().eq('id', row.id);
    toast('Eliminado', 'ok');
    back.remove();
    await recargar(root);
  });
  back.querySelector('#form-edit').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const hE = fd.get('hora_entrada');
    const hS = fd.get('hora_salida');
    const payload = {
      entrada: hE ? `${row.fecha}T${hE}:00` : null,
      salida:  hS ? `${row.fecha}T${hS}:00` : null,
      observaciones: fd.get('observaciones') || null,
    };
    if (payload.entrada && payload.salida) {
      payload.horas_trabajadas = Math.round((new Date(payload.salida) - new Date(payload.entrada)) / 36000) / 100;
    }
    const { error } = await supabase.from('asistencia').update(payload).eq('id', row.id);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Actualizado', 'ok');
    back.remove();
    await recargar(root);
  });
}

async function exportarRegistros(root) {
  const desde = root.querySelector('#desde').value;
  const hasta = root.querySelector('#hasta').value;
  const empId = root.querySelector('#empleado-filtro').value;
  let q = supabase.from('asistencia')
    .select('fecha, empleados:empleado_id(nombre, rut), entrada, salida, horas_trabajadas, observaciones')
    .gte('fecha', desde).lte('fecha', hasta).order('fecha', { ascending: true });
  if (empId) q = q.eq('empleado_id', empId);
  const { data } = await q;
  const rows = (data || []).map(r => ({
    Fecha: r.fecha,
    Empleado: r.empleados?.nombre || '',
    RUT: r.empleados?.rut || '',
    Entrada: r.entrada ? new Date(r.entrada).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }) : '',
    Salida:  r.salida  ? new Date(r.salida).toLocaleTimeString('es-CL',  { hour: '2-digit', minute: '2-digit' }) : '',
    Horas_trabajadas: r.horas_trabajadas ?? '',
    Observaciones: r.observaciones || ''
  }));
  exportarCSV(rows, `asistencia_${desde}_${hasta}.csv`);
  toast('CSV descargado', 'ok');
}
