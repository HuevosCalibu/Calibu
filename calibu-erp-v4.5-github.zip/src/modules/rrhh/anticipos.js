// Anticipos — registro y descuento de adelantos
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, mesActualISO } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';

let _empleados = [];

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Anticipos</h1><small>Adelantos de sueldo</small></div>
      <button class="btn" id="btn-nuevo">+ Nuevo anticipo</button>
    </div>
    <div class="kpi-grid" id="resumen"></div>
    <div class="card" style="padding:0; margin-top: 16px">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Fecha</th><th>Empleado</th><th>Descripción</th><th>Mes descuento</th>
          <th class="num">Monto</th><th>Estado</th><th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="7" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  const { data: emps } = await supabase.from('empleados').select('id, nombre').order('nombre');
  _empleados = emps || [];
  await recargar(root);
  root.querySelector('#btn-nuevo').addEventListener('click', () => abrirFormulario(root));
}

async function recargar(root) {
  const { data, error } = await supabase
    .from('anticipos')
    .select('*, empleados:empleado_id(id, nombre)')
    .order('fecha', { ascending: false });
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  const rows = data || [];
  const totalMes = rows.filter(r => r.mes_descuento === mesActualISO()).reduce((a,r) => a + r.monto, 0);
  const pendientes = rows.filter(r => !r.descontado).reduce((a,r) => a + r.monto, 0);
  root.querySelector('#resumen').innerHTML = `
    <div class="kpi"><div class="label">A descontar este mes</div><div class="value">${formatearCLP(totalMes)}</div></div>
    <div class="kpi"><div class="label">Total pendientes</div><div class="value">${formatearCLP(pendientes)}</div></div>
    <div class="kpi"><div class="label">N° anticipos</div><div class="value">${rows.length}</div></div>`;
  const tbody = root.querySelector('#tbody');
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="icon">💵</div><p>Sin anticipos registrados</p></div></td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td>${formatearFecha(r.fecha)}</td>
      <td>${escapeHTML(r.empleados?.nombre || '—')}</td>
      <td>${escapeHTML(r.descripcion || '—')}</td>
      <td>${escapeHTML(r.mes_descuento || '—')}</td>
      <td class="num">${formatearCLP(r.monto)}</td>
      <td><span class="badge ${r.descontado ? 'ok' : 'warn'}">${r.descontado ? 'Descontado' : 'Pendiente'}</span></td>
      <td class="actions">
        ${!r.descontado ? '<button class="btn ghost sm" data-action="descontar">Marcar descontado</button>' : ''}
        <button class="btn ghost sm" data-action="del">Eliminar</button>
      </td>
    </tr>`).join('');
  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.closest('tr').dataset.id;
    if (btn.dataset.action === 'descontar') {
      await supabase.from('anticipos').update({ descontado: true }).eq('id', id);
      toast('Anticipo descontado', 'ok');
    } else if (btn.dataset.action === 'del') {
      if (await confirmar('¿Eliminar este anticipo?', { peligroso: true })) {
        await supabase.from('anticipos').delete().eq('id', id);
        toast('Eliminado', 'ok');
      }
    }
    await recargar(root);
  });
}

function abrirFormulario(root) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" style="max-width:520px" id="form-ant">
      <div class="modal-header"><h2>Nuevo anticipo</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field">
          <label>Empleado *</label>
          <select name="empleado_id" required>
            <option value="">—</option>
            ${_empleados.map(e => `<option value="${e.id}">${escapeHTML(e.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Fecha *</label><input type="date" name="fecha" required value="${new Date().toISOString().slice(0,10)}"></div>
        <div class="field"><label>Monto (CLP) *</label><input type="number" name="monto" required min="1" step="1000"></div>
        <div class="field"><label>Mes descuento</label><input type="month" name="mes_descuento" value="${mesActualISO()}"></div>
        <div class="field" style="grid-column:1/-1"><label>Descripción</label><textarea name="descripcion" rows="2"></textarea></div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Registrar</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-ant');
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const payload = {
      empleado_id: fd.get('empleado_id'),
      fecha: fd.get('fecha'),
      monto: parseInt(fd.get('monto'), 10),
      mes_descuento: fd.get('mes_descuento') || null,
      descripcion: fd.get('descripcion') || null
    };
    const { error } = await supabase.from('anticipos').insert(payload);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Anticipo registrado', 'ok');
    back.remove();
    await recargar(root);
  });
}
