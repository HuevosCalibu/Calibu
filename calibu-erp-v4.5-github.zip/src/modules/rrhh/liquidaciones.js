// Liquidaciones — generador mensual y listado
import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, mesActualISO } from '../../lib/calc.js';
import { calcularLiquidacion } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Liquidaciones</h1><small>Cálculo y registro mensual</small></div>
      <div style="display:flex; gap: 8px; align-items: center">
        <select id="mes-filtro" style="padding:8px 10px; border:1px solid var(--border-fuerte); border-radius:8px">
          ${mesesOpciones()}
        </select>
        <button class="btn" id="btn-generar">Generar mes</button>
      </div>
    </div>
    <div class="card" style="padding:0">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Mes</th><th>Empleado</th><th>Imponible</th><th>AFP</th><th>Salud</th>
          <th>Hrs extra</th><th>Anticipos</th><th class="num">Líquido</th><th class="num">Costo empleador</th><th>Estado</th>
          <th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="11" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  await recargar(root);
  root.querySelector('#btn-generar').addEventListener('click', () => generarMes(root));
  root.querySelector('#mes-filtro').addEventListener('change', () => recargar(root));
}

function mesesOpciones() {
  const ahora = new Date();
  const meses = [];
  for (let i = -6; i <= 0; i++) {
    const d = new Date(ahora.getFullYear(), ahora.getMonth() + i, 1);
    meses.push(d.toISOString().slice(0,7));
  }
  return meses.map(m => `<option value="${m}" ${m===mesActualISO()?'selected':''}>${m}</option>`).join('');
}

async function recargar(root) {
  const mes = root.querySelector('#mes-filtro').value;
  const { data, error } = await supabase
    .from('liquidaciones')
    .select('*, empleados:empleado_id(id, nombre)')
    .eq('anio_mes', mes)
    .order('empleado_id');
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  const rows = data || [];
  const tbody = root.querySelector('#tbody');
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="11"><div class="empty-state"><div class="icon">📋</div><p>Sin liquidaciones en ${mes}</p><small>Usa "Generar mes" para crearlas</small></div></td></tr>`;
    return;
  }
  // Guardar rows para modal de horas extra
  tbody._rows = rows;
  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td>${r.anio_mes}</td>
      <td>${escapeHTML(r.empleados?.nombre || '—')}</td>
      <td class="num">${formatearCLP(r.total_haberes_imponibles)}</td>
      <td class="num">${formatearCLP(r.afp_monto + r.afp_comision)}</td>
      <td class="num">${formatearCLP(r.salud_monto)}</td>
      <td class="num">${r.horas_extra > 0 ? r.horas_extra + ' hrs (+' + formatearCLP(r.horas_extra_monto||0) + ')' : '—'}</td>
      <td class="num">${formatearCLP(r.anticipos_monto)}</td>
      <td class="num" style="font-weight:700">${formatearCLP(r.liquido)}</td>
      <td class="num">${formatearCLP(r.costo_empleador_total)}</td>
      <td><span class="badge ${r.estado==='pagada'?'ok':r.estado==='emitida'?'info':'neutral'}">${r.estado}</span></td>
      <td class="actions">
        <button class="btn ghost sm" data-action="hrsextra">Hrs extra</button>
        ${r.estado !== 'pagada' ? '<button class="btn ghost sm" data-action="pagar">Marcar pagada</button>' : ''}
        <button class="btn ghost sm" data-action="del">Eliminar</button>
      </td>
    </tr>`).join('');
  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.closest('tr').dataset.id;
    const rows = tbody._rows || [];
    if (btn.dataset.action === 'hrsextra') {
      const row = rows.find(r => r.id === id);
      if (row) await modalHrsExtra(row, root);
      return;
    } else if (btn.dataset.action === 'pagar') {
      await supabase.from('liquidaciones').update({ estado: 'pagada' }).eq('id', id);
      toast('Marcada como pagada', 'ok');
    } else if (btn.dataset.action === 'del') {
      if (await confirmar('¿Eliminar liquidación?', { peligroso: true })) {
        await supabase.from('liquidaciones').delete().eq('id', id);
        toast('Eliminada', 'ok');
      }
    }
    await recargar(root);
  });
}

async function generarMes(root) {
  const mes = root.querySelector('#mes-filtro').value;
  if (!await confirmar(`Generar liquidaciones para ${mes}? Esto creará una liquidación por cada empleado activo, calculando AFP, salud, cesantía y anticipos del mes.`)) return;
  const { data: empleados } = await supabase.from('empleados').select('*').eq('estado', 'activo');
  if (!empleados?.length) { toast('No hay empleados activos', 'warn'); return; }
  let creadas = 0, omitidas = 0;
  for (const emp of empleados) {
    // Verificar si ya existe
    const { data: existente } = await supabase.from('liquidaciones')
      .select('id').eq('empleado_id', emp.id).eq('anio_mes', mes).maybeSingle();
    if (existente) { omitidas++; continue; }
    // Calcular anticipos del mes
    const { data: anticipos } = await supabase.from('anticipos')
      .select('monto').eq('empleado_id', emp.id).eq('mes_descuento', mes).eq('descontado', false);
    const totalAnticipos = (anticipos || []).reduce((a, x) => a + x.monto, 0);
    // Calcular
    // Horas extra del mes (se pueden ajustar luego desde la liquidación)
    const horasExtra = 0;
    const calc = calcularLiquidacion({
      sueldo_base: emp.sueldo_base,
      afp: emp.afp,
      prevision_salud: emp.prevision_salud,
      isapre_plan_uf: emp.isapre_plan_uf,
      tipo_contrato: emp.tipo_contrato,
      anticipos_monto: totalAnticipos,
      horas_extra: horasExtra,
      horas_semanales: emp.horas_semanales || 42
    });
    const payload = {
      empleado_id: emp.id,
      anio_mes: mes,
      sueldo_base: emp.sueldo_base,
      total_haberes_imponibles: calc.total_haberes_imponibles,
      total_haberes: calc.total_haberes,
      afp_monto: calc.afp_monto,
      afp_comision: calc.afp_comision,
      salud_monto: calc.salud_monto,
      seguro_cesantia_trabajador: calc.seguro_cesantia_trabajador,
      anticipos_monto: totalAnticipos,
      total_descuentos: calc.total_descuentos,
      liquido: calc.liquido,
      costo_empleador_sis: calc.costo_empleador_sis,
      costo_empleador_cesantia: calc.costo_empleador_cesantia,
      costo_empleador_total: calc.costo_empleador_total,
      horas_extra: calc.horas_extra || 0,
      horas_extra_monto: calc.horas_extra_monto || 0,
      estado: 'emitida'
    };
    const { error } = await supabase.from('liquidaciones').insert(payload);
    if (error) { console.error(error); continue; }
    creadas++;
    // Marcar anticipos como descontados
    if (anticipos?.length) {
      await supabase.from('anticipos').update({ descontado: true })
        .eq('empleado_id', emp.id).eq('mes_descuento', mes).eq('descontado', false);
    }
  }
  toast(`${creadas} creadas, ${omitidas} ya existían`, 'ok');
  await recargar(root);
}


// =====================================================================
// Modal para registrar horas extra en una liquidación
// Ley 19.250 — Recargo mínimo 50% sobre valor hora normal
// =====================================================================
async function modalHrsExtra(liq, root) {
  const { data: emp } = await supabase.from('empleados').select('sueldo_base, horas_semanales').eq('id', liq.empleado_id).maybeSingle();
  const sueldoBase = emp?.sueldo_base || liq.sueldo_base || 0;
  const hrsSemanales = emp?.horas_semanales || 42;
  // Valor hora = sueldo_base / (hrsSemanales * 4.33)
  const valorHora = Math.round(sueldoBase / (hrsSemanales * 4.33));
  const valorHoraExtra = Math.round(valorHora * 1.5); // 50% recargo legal

  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-hrs" style="max-width:440px">
      <div class="modal-header">
        <h2>Horas extra — ${escapeHTML(liq.anio_mes)}</h2>
        <button type="button" class="modal-close">&times;</button>
      </div>
      <div style="background:var(--surface-2); border-radius:8px; padding:12px; margin-bottom:16px; font-size:13px">
        <div>Sueldo base: <strong>${formatearCLP(sueldoBase)}</strong></div>
        <div>Jornada: <strong>${hrsSemanales} hrs/semana</strong></div>
        <div>Valor hora normal: <strong>${formatearCLP(valorHora)}</strong></div>
        <div style="color:var(--calibu-primario)">Valor hora extra (50% recargo): <strong>${formatearCLP(valorHoraExtra)}</strong></div>
      </div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1">
          <label>Número de horas extra del mes</label>
          <input type="number" name="horas_extra" min="0" max="45" step="0.5" value="${liq.horas_extra || 0}" id="inp-hrs">
          <div class="hint">Máximo legal: 2 hrs/día · 10 hrs/semana · ~45 hrs/mes</div>
        </div>
        <div class="field" style="grid-column:1/-1">
          <div style="display:flex; justify-content:space-between; font-size:14px; padding:8px 0">
            <span>Monto horas extra:</span>
            <strong id="preview-monto">${formatearCLP((liq.horas_extra||0) * valorHoraExtra)}</strong>
          </div>
        </div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Guardar y recalcular</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());

  const inpHrs = back.querySelector('#inp-hrs');
  const previewMonto = back.querySelector('#preview-monto');
  inpHrs.addEventListener('input', () => {
    const hrs = parseFloat(inpHrs.value) || 0;
    previewMonto.textContent = formatearCLP(Math.round(hrs * valorHoraExtra));
  });

  back.querySelector('#form-hrs').addEventListener('submit', async (e) => {
    e.preventDefault();
    const hrs = parseFloat(inpHrs.value) || 0;
    const montoExtra = Math.round(hrs * valorHoraExtra);
    // Recalcular líquido: agregar horas extra a haberes y restar descuentos
    const nuevoImponible = liq.total_haberes_imponibles + montoExtra;
    // Simplificado: el monto extra va directo al líquido (ya cotizado en sueldo base)
    const nuevoLiquido = liq.liquido + montoExtra;
    const nuevoCostoEmpleador = liq.costo_empleador_total + montoExtra;
    const { error } = await supabase.from('liquidaciones').update({
      horas_extra: hrs,
      horas_extra_monto: montoExtra,
      total_haberes: (liq.total_haberes || liq.total_haberes_imponibles) + montoExtra,
      liquido: nuevoLiquido,
      costo_empleador_total: nuevoCostoEmpleador
    }).eq('id', liq.id);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(`${hrs} hrs extra guardadas (+${formatearCLP(montoExtra)})`, 'ok');
    back.remove();
    await recargar(root);
  });
}
