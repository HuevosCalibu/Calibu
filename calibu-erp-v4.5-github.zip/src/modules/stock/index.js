import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Stock de insumos</h1><small>Semáforo de inventario y alertas</small></div>
      <button class="btn" id="btn-nuevo">+ Nuevo insumo</button>
    </div>
    <div class="kpi-grid" id="resumen" style="margin-bottom:16px"></div>
    <div class="card" style="padding:0">
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Insumo</th><th>Categoría</th>
          <th class="num">Stock actual</th><th>Unidad</th>
          <th class="num">Consumo diario</th><th class="num">Días stock</th>
          <th>Semáforo</th><th class="actions">Acciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="8" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  await recargar(root);
  root.querySelector('#btn-nuevo').addEventListener('click', () => abrirFormulario(root, null));
}

async function recargar(root) {
  const { data } = await supabase.from('v_stock_alertas').select('*').order('dias_stock', { ascending: true, nullsFirst: false });
  const rows = data || [];
  const rojos = rows.filter(r => r.semaforo === 'rojo').length;
  const amar = rows.filter(r => r.semaforo === 'amarillo').length;
  const verdes = rows.filter(r => r.semaforo === 'verde').length;
  root.querySelector('#resumen').innerHTML = `
    <div class="kpi"><div class="label">🔴 Críticos</div><div class="value">${rojos}</div></div>
    <div class="kpi"><div class="label">🟡 Por reponer</div><div class="value">${amar}</div></div>
    <div class="kpi"><div class="label">🟢 OK</div><div class="value">${verdes}</div></div>
    <div class="kpi"><div class="label">Total insumos</div><div class="value">${rows.length}</div></div>`;
  // Clonar tbody para evitar listeners acumulativos en cada recargar
  const viejoTbody = root.querySelector('#tbody');
  const tbody = viejoTbody.cloneNode(false);
  viejoTbody.parentNode.replaceChild(tbody, viejoTbody);
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="8"><div class="empty-state">Sin insumos</div></td></tr>'; return; }
  const sem = { rojo: '🔴', amarillo: '🟡', verde: '🟢', blanco: '⚪' };
  const semClass = { rojo: 'danger', amarillo: 'warn', verde: 'ok', blanco: 'neutral' };
  tbody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td><strong>${escapeHTML(r.nombre)}</strong></td>
      <td>—</td>
      <td class="num">${Number(r.stock_actual).toFixed(0)}</td>
      <td>${escapeHTML(r.unidad)}</td>
      <td class="num">${r.consumo_diario_estimado ? Number(r.consumo_diario_estimado).toFixed(2) : '—'}</td>
      <td class="num">${r.dias_stock != null ? Number(r.dias_stock).toFixed(0) + ' días' : '—'}</td>
      <td><span class="badge ${semClass[r.semaforo]}">${sem[r.semaforo]} ${r.semaforo}</span></td>
      <td class="actions">
        <button class="btn ghost sm" data-action="entrada">+ Entrada</button>
        <button class="btn ghost sm" data-action="ajuste">Ajustar</button>
        <button class="btn ghost sm" data-action="edit">Editar</button>
      </td>
    </tr>`).join('');
  tbody.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.closest('tr').dataset.id;
    if (btn.dataset.action === 'entrada') return modalMovimiento(root, id, 'entrada');
    if (btn.dataset.action === 'ajuste') return modalMovimiento(root, id, 'ajuste');
    if (btn.dataset.action === 'edit') {
      const { data: ins } = await supabase.from('insumos').select('*').eq('id', id).maybeSingle();
      if (ins) abrirFormulario(root, ins);
    }
  });
}

function modalMovimiento(root, insumoId, tipo) {
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" style="max-width:420px" id="form-mov">
      <div class="modal-header"><h2>${tipo === 'entrada' ? '+ Entrada de stock' : 'Ajustar stock'}</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1"><label>${tipo === 'entrada' ? 'Cantidad a sumar' : 'Stock nuevo (exacto)'} *</label><input type="number" name="cantidad" required step="0.001" min="0"></div>
        <div class="field" style="grid-column:1/-1"><label>Motivo</label><input name="motivo" placeholder="Ej: compra Champion 50 sacos"></div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Registrar</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-mov');
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const { error } = await supabase.from('movimientos_stock').insert({
      insumo_id: insumoId, tipo,
      cantidad: parseFloat(form.cantidad.value),
      motivo: form.motivo.value || null
    });
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(tipo === 'entrada' ? '+ Entrada registrada' : 'Stock ajustado', 'ok');
    back.remove();
    await recargar(root);
  });
}

function abrirFormulario(root, ins) {
  const esNuevo = !ins;
  const i = ins || {};
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" id="form-ins" style="max-width:520px">
      <div class="modal-header"><h2>${esNuevo?'Nuevo insumo':'Editar insumo'}</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1"><label>Nombre *</label><input name="nombre" required value="${escapeHTML(i.nombre||'')}"></div>
        <div class="field"><label>Unidad *</label><input name="unidad" required value="${escapeHTML(i.unidad||'')}" placeholder="unidades, sacos, rollos..."></div>
        <div class="field"><label>Categoría</label><input name="categoria" value="${escapeHTML(i.categoria||'')}"></div>
        <div class="field"><label>Stock actual</label><input type="number" name="stock_actual" step="0.001" min="0" value="${i.stock_actual||0}"></div>
        <div class="field"><label>Consumo diario estimado</label><input type="number" name="consumo_diario_estimado" step="0.001" min="0" value="${i.consumo_diario_estimado||''}"></div>
        <div class="field"><label>Alerta amarillo (días)</label><input type="number" name="dias_alerta_amarillo" min="1" value="${i.dias_alerta_amarillo||10}"></div>
        <div class="field"><label>Alerta rojo (días)</label><input type="number" name="dias_alerta_rojo" min="1" value="${i.dias_alerta_rojo||5}"></div>
        <div class="field" style="grid-column:1/-1"><label>Descripción de consumo</label><input name="consumo_unitario_desc" value="${escapeHTML(i.consumo_unitario_desc||'')}"></div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">${esNuevo?'Crear':'Guardar'}</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-ins');
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const payload = Object.fromEntries(fd.entries());
    payload.stock_actual = parseFloat(payload.stock_actual)||0;
    payload.consumo_diario_estimado = payload.consumo_diario_estimado ? parseFloat(payload.consumo_diario_estimado) : null;
    payload.dias_alerta_amarillo = parseInt(payload.dias_alerta_amarillo,10)||10;
    payload.dias_alerta_rojo = parseInt(payload.dias_alerta_rojo,10)||5;
    for (const k of Object.keys(payload)) if (payload[k] === '') payload[k] = null;
    const op = esNuevo ? supabase.from('insumos').insert(payload) : supabase.from('insumos').update(payload).eq('id', i.id);
    const { error } = await op;
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(esNuevo?'Insumo creado':'Cambios guardados', 'ok');
    back.remove();
    await recargar(root);
  });
}
