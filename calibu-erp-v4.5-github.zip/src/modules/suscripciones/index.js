import { supabase } from '../../lib/supabase.js';
import { formatearCLP, formatearFecha, escapeHTML, hoyISO } from '../../lib/calc.js';
import { toast, confirmar } from '../../lib/ui.js';
import { LISTAS } from '../../lib/constantes.js';

let _vista = 'activas';

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Suscripciones</h1><small>Planes activos y calendario de entregas</small></div>
      <button class="btn" id="btn-nueva">+ Nueva suscripción</button>
    </div>
    <div style="display:flex; gap:8px; margin-bottom:16px">
      <button class="btn ghost sm" data-tab="activas">Activas</button>
      <button class="btn ghost sm" data-tab="entregas">Próximas entregas</button>
      <button class="btn ghost sm" data-tab="todas">Todas</button>
    </div>
    <div id="contenido"></div>`;
  root.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
    _vista = b.dataset.tab;
    root.querySelectorAll('[data-tab]').forEach(x => x.classList.toggle('active', x === b));
    recargar(root);
  }));
  root.querySelector('[data-tab=activas]').classList.add('active');
  root.querySelector('#btn-nueva').addEventListener('click', () => abrirFormulario(root));
  await recargar(root);
}

async function recargar(root) {
  const cont = root.querySelector('#contenido');
  cont.innerHTML = '<div class="empty-state">Cargando...</div>';
  if (_vista === 'entregas') return renderEntregas(cont);
  return renderSuscripciones(cont);
}

async function renderSuscripciones(cont) {
  let q = supabase.from('suscripciones').select('*, clientes:cliente_id(nombre), planes:plan_id(nombre)');
  if (_vista === 'activas') q = q.eq('estado', 'activa');
  q = q.order('cliente_id');
  const { data, error } = await q;
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  const rows = data || [];
  if (!rows.length) {
    cont.innerHTML = `<div class="card"><div class="empty-state"><div class="icon">🔁</div><p>Sin suscripciones</p></div></div>`;
    return;
  }
  const totalRecurrente = rows.filter(r => r.estado === 'activa').reduce((a,r) => a + (r.valor_mensual||0), 0);
  cont.innerHTML = `
    <div class="kpi-grid" style="margin-bottom:16px">
      <div class="kpi"><div class="label">Activas</div><div class="value">${rows.filter(r => r.estado==='activa').length}</div></div>
      <div class="kpi"><div class="label">Ingreso recurrente / mes</div><div class="value">${formatearCLP(totalRecurrente)}</div></div>
    </div>
    <div class="card" style="padding:0"><div class="table-wrap"><table class="data">
      <thead><tr>
        <th>Cliente</th><th>Plan</th><th>Frecuencia</th><th>Día</th>
        <th class="num">Bandejas/mes</th><th>Tamaño</th><th class="num">Valor</th>
        <th>Inicio</th><th>Estado</th><th class="actions">Acciones</th>
      </tr></thead>
      <tbody>${rows.map(r => `
        <tr data-id="${r.id}">
          <td>${escapeHTML(r.clientes?.nombre||'—')}</td>
          <td>${escapeHTML(r.planes?.nombre||'—')}</td>
          <td>${escapeHTML(r.frecuencia)}</td>
          <td>${escapeHTML(r.dia_planificado||'—')}</td>
          <td class="num">${r.bandejas_mes}</td>
          <td>${escapeHTML(r.tamano_huevo||'—')}</td>
          <td class="num">${formatearCLP(r.valor_mensual||0)}</td>
          <td>${formatearFecha(r.fecha_inicio)}</td>
          <td><span class="badge ${r.estado==='activa'?'ok':r.estado==='pausada'?'warn':'neutral'}">${r.estado}</span></td>
          <td class="actions">
            ${r.estado==='activa' ? '<button class="btn ghost sm" data-action="pausar">Pausar</button>' : ''}
            ${r.estado==='pausada' ? '<button class="btn ghost sm" data-action="reactivar">Reactivar</button>' : ''}
            <button class="btn ghost sm" data-action="cancelar">Cancelar</button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table></div></div>`;
  cont.querySelectorAll('button[data-action]').forEach(b => b.addEventListener('click', async () => {
    const id = b.closest('tr').dataset.id;
    const map = { pausar: 'pausada', reactivar: 'activa', cancelar: 'cancelada' };
    const nuevo = map[b.dataset.action];
    if (nuevo === 'cancelada' && !await confirmar('¿Cancelar esta suscripción?', { peligroso: true })) return;
    await supabase.from('suscripciones').update({ estado: nuevo }).eq('id', id);
    toast('Estado actualizado', 'ok');
    await recargar(root);
  }));
}

async function renderEntregas(cont) {
  const hoy = hoyISO();
  const en30 = new Date(Date.now() + 30*86400000).toISOString().slice(0,10);
  const { data } = await supabase
    .from('entregas')
    .select('*, suscripciones:suscripcion_id(clientes:cliente_id(nombre), planes:plan_id(nombre))')
    .gte('fecha_planificada', hoy).lte('fecha_planificada', en30)
    .order('fecha_planificada').limit(200);
  const rows = data || [];
  if (!rows.length) {
    cont.innerHTML = `<div class="card"><div class="empty-state"><div class="icon">📅</div><p>Sin entregas programadas en 30 días</p></div></div>`;
    return;
  }
  cont.innerHTML = `
    <div class="card" style="padding:0"><div class="table-wrap"><table class="data">
      <thead><tr>
        <th>Fecha planificada</th><th>Cliente</th><th>Plan</th>
        <th class="num">Bandejas</th><th>Tamaño</th><th class="num">Monto</th>
        <th>Estado</th><th>Pago</th><th class="actions">Acciones</th>
      </tr></thead>
      <tbody>${rows.map(e => `
        <tr data-id="${e.id}">
          <td>${formatearFecha(e.fecha_planificada)}</td>
          <td>${escapeHTML(e.suscripciones?.clientes?.nombre||'—')}</td>
          <td>${escapeHTML(e.suscripciones?.planes?.nombre||'—')}</td>
          <td class="num">${e.n_bandejas}</td>
          <td>${escapeHTML(e.tamano_huevo||'—')}</td>
          <td class="num">${formatearCLP(e.monto||0)}</td>
          <td><span class="badge ${e.estado==='entregada'?'ok':e.estado==='planificada'?'info':'neutral'}">${e.estado}</span></td>
          <td><span class="badge ${e.estado_pago==='pagado'?'ok':'warn'}">${e.estado_pago}</span></td>
          <td class="actions">
            ${e.estado==='planificada' ? '<button class="btn ghost sm" data-action="entregar">Marcar entregada</button>' : ''}
          </td>
        </tr>`).join('')}
      </tbody>
    </table></div></div>`;
  cont.querySelectorAll('button[data-action=entregar]').forEach(b => b.addEventListener('click', async () => {
    const id = b.closest('tr').dataset.id;
    await supabase.from('entregas').update({ estado: 'entregada', fecha_real: hoyISO() }).eq('id', id);
    toast('Entrega registrada', 'ok');
    await recargar(root);
  }));
}

async function abrirFormulario(root) {
  const [{ data: clientes }, { data: planes }] = await Promise.all([
    supabase.from('clientes').select('id, nombre').order('nombre'),
    supabase.from('planes').select('id, nombre, frecuencia, tamano_huevo, bandejas_mes, valor_mensual').eq('tipo', 'suscripcion')
  ]);
  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <form class="modal" style="max-width: 560px" id="form-sus">
      <div class="modal-header"><h2>Nueva suscripción</h2><button type="button" class="modal-close">&times;</button></div>
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1">
          <label>Cliente *</label>
          <select name="cliente_id" required>
            <option value="">—</option>
            ${(clientes||[]).map(c => `<option value="${c.id}">${escapeHTML(c.nombre)}</option>`).join('')}
          </select>
        </div>
        <div class="field" style="grid-column:1/-1">
          <label>Plan *</label>
          <select name="plan_id" required id="plan-sel">
            <option value="">—</option>
            ${(planes||[]).map(p => `<option value="${p.id}" data-frec="${p.frecuencia}" data-tamano="${p.tamano_huevo||''}" data-bands="${p.bandejas_mes||0}" data-valor="${p.valor_mensual||0}">${escapeHTML(p.nombre)} (${p.frecuencia}, ${p.tamano_huevo||'-'})</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Día planificado</label>
          <select name="dia_planificado">${LISTAS.DIAS_SEMANA.map(d => `<option value="${d}">${d}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Inicio</label><input type="date" name="fecha_inicio" value="${hoyISO()}"></div>
      </div>
      <div class="form-actions" style="justify-content:flex-end">
        <button type="button" class="btn ghost" data-action="cancel">Cancelar</button>
        <button type="submit" class="btn">Crear suscripción</button>
      </div>
    </form>`;
  document.body.appendChild(back);
  const form = back.querySelector('#form-sus');
  back.querySelector('.modal-close').addEventListener('click', () => back.remove());
  back.querySelector('[data-action=cancel]').addEventListener('click', () => back.remove());
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const opt = form.plan_id.options[form.plan_id.selectedIndex];
    const payload = {
      cliente_id: fd.get('cliente_id'),
      plan_id: fd.get('plan_id'),
      frecuencia: opt.dataset.frec || 'mensual',
      dia_planificado: fd.get('dia_planificado'),
      bandejas_mes: parseFloat(opt.dataset.bands) || 0,
      tamano_huevo: opt.dataset.tamano || null,
      valor_mensual: parseInt(opt.dataset.valor, 10) || 0,
      fecha_inicio: fd.get('fecha_inicio'),
      estado: 'activa'
    };
    const { error } = await supabase.from('suscripciones').insert(payload);
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast('Suscripción creada', 'ok');
    back.remove();
    await recargar(root);
  });
}
