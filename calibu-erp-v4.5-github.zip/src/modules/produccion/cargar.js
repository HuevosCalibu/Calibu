import { supabase } from '../../lib/supabase.js';
import { escapeHTML, hoyISO } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root, { perfil }) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>🥚 Carga diaria de producción</h1><small>Registra los huevos del día por lote</small></div>
    </div>
    <div class="card">
      <div class="form-grid">
        <div class="field"><label>Fecha *</label><input type="date" id="fecha" value="${hoyISO()}" max="${hoyISO()}"></div>
        <div class="field"><label>Cargado por</label><input type="text" value="${escapeHTML(perfil.nombre_display || 'Yo')}" readonly></div>
      </div>
    </div>
    <div id="lotes-cards" style="margin-top: 16px; display:grid; gap: 12px"></div>
    <div class="card" style="margin-top: 16px; position: sticky; bottom: 16px; box-shadow: 0 -2px 12px rgba(0,0,0,.08)">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap">
        <div>
          <div style="font-size:12px; color:var(--text-muted); text-transform:uppercase">Total del día</div>
          <div id="total" style="font-size:24px; font-weight:800; color:var(--calibu-primario)">0 huevos</div>
          <div id="sub-total" style="font-size:12px; color:var(--text-muted)"></div>
        </div>
        <button class="btn" id="btn-guardar" style="padding: 12px 24px; font-size: 16px">Guardar producción</button>
      </div>
    </div>`;

  const { data: lotes } = await supabase
    .from('lotes')
    .select('*, galpones:galpon_id(nombre)')
    .in('estado', ['activo_produccion','activo_pre_pico','activo_prueba'])
    .order('codigo');

  const cont = root.querySelector('#lotes-cards');
  if (!lotes?.length) {
    cont.innerHTML = '<div class="card"><div class="empty-state"><p>Sin lotes activos</p></div></div>';
    return;
  }
  cont.innerHTML = lotes.map(l => `
    <div class="card" data-lote="${l.id}">
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px">
        <div>
          <div style="display:flex; align-items:center; gap:8px">
            <span class="lote-codigo">${escapeHTML(l.codigo)}</span>
            <strong style="font-size:16px">${escapeHTML(l.raza)}</strong>
          </div>
          <small>${escapeHTML(l.galpones?.nombre||'')} · ${l.gallinas_actuales} gallinas</small>
        </div>
      </div>
      <div class="form-grid">
        <div class="field"><label>Huevos enteros</label><input type="number" min="0" data-field="enteros" inputmode="numeric" style="font-size:18px; padding:12px"></div>
        <div class="field"><label>Rotos</label><input type="number" min="0" value="0" data-field="rotos" inputmode="numeric"></div>
        <div class="field"><label>Mortalidades</label><input type="number" min="0" value="0" data-field="mortalidades" inputmode="numeric"></div>
        <div class="field"><label>Causa mortalidad</label><input type="text" data-field="causa" placeholder="Opcional"></div>
        <div class="field" style="grid-column:1/-1"><label>Observaciones</label><textarea data-field="obs" rows="2" placeholder="Opcional"></textarea></div>
      </div>
    </div>`).join('');

  const calcTotal = () => {
    let totalE = 0, totalR = 0, totalM = 0;
    cont.querySelectorAll('[data-lote]').forEach(card => {
      totalE += parseInt(card.querySelector('[data-field=enteros]').value || '0', 10);
      totalR += parseInt(card.querySelector('[data-field=rotos]').value || '0', 10);
      totalM += parseInt(card.querySelector('[data-field=mortalidades]').value || '0', 10);
    });
    root.querySelector('#total').textContent = totalE.toLocaleString('es-CL') + ' huevos';
    root.querySelector('#sub-total').textContent = `${totalR} rotos · ${totalM} mortalidades`;
  };
  cont.querySelectorAll('input, textarea').forEach(i => i.addEventListener('input', calcTotal));

  root.querySelector('#btn-guardar').addEventListener('click', async () => {
    const fecha = root.querySelector('#fecha').value;
    const filas = [];
    cont.querySelectorAll('[data-lote]').forEach(card => {
      const enteros = parseInt(card.querySelector('[data-field=enteros]').value || '0', 10);
      const rotos = parseInt(card.querySelector('[data-field=rotos]').value || '0', 10);
      const mort = parseInt(card.querySelector('[data-field=mortalidades]').value || '0', 10);
      if (enteros === 0 && rotos === 0 && mort === 0) return;
      filas.push({
        fecha,
        lote_id: card.dataset.lote,
        huevos_enteros: enteros,
        huevos_rotos: rotos,
        mortalidades: mort,
        causa_mortalidad: card.querySelector('[data-field=causa]').value || null,
        observaciones: card.querySelector('[data-field=obs]').value || null,
        cargado_por: perfil.id
      });
    });
    if (!filas.length) { toast('No hay datos para guardar', 'warn'); return; }
    const { error } = await supabase.from('produccion_diaria').upsert(filas, { onConflict: 'fecha,lote_id' });
    if (error) { toast('Error: ' + error.message, 'danger'); return; }
    toast(`${filas.length} lote(s) guardado(s)`, 'ok');
    setTimeout(() => location.hash = '#dashboard', 1500);
  });
}
