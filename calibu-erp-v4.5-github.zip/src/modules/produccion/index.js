import { supabase } from '../../lib/supabase.js';
import { formatearFecha, escapeHTML, hoyISO } from '../../lib/calc.js';
import { toast } from '../../lib/ui.js';

export async function render(root) {
  root.innerHTML = `
    <div class="section-header">
      <div><h1>Producción</h1><small>Lotes activos y registro histórico</small></div>
      <a href="#cargar-produccion" class="btn">📋 Cargar producción del día</a>
    </div>
    <div class="card" style="margin-bottom: 16px">
      <h3 class="card-title">Lotes en producción</h3>
      <div class="lotes-grid" id="lotes">Cargando...</div>
    </div>
    <div class="card" style="padding: 0">
      <div style="padding: 16px 16px 8px">
        <h3 class="card-title" style="margin:0">Producción últimos 14 días</h3>
      </div>
      <div class="table-wrap"><table class="data">
        <thead><tr>
          <th>Fecha</th><th>Lote</th><th>Galpón</th>
          <th class="num">Enteros</th><th class="num">Rotos</th>
          <th class="num">Mortalidad</th><th>Observaciones</th>
        </tr></thead>
        <tbody id="tbody"><tr><td colspan="7" style="text-align:center;padding:24px">Cargando...</td></tr></tbody>
      </table></div>
    </div>`;
  await Promise.all([cargarLotes(root), cargarHistorial(root)]);
}

async function cargarLotes(root) {
  const { data, error } = await supabase
    .from('lotes')
    .select('*, galpones:galpon_id(nombre)')
    .in('estado', ['activo_produccion','activo_pre_pico','activo_prueba'])
    .order('codigo');
  if (error) { toast('Error: ' + error.message, 'danger'); return; }
  const lotes = data || [];
  root.querySelector('#lotes').innerHTML = lotes.length ? lotes.map(l => {
    const pct = Math.round((l.postura_esperada_pct || 0) * 100);
    const teorico = Math.round((l.gallinas_actuales || 0) * (l.postura_esperada_pct || 0));
    return `
      <div class="lote-card">
        <div class="lote-head">
          <span class="lote-codigo">${escapeHTML(l.codigo)}</span>
          <div class="lote-raza">${escapeHTML(l.galpones?.nombre||'')}</div>
        </div>
        <div class="lote-raza" style="margin-bottom:8px">${escapeHTML(l.raza)} · ${escapeHTML(l.estado.replace('activo_',''))}</div>
        <div class="lote-stats">
          <div class="lote-stat"><div class="lote-stat-label">Gallinas</div><div class="lote-stat-value">${(l.gallinas_actuales||0).toLocaleString('es-CL')}</div></div>
          <div class="lote-stat"><div class="lote-stat-label">Huevos/día</div><div class="lote-stat-value">${teorico}</div></div>
          <div class="lote-stat"><div class="lote-stat-label">% Postura</div><div class="lote-stat-value">${pct}%</div></div>
        </div>
        <div class="lote-progress"><div style="width: ${pct}%"></div></div>
      </div>`;
  }).join('') : '<div class="empty-state"><small>Sin lotes activos</small></div>';
}

async function cargarHistorial(root) {
  const desde = new Date(Date.now() - 14*86400000).toISOString().slice(0,10);
  const { data } = await supabase
    .from('produccion_diaria')
    .select('*, lotes:lote_id(codigo, galpones:galpon_id(nombre))')
    .gte('fecha', desde).order('fecha', { ascending: false }).order('lote_id').limit(100);
  const rows = data || [];
  const tbody = root.querySelector('#tbody');
  if (!rows.length) { tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="icon">🥚</div><p>Sin registros recientes</p></div></td></tr>`; return; }
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td>${formatearFecha(r.fecha)}</td>
      <td><span class="badge neutral">${escapeHTML(r.lotes?.codigo||'—')}</span></td>
      <td>${escapeHTML(r.lotes?.galpones?.nombre||'—')}</td>
      <td class="num">${r.huevos_enteros}</td>
      <td class="num">${r.huevos_rotos}</td>
      <td class="num">${r.mortalidades>0 ? `<span style="color:var(--danger);font-weight:600">${r.mortalidades}</span>` : '0'}</td>
      <td>${escapeHTML(r.observaciones||'—')}</td>
    </tr>`).join('');
}
