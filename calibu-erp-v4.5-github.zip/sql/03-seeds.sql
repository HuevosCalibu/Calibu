-- =====================================================================
-- CALIBÚ ERP — DATOS INICIALES (seeds)
-- Extraídos de la planilla operativa real "Calibu Empresa 2.4.xlsx"
-- =====================================================================

-- ---------------------------------------------------------------------
-- GALPONES
-- ---------------------------------------------------------------------
insert into public.galpones (nombre, m2_galpon, m2_patio, capacidad_max) values
  ('Galpón 1', 80,  1000, 500),
  ('Galpón 2', 100, 1200, 800);

-- ---------------------------------------------------------------------
-- LOTES (estado actual del Excel)
-- ---------------------------------------------------------------------
insert into public.lotes (codigo, galpon_id, raza, fecha_nacimiento, gallinas_ingreso, gallinas_actuales, postura_esperada_pct, estado, notas)
select 'L01', g.id, 'Lohmann White', '2025-01-01', 30,  7,   0.75, 'activo_prueba',     'Lote antiguo, recambio fin de año'
from public.galpones g where g.nombre = 'Galpón 1';

insert into public.lotes (codigo, galpon_id, raza, fecha_nacimiento, gallinas_ingreso, gallinas_actuales, postura_esperada_pct, estado, notas)
select 'L02', g.id, 'Hyline Brown',  '2025-02-10', 395, 302, 0.80, 'activo_produccion', 'Lote en plena producción'
from public.galpones g where g.nombre = 'Galpón 1';

insert into public.lotes (codigo, galpon_id, raza, fecha_nacimiento, gallinas_ingreso, gallinas_actuales, postura_esperada_pct, estado, notas)
select 'L03', g.id, 'Lohmann Brown', '2026-01-05', 650, 641, 0.02, 'activo_pre_pico',   'Lote nuevo, recién entrando a postura'
from public.galpones g where g.nombre = 'Galpón 2';

-- ---------------------------------------------------------------------
-- PLANES — Suscripciones + Mayorista (price book oficial)
-- ---------------------------------------------------------------------
insert into public.planes
  (nombre, tipo, frecuencia, tamano_huevo, bandejas_mes, bandejas_entrega, huevos_bandeja, valor_mensual, precio_entrega, iva_aplica, activo) values
  -- Suscripciones quincenales (2 bandejas/mes)
  ('Cascaron',     'suscripcion', 'quincenal', 'S',  2, 1, 30, 13500,  6750, false, true),
  ('Ponedora',     'suscripcion', 'quincenal', 'M',  2, 1, 30, 17900,  8950, false, true),
  ('Doña Gallina', 'suscripcion', 'quincenal', 'L',  2, 1, 30, 19500,  9750, false, true),
  ('Nido Jumbo',   'suscripcion', 'quincenal', 'XL', 2, 1, 30, 22000, 11000, false, true),
  -- Suscripciones semanales (4 bandejas/mes)
  ('Gallinero',    'suscripcion', 'semanal',   'M',  4, 1, 30, 35000,  8750, false, true),
  ('Gran Calibu',  'suscripcion', 'semanal',   'L',  4, 1, 30, 38500,  9625, false, true),
  ('Jumbo Calibu', 'suscripcion', 'semanal',   'XL', 4, 1, 30, 42000, 10500, false, true);

insert into public.planes
  (nombre, tipo, tamano_huevo, huevos_bandeja, precio_neto, precio_con_iva, iva_aplica, activo) values
  ('Empresa M',  'mayorista', 'M',  180, 45000, 53550, true, true),
  ('Empresa L',  'mayorista', 'L',  180, 48000, 57120, true, true),
  ('Empresa XL', 'mayorista', 'XL', 180, 51000, 60690, true, true);

-- ---------------------------------------------------------------------
-- PROVEEDORES (extraídos de Compras del Excel)
-- ---------------------------------------------------------------------
insert into public.proveedores (nombre, categoria_principal) values
  ('Aramco',              'Combustible'),
  ('Ferretería Arique',   'Insumos chicos'),
  ('Champion',            'Alimento'),
  ('Aves Sandoval',       'Alimento');

-- ---------------------------------------------------------------------
-- INSUMOS — catálogo base con stock inicial del Excel
-- ---------------------------------------------------------------------
insert into public.insumos
  (nombre, unidad, consumo_unitario_desc, stock_actual, consumo_diario_estimado, dias_alerta_amarillo, dias_alerta_rojo, categoria, activo) values
  ('Cajas bandeja 30 unidades',       'unidades', '2 por pedido (sándwich)',    750, 9.45,    10, 5, 'Cajas y embalaje', true),
  ('Cajas docena 12 unidades',        'unidades', '1 por venta a local',        900, 10.43,   10, 5, 'Cajas y embalaje', true),
  ('Cajas media docena 6 unidades',   'unidades', '1 por venta tipo 6',         200, 2.065,   10, 5, 'Cajas y embalaje', true),
  ('Etiqueta grande (caja 12)',       'unidades', '1 por caja 12u',             160, 10.43,   10, 5, 'Etiquetas',        true),
  ('Etiqueta chica (caja 6)',         'unidades', '1 por caja 6u',              100, 2.065,   10, 5, 'Etiquetas',        true),
  ('Etiqueta envoltura bandeja 30',   'unidades', '1 por pedido B30 (faja)',      0, 4.725,   10, 5, 'Etiquetas',        true),
  ('Pita (rollos 1000m)',             'rollos',   '2,5 m por pedido B30',       143, 0.0118,  10, 5, 'Insumos chicos',   true),
  ('Alimento inicial (saco 25kg)',    'sacos',    '110 g/día por gallina',       95, 3.9,     10, 5, 'Alimento',         true),
  ('Mascarillas',                     'caja 50',  '1 por uso',                    0, 1.0,     10, 5, 'Insumos chicos',   true),
  ('Guantes látex/nitrilo',           'caja 100', '1 por uso',                    0, 2.0,     10, 5, 'Insumos chicos',   true);

-- ---------------------------------------------------------------------
-- SUPUESTOS MENSUALES — modelo financiero base (mayo 2026)
-- ---------------------------------------------------------------------
insert into public.supuestos_mensuales (anio_mes, concepto, valor, notas) values
  ('2026-05', 'Gallinas Hy-Line Brown', 290,   'Lote antiguo, recambio fin de año'),
  ('2026-05', 'Gallinas Lohmann Brown', 600,   'Lote nuevo, recién entrando a postura'),
  ('2026-05', 'Total gallinas',         890,   'Suma'),
  ('2026-05', 'UTM',                    68306, 'CLP'),
  ('2026-05', 'UF',                     38441, 'CLP');

-- ---------------------------------------------------------------------
-- DISTRIBUCIÓN DE CANALES (modelo)
-- ---------------------------------------------------------------------
insert into public.ingresos_proyectados (anio_mes, canal, bandejas_mes, valor_estimado, notas) values
  ('2026-05', 'mayorista',   284.8, null, '40% de canal'),
  ('2026-05', 'suscripcion', 249.2, null, '35% de canal'),
  ('2026-05', 'directa',     178.0, null, '25% de canal');

-- ---------------------------------------------------------------------
-- COSTOS MENSUALES BASE
-- ---------------------------------------------------------------------
insert into public.costos_mensuales (anio_mes, concepto, cantidad, precio_unitario, total, tipo, notas) values
  ('2026-05', 'Alimento (sacos 25 kg)',          117.48, 12605, 1480835, 'variable', 'Sin IVA, IVA crédito recuperable'),
  ('2026-05', 'Cajas docena 12u (locales)',      712,    180,   128160,  'variable', '1 caja por docena'),
  ('2026-05', 'Etiquetas caja 12u',              712,    90,    64080,   'variable', '1 etiqueta por caja'),
  ('2026-05', 'Cajas bandeja 30u (sándwich)',    854.4,  105,   89712,   'variable', '2 bandejas por pedido (arriba+abajo)');
