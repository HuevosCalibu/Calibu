-- =====================================================================
-- CALIBÚ ERP — SCHEMA COMPLETO (MVP + Fase 2)
-- PostgreSQL / Supabase
-- =====================================================================
-- Orden de ejecución:
--   1. Crear proyecto Supabase
--   2. Ejecutar este archivo en el SQL Editor
--   3. Ejecutar 02-rls-policies.sql
--   4. Ejecutar 03-seeds.sql
-- =====================================================================

create extension if not exists "pgcrypto";

-- Helper: trigger para mantener updated_at
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- =====================================================================
-- AUTH / USUARIOS
-- =====================================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nombre_display text not null,
  rol text not null check (rol in ('admin','trabajador')),
  empleado_id uuid,
  activo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

-- =====================================================================
-- RRHH — Módulo 1
-- =====================================================================
create table public.empleados (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  rut text not null unique,
  cargo text,
  area text,
  tipo_contrato text check (tipo_contrato in ('indefinido','plazo_fijo','obra_faena','honorarios')),
  afp text check (afp in ('Capital','Cuprum','Habitat','Modelo','PlanVital','ProVida','Uno')),
  prevision_salud text check (prevision_salud in ('Fonasa','Isapre')),
  isapre_nombre text,
  isapre_plan_uf numeric(10,4),
  sueldo_base integer not null default 0,
  tipo_jornada text check (tipo_jornada in ('completa_42hrs','parcial','por_dia','honorarios')),
  horas_semanales numeric(5,2),
  direccion text,
  telefono text,
  email text,
  fecha_nacimiento date,
  fecha_ingreso date,
  fecha_termino date,
  estado text not null default 'activo' check (estado in ('activo','licencia','vacaciones','desvinculado')),
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_empleados_estado on public.empleados(estado);
create trigger trg_empleados_updated before update on public.empleados
  for each row execute function public.set_updated_at();

alter table public.profiles
  add constraint fk_profiles_empleado
  foreign key (empleado_id) references public.empleados(id) on delete set null;

create table public.vacaciones (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  fecha_solicitud date not null default current_date,
  fecha_desde date not null,
  fecha_hasta date not null,
  dias_habiles numeric(5,2) not null,
  estado text not null default 'solicitada' check (estado in ('solicitada','aprobada','rechazada','tomada','cancelada')),
  aprobada_por uuid references public.profiles(id),
  fecha_aprobacion timestamptz,
  motivo_rechazo text,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_vacaciones_empleado on public.vacaciones(empleado_id);
create index idx_vacaciones_estado on public.vacaciones(estado);
create trigger trg_vacaciones_updated before update on public.vacaciones
  for each row execute function public.set_updated_at();

create table public.anticipos (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  fecha date not null default current_date,
  monto integer not null,
  descripcion text,
  mes_descuento text,
  descontado boolean not null default false,
  liquidacion_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_anticipos_empleado on public.anticipos(empleado_id);
create index idx_anticipos_mes on public.anticipos(mes_descuento);
create trigger trg_anticipos_updated before update on public.anticipos
  for each row execute function public.set_updated_at();

create table public.liquidaciones (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  anio_mes text not null,
  dias_trabajados integer,
  sueldo_base integer not null,
  gratificacion integer default 0,
  horas_extras integer default 0,
  bonos integer default 0,
  total_haberes_imponibles integer not null,
  total_haberes_no_imponibles integer default 0,
  total_haberes integer not null,
  afp_monto integer not null,
  afp_comision integer not null,
  salud_monto integer not null,
  seguro_cesantia_trabajador integer default 0,
  anticipos_monto integer default 0,
  otros_descuentos integer default 0,
  total_descuentos integer not null,
  liquido integer not null,
  costo_empleador_sis integer default 0,
  costo_empleador_cesantia integer default 0,
  costo_empleador_total integer default 0,
  pdf_url text,
  estado text not null default 'borrador' check (estado in ('borrador','emitida','pagada')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (empleado_id, anio_mes)
);
create index idx_liquidaciones_empleado on public.liquidaciones(empleado_id);
create index idx_liquidaciones_mes on public.liquidaciones(anio_mes);
create trigger trg_liquidaciones_updated before update on public.liquidaciones
  for each row execute function public.set_updated_at();

alter table public.anticipos
  add constraint fk_anticipos_liquidacion
  foreign key (liquidacion_id) references public.liquidaciones(id) on delete set null;

create table public.finiquitos (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  fecha_termino date not null,
  causal_articulo text not null,
  causal_descripcion text,
  anios_servicio numeric(5,2),
  ias integer default 0,
  ias_topeado boolean default false,
  feriado_proporcional integer default 0,
  feriado_pendiente integer default 0,
  aviso_previo integer default 0,
  sueldo_proporcional integer default 0,
  otros_haberes integer default 0,
  total_a_pagar integer not null,
  pdf_url text,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_finiquitos_updated before update on public.finiquitos
  for each row execute function public.set_updated_at();

create table public.documentos_empleado (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  tipo text not null check (tipo in ('contrato','anexo','certificado','licencia','otro')),
  titulo text not null,
  archivo_url text,
  fecha date not null default current_date,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_documentos_empleado on public.documentos_empleado(empleado_id);
create trigger trg_documentos_updated before update on public.documentos_empleado
  for each row execute function public.set_updated_at();

create table public.asistencia (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  fecha date not null,
  entrada timestamptz,
  salida timestamptz,
  lat_entrada numeric(10,7),
  lng_entrada numeric(10,7),
  lat_salida numeric(10,7),
  lng_salida numeric(10,7),
  horas_trabajadas numeric(5,2),
  observaciones text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (empleado_id, fecha)
);
create index idx_asistencia_empleado_fecha on public.asistencia(empleado_id, fecha desc);
create trigger trg_asistencia_updated before update on public.asistencia
  for each row execute function public.set_updated_at();

create table public.evaluaciones_desempeno (
  id uuid primary key default gen_random_uuid(),
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  periodo text not null,
  objetivos jsonb default '[]'::jsonb,
  calificacion numeric(3,1),
  fortalezas text,
  oportunidades_mejora text,
  comentarios text,
  evaluador_id uuid references public.profiles(id),
  fecha_evaluacion date default current_date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_evaluaciones_updated before update on public.evaluaciones_desempeno
  for each row execute function public.set_updated_at();

-- =====================================================================
-- PRODUCCIÓN — Módulo 2
-- =====================================================================
create table public.galpones (
  id uuid primary key default gen_random_uuid(),
  nombre text not null unique,
  m2_galpon numeric(8,2),
  m2_patio numeric(8,2),
  capacidad_max integer,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_galpones_updated before update on public.galpones
  for each row execute function public.set_updated_at();

create table public.lotes (
  id uuid primary key default gen_random_uuid(),
  codigo text not null unique,
  galpon_id uuid not null references public.galpones(id),
  raza text not null,
  fecha_nacimiento date not null,
  gallinas_ingreso integer not null,
  gallinas_actuales integer not null,
  postura_esperada_pct numeric(4,3),
  estado text not null check (estado in ('activo_prueba','activo_produccion','activo_pre_pico','recambio','terminado')),
  fecha_termino date,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_lotes_galpon on public.lotes(galpon_id);
create index idx_lotes_estado on public.lotes(estado);
create trigger trg_lotes_updated before update on public.lotes
  for each row execute function public.set_updated_at();

create table public.produccion_diaria (
  id uuid primary key default gen_random_uuid(),
  fecha date not null,
  lote_id uuid not null references public.lotes(id),
  huevos_enteros integer not null default 0,
  huevos_rotos integer not null default 0,
  mortalidades integer not null default 0,
  causa_mortalidad text,
  observaciones text,
  cargado_por uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (fecha, lote_id)
);
create index idx_produccion_fecha on public.produccion_diaria(fecha desc);
create index idx_produccion_lote on public.produccion_diaria(lote_id);
create trigger trg_produccion_updated before update on public.produccion_diaria
  for each row execute function public.set_updated_at();

create or replace function public.aplicar_mortalidad_lote()
returns trigger language plpgsql as $$
begin
  if new.mortalidades > 0 then
    update public.lotes
       set gallinas_actuales = greatest(0, gallinas_actuales - new.mortalidades)
     where id = new.lote_id;
  end if;
  return new;
end $$;
create trigger trg_produccion_mortalidad after insert on public.produccion_diaria
  for each row execute function public.aplicar_mortalidad_lote();

-- =====================================================================
-- VENTAS Y CLIENTES — Módulo 3
-- =====================================================================
create table public.clientes (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  rut text,
  razon_social text,
  direccion text,
  comuna text,
  telefono text,
  email text,
  canal_principal text check (canal_principal in ('directa','mayorista','suscripcion','mixto')),
  estado text not null default 'activo' check (estado in ('activo','inactivo','potencial')),
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_clientes_nombre on public.clientes(nombre);
create index idx_clientes_canal on public.clientes(canal_principal);
create trigger trg_clientes_updated before update on public.clientes
  for each row execute function public.set_updated_at();

create table public.planes (
  id uuid primary key default gen_random_uuid(),
  nombre text not null unique,
  tipo text not null check (tipo in ('suscripcion','mayorista','directa')),
  frecuencia text check (frecuencia in ('semanal','quincenal','mensual','unica')),
  tamano_huevo text check (tamano_huevo in ('XS','S','M','L','XL')),
  bandejas_mes numeric(5,2),
  bandejas_entrega numeric(5,2),
  huevos_bandeja integer,
  valor_mensual integer,
  precio_entrega integer,
  precio_neto integer,
  precio_con_iva integer,
  iva_aplica boolean not null default false,
  activo boolean not null default true,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_planes_updated before update on public.planes
  for each row execute function public.set_updated_at();

create table public.ventas (
  id uuid primary key default gen_random_uuid(),
  fecha date not null default current_date,
  cliente_id uuid not null references public.clientes(id),
  canal text not null check (canal in ('directa','mayorista','suscripcion')),
  plan_id uuid references public.planes(id),
  tipo_bandeja integer,
  n_bandejas numeric(8,2) not null,
  tamano_huevo text check (tamano_huevo in ('XS','S','M','L','XL')),
  n_huevos integer not null,
  precio_unitario integer not null,
  total integer not null,
  estado_pago text not null default 'pendiente' check (estado_pago in ('pagado','pendiente','vencido','anulado','gratis')),
  medio_pago text check (medio_pago in ('transferencia','efectivo','debito','credito','factura_30')),
  fecha_pago date,
  numero_documento text,
  vendido_por uuid references public.profiles(id),
  entrega_id uuid,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_ventas_fecha on public.ventas(fecha desc);
create index idx_ventas_cliente on public.ventas(cliente_id);
create index idx_ventas_canal on public.ventas(canal);
create index idx_ventas_estado_pago on public.ventas(estado_pago);
create trigger trg_ventas_updated before update on public.ventas
  for each row execute function public.set_updated_at();

-- =====================================================================
-- SUSCRIPCIONES — Módulo 4
-- =====================================================================
create table public.suscripciones (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references public.clientes(id),
  plan_id uuid not null references public.planes(id),
  frecuencia text not null check (frecuencia in ('semanal','quincenal','mensual')),
  dia_planificado text,
  bandejas_mes numeric(5,2),
  tamano_huevo text,
  valor_mensual integer,
  fecha_inicio date not null default current_date,
  fecha_fin date,
  estado text not null default 'activa' check (estado in ('activa','pausada','cancelada')),
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_suscripciones_cliente on public.suscripciones(cliente_id);
create index idx_suscripciones_estado on public.suscripciones(estado);
create trigger trg_suscripciones_updated before update on public.suscripciones
  for each row execute function public.set_updated_at();

create table public.entregas (
  id uuid primary key default gen_random_uuid(),
  suscripcion_id uuid not null references public.suscripciones(id) on delete cascade,
  fecha_planificada date not null,
  fecha_real date,
  n_bandejas numeric(5,2) not null,
  tamano_huevo text,
  estado text not null default 'planificada' check (estado in ('planificada','entregada','no_entregada','reagendada','cancelada')),
  estado_pago text not null default 'pendiente' check (estado_pago in ('pagado','pendiente','vencido','gratis')),
  monto integer,
  venta_id uuid references public.ventas(id),
  observaciones text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_entregas_suscripcion on public.entregas(suscripcion_id);
create index idx_entregas_fecha on public.entregas(fecha_planificada);
create index idx_entregas_estado on public.entregas(estado);
create trigger trg_entregas_updated before update on public.entregas
  for each row execute function public.set_updated_at();

alter table public.ventas
  add constraint fk_ventas_entrega
  foreign key (entrega_id) references public.entregas(id) on delete set null;

-- =====================================================================
-- COMPRAS Y STOCK — Fase 2
-- =====================================================================
create table public.proveedores (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  rut text,
  contacto text,
  telefono text,
  email text,
  categoria_principal text,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_proveedores_updated before update on public.proveedores
  for each row execute function public.set_updated_at();

create table public.compras (
  id uuid primary key default gen_random_uuid(),
  fecha date not null default current_date,
  categoria text not null,
  proveedor_id uuid references public.proveedores(id),
  descripcion text,
  cantidad numeric(10,3),
  precio_unit integer,
  total_neto integer not null,
  iva integer default 0,
  total_con_iva integer not null,
  estado_pago text not null default 'pendiente' check (estado_pago in ('pagado','pendiente','vencido')),
  medio_pago text,
  numero_documento text,
  comprobante_url text,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_compras_fecha on public.compras(fecha desc);
create index idx_compras_categoria on public.compras(categoria);
create trigger trg_compras_updated before update on public.compras
  for each row execute function public.set_updated_at();

create table public.insumos (
  id uuid primary key default gen_random_uuid(),
  nombre text not null unique,
  unidad text not null,
  consumo_unitario_desc text,
  stock_actual numeric(10,3) not null default 0,
  consumo_diario_estimado numeric(10,3),
  dias_alerta_amarillo integer default 10,
  dias_alerta_rojo integer default 5,
  precio_referencia integer,
  categoria text,
  activo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_insumos_updated before update on public.insumos
  for each row execute function public.set_updated_at();

create table public.movimientos_stock (
  id uuid primary key default gen_random_uuid(),
  insumo_id uuid not null references public.insumos(id),
  tipo text not null check (tipo in ('entrada','salida','ajuste','merma')),
  cantidad numeric(10,3) not null,
  fecha timestamptz not null default now(),
  compra_id uuid references public.compras(id),
  motivo text,
  registrado_por uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create index idx_movs_insumo on public.movimientos_stock(insumo_id);
create index idx_movs_fecha on public.movimientos_stock(fecha desc);

create or replace function public.aplicar_movimiento_stock()
returns trigger language plpgsql as $$
begin
  if new.tipo = 'entrada' then
    update public.insumos set stock_actual = stock_actual + new.cantidad where id = new.insumo_id;
  elsif new.tipo in ('salida','merma') then
    update public.insumos set stock_actual = greatest(0, stock_actual - new.cantidad) where id = new.insumo_id;
  elsif new.tipo = 'ajuste' then
    update public.insumos set stock_actual = new.cantidad where id = new.insumo_id;
  end if;
  return new;
end $$;
create trigger trg_movs_aplicar after insert on public.movimientos_stock
  for each row execute function public.aplicar_movimiento_stock();

-- =====================================================================
-- MODELO FINANCIERO — Fase 2
-- =====================================================================
create table public.supuestos_mensuales (
  id uuid primary key default gen_random_uuid(),
  anio_mes text not null,
  concepto text not null,
  valor numeric(14,4),
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (anio_mes, concepto)
);
create trigger trg_supuestos_updated before update on public.supuestos_mensuales
  for each row execute function public.set_updated_at();

create table public.ingresos_proyectados (
  id uuid primary key default gen_random_uuid(),
  anio_mes text not null,
  canal text not null,
  bandejas_mes numeric(10,2),
  valor_estimado integer,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_ingresos_updated before update on public.ingresos_proyectados
  for each row execute function public.set_updated_at();

create table public.costos_mensuales (
  id uuid primary key default gen_random_uuid(),
  anio_mes text not null,
  concepto text not null,
  cantidad numeric(10,3),
  precio_unitario integer,
  total integer not null,
  tipo text check (tipo in ('variable','fijo','inversion')),
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_costos_mes on public.costos_mensuales(anio_mes);
create trigger trg_costos_updated before update on public.costos_mensuales
  for each row execute function public.set_updated_at();

-- =====================================================================
-- VISTAS ÚTILES
-- =====================================================================
create or replace view public.v_top_clientes as
select c.id, c.nombre, c.canal_principal,
       count(v.id) as n_compras,
       coalesce(sum(v.n_huevos), 0) as n_huevos,
       coalesce(sum(v.total), 0) as total_comprado,
       max(v.fecha) as ultima_compra
from public.clientes c
left join public.ventas v on v.cliente_id = c.id and v.estado_pago != 'anulado'
group by c.id, c.nombre, c.canal_principal;

create or replace view public.v_resumen_mensual_ventas as
select to_char(fecha, 'YYYY-MM') as anio_mes, canal,
       count(*) as n_transacciones,
       sum(n_huevos) as huevos,
       sum(total) as total
from public.ventas
where estado_pago != 'anulado'
group by 1, 2;

create or replace view public.v_produccion_galpon as
select pd.fecha, g.nombre as galpon,
       sum(pd.huevos_enteros) as huevos_enteros,
       sum(pd.huevos_rotos) as huevos_rotos,
       sum(pd.mortalidades) as mortalidades
from public.produccion_diaria pd
join public.lotes l on l.id = pd.lote_id
join public.galpones g on g.id = l.galpon_id
group by pd.fecha, g.nombre;

create or replace view public.v_stock_alertas as
select i.id, i.nombre, i.unidad, i.stock_actual, i.consumo_diario_estimado,
       case when coalesce(i.consumo_diario_estimado,0) = 0 then null
            else (i.stock_actual / i.consumo_diario_estimado)::numeric(10,1)
       end as dias_stock,
       case
         when coalesce(i.consumo_diario_estimado,0) = 0 then 'blanco'
         when i.stock_actual = 0 then 'rojo'
         when (i.stock_actual / nullif(i.consumo_diario_estimado,0)) <= i.dias_alerta_rojo then 'rojo'
         when (i.stock_actual / nullif(i.consumo_diario_estimado,0)) <= i.dias_alerta_amarillo then 'amarillo'
         else 'verde'
       end as semaforo
from public.insumos i
where i.activo = true;

-- =====================================================================
-- HABILITAR RLS (políticas en 02-rls-policies.sql)
-- =====================================================================
alter table public.profiles                enable row level security;
alter table public.empleados               enable row level security;
alter table public.vacaciones              enable row level security;
alter table public.anticipos               enable row level security;
alter table public.liquidaciones           enable row level security;
alter table public.finiquitos              enable row level security;
alter table public.documentos_empleado     enable row level security;
alter table public.asistencia              enable row level security;
alter table public.evaluaciones_desempeno  enable row level security;
alter table public.galpones                enable row level security;
alter table public.lotes                   enable row level security;
alter table public.produccion_diaria       enable row level security;
alter table public.clientes                enable row level security;
alter table public.planes                  enable row level security;
alter table public.ventas                  enable row level security;
alter table public.suscripciones           enable row level security;
alter table public.entregas                enable row level security;
alter table public.proveedores             enable row level security;
alter table public.compras                 enable row level security;
alter table public.insumos                 enable row level security;
alter table public.movimientos_stock       enable row level security;
alter table public.supuestos_mensuales     enable row level security;
alter table public.ingresos_proyectados    enable row level security;
alter table public.costos_mensuales        enable row level security;
