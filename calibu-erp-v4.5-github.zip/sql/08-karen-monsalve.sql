-- =====================================================================
-- Calibú ERP — Agregar empleada Karen Monsalve
-- Ejecutar en Supabase Dashboard > SQL Editor
-- =====================================================================

-- 1. Insertar empleada (ajusta los datos reales antes de ejecutar)
INSERT INTO public.empleados (
  nombre,
  rut,
  cargo,
  area,
  tipo_contrato,
  tipo_jornada,
  horas_semanales,
  sueldo_base,
  afp,
  prevision_salud,
  fecha_ingreso,
  estado,
  pin_kiosk   -- PIN de 4 dígitos para el kiosk de marcaje (cambiar antes de ejecutar)
) VALUES (
  'Karen Monsalve',
  '00.000.000-0',        -- ⚠️ COMPLETAR con RUT real
  'Asistente Avícola',
  'Producción',
  'indefinido',          -- Ajustar según contrato
  'completa_42hrs',
  42,
  620000,                -- ⚠️ COMPLETAR con sueldo real
  'Habitat',             -- ⚠️ COMPLETAR con AFP real
  'Fonasa',              -- ⚠️ COMPLETAR si es Isapre
  CURRENT_DATE,
  'activo',
  '1234'                 -- ⚠️ CAMBIAR a PIN real antes de ejecutar
);

-- 2. Crear cuenta de usuario en Supabase Auth
-- Esto debes hacerlo desde el Dashboard de Supabase:
--   Authentication > Users > Add user
--   Email: karen@calibu.cl (o el email que uses)
--   Password: (una temporal, ella la cambia al primer login)
--
-- Luego vincula el usuario al empleado con este SQL
-- (reemplaza el email y el nombre):

/*
INSERT INTO public.perfiles (id, nombre_display, rol, empleado_id)
SELECT 
  au.id,
  'Karen Monsalve',
  'trabajador',
  e.id
FROM auth.users au
CROSS JOIN public.empleados e
WHERE au.email = 'karen@calibu.cl'   -- ⚠️ reemplazar con email real
  AND e.nombre = 'Karen Monsalve'
ON CONFLICT (id) DO UPDATE SET
  nombre_display = EXCLUDED.nombre_display,
  rol = EXCLUDED.rol,
  empleado_id = EXCLUDED.empleado_id;
*/
