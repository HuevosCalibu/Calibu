-- =====================================================================
-- CALIBÚ ERP v3.0 — Fix de datos demo
-- =====================================================================
-- 1. Eliminar todas las ventas demo basura
-- 2. Insertar ventas realistas con totales por cliente del Excel real
-- 3. Producción de HOY actualizada
-- =====================================================================

-- LIMPIEZA
delete from public.ventas;
delete from public.entregas;
delete from public.produccion_diaria;

-- ============== TOP CLIENTES con totales realistas ==============
-- Para cada cliente top, generar ventas distribuidas en 9 meses
-- que sumen su total real del Excel

do $$
declare
  v_cliente_id uuid;
  v_meses text[] := ARRAY['2025-09','2025-10','2025-11','2025-12','2026-01','2026-02','2026-03','2026-04','2026-05'];
  v_mes text;
  v_compras_por_mes int;
  v_monto_por_compra int;
  v_dia int;
  v_canal text;
  v_tipo_bandeja int;
  v_n_bandejas numeric;
  v_precio int;
begin
  -- Comercial Romance: 46 compras, total $1843545
  select id into v_cliente_id from public.clientes where nombre = 'Comercial Romance' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 46 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 40077 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Multisur: 21 compras, total $1486436
  select id into v_cliente_id from public.clientes where nombre = 'Multisur' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 21 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 70782 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Baguales: 18 compras, total $1288266
  select id into v_cliente_id from public.clientes where nombre = 'Baguales' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 18 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 71570 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Frutería Los Robles: 27 compras, total $1222577
  select id into v_cliente_id from public.clientes where nombre = 'Frutería Los Robles' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 27 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 45280 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Erich Lagos: 12 compras, total $803534
  select id into v_cliente_id from public.clientes where nombre = 'Erich Lagos' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 12 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 66961 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Local Las Rosas: 14 compras, total $736705
  select id into v_cliente_id from public.clientes where nombre = 'Local Las Rosas' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 14 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 52621 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Casa Lumbre: 10 compras, total $560440
  select id into v_cliente_id from public.clientes where nombre = 'Casa Lumbre' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 10 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 56044 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Botacura: 21 compras, total $539070
  select id into v_cliente_id from public.clientes where nombre = 'Botacura' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 21 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 25670 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Fruteria Que te importa: 7 compras, total $377082
  select id into v_cliente_id from public.clientes where nombre = 'Fruteria Que te importa' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 7 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 53868 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- David Silva: 12 compras, total $353500
  select id into v_cliente_id from public.clientes where nombre = 'David Silva' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 12 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 29458 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 3, 'L',
          90, v_monto_por_compra / 3, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Pauli Gutierrez VS: 14 compras, total $341875
  select id into v_cliente_id from public.clientes where nombre = 'Pauli Gutierrez VS' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 14 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 24419 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Javi Tapia: 15 compras, total $330075
  select id into v_cliente_id from public.clientes where nombre = 'Javi Tapia' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 15 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 22005 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Cata Rodriguez: 13 compras, total $293000
  select id into v_cliente_id from public.clientes where nombre = 'Cata Rodriguez' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 13 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 22538 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Fran Yoga: 12 compras, total $260180
  select id into v_cliente_id from public.clientes where nombre = 'Fran Yoga' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 12 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 21681 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Paula Windsor: 11 compras, total $258200
  select id into v_cliente_id from public.clientes where nombre = 'Paula Windsor' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 11 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 23472 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Ingrid Ramirez: 12 compras, total $254000
  select id into v_cliente_id from public.clientes where nombre = 'Ingrid Ramirez' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 12 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 21166 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Millarai: 13 compras, total $245655
  select id into v_cliente_id from public.clientes where nombre = 'Millarai' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 13 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 18896 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 1, 'L',
          30, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Sofi Kramm: 9 compras, total $227750
  select id into v_cliente_id from public.clientes where nombre = 'Sofi Kramm' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 9 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 25305 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 3, 'L',
          90, v_monto_por_compra / 3, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Carlos Larrañaga: 11 compras, total $227200
  select id into v_cliente_id from public.clientes where nombre = 'Carlos Larrañaga' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 11 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 20654 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Mary Mawenche: 17 compras, total $215500
  select id into v_cliente_id from public.clientes where nombre = 'Mary Mawenche' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 17 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 12676 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'directa', 30, 1, 'L',
          30, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Cristian Budinich: 8 compras, total $196100
  select id into v_cliente_id from public.clientes where nombre = 'Cristian Budinich' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 8 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 24512 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'directa', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Sra Sonia Pishuinco: 5 compras, total $192000
  select id into v_cliente_id from public.clientes where nombre = 'Sra Sonia Pishuinco' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 5 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 38400 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'directa', 30, 5, 'L',
          150, v_monto_por_compra / 5, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Kevin Santino: 4 compras, total $188020
  select id into v_cliente_id from public.clientes where nombre = 'Kevin Santino' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 4 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 47005 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'directa', 30, 7, 'L',
          210, v_monto_por_compra / 7, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Silos (ventas budis): 17 compras, total $187500
  select id into v_cliente_id from public.clientes where nombre = 'Silos (ventas budis)' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 17 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 11029 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'directa', 30, 1, 'L',
          30, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Maria Jose Silos: 9 compras, total $179875
  select id into v_cliente_id from public.clientes where nombre = 'Maria Jose Silos' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 9 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 19986 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'directa', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Pamela Pérez: 12 compras, total $177750
  select id into v_cliente_id from public.clientes where nombre = 'Pamela Pérez' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 12 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 14812 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Claudia Thomas: 8 compras, total $177625
  select id into v_cliente_id from public.clientes where nombre = 'Claudia Thomas' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 8 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 22203 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 2, 'L',
          60, v_monto_por_compra / 2, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Carolina Matamala: 7 compras, total $176300
  select id into v_cliente_id from public.clientes where nombre = 'Carolina Matamala' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 7 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 25185 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 3, 'L',
          90, v_monto_por_compra / 3, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- Frutería El Bosque: 5 compras, total $173740
  select id into v_cliente_id from public.clientes where nombre = 'Frutería El Bosque' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 5 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 34748 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'mayorista', 180, 1, 'L',
          180, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
  -- María Ines Díaz: 8 compras, total $157000
  select id into v_cliente_id from public.clientes where nombre = 'María Ines Díaz' limit 1;
  if v_cliente_id is not null then
    v_compras_por_mes := greatest(1, 8 / 9);
    foreach v_mes in array v_meses loop
      for i in 1..v_compras_por_mes loop
        v_dia := 1 + (random() * 27)::int;
        v_monto_por_compra := 19625 + (random() * 500 - 250)::int;
        insert into public.ventas (fecha, cliente_id, canal, tipo_bandeja, n_bandejas, tamano_huevo, n_huevos, precio_unitario, total, estado_pago, medio_pago) values (
          (v_mes || '-' || lpad(v_dia::text, 2, '0'))::date,
          v_cliente_id, 'suscripcion', 30, 1, 'L',
          30, v_monto_por_compra / 1, v_monto_por_compra,
          (case when random() < 0.85 then 'pagado' else 'pendiente' end),
          (array['transferencia','efectivo','debito'])[1+(random()*2.99)::int]
        );
      end loop;
    end loop;
  end if;
end $$;

-- ============== PRODUCCIÓN ÚLTIMOS 30 DÍAS (incluye HOY) ==============
do $$
declare
  v_l01 uuid; v_l02 uuid; v_l03 uuid;
begin
  select id into v_l01 from public.lotes where codigo='L01';
  select id into v_l02 from public.lotes where codigo='L02';
  select id into v_l03 from public.lotes where codigo='L03';
  for i in 0..29 loop
    insert into public.produccion_diaria (fecha, lote_id, huevos_enteros, huevos_rotos, mortalidades, observaciones) values
      (current_date - i, v_l01, 4 + (random()*3)::int, (random()*1)::int, 0, null),
      (current_date - i, v_l02, 235 + (random()*40)::int, 3 + (random()*5)::int, case when i=14 then 1 else 0 end, case when i=14 then 'Mortalidad lote viejo' else null end),
      (current_date - i, v_l03, 10 + (random()*15)::int, 1 + (random()*2)::int, 0, null);
  end loop;
end $$;

-- ============== ENTREGAS PRÓXIMAS para suscripciones activas ==============
do $$
declare
  r record;
  fecha_entrega date;
  dia_target int;
  dias_map jsonb := '{"Lunes":1,"Martes":2,"Miércoles":3,"Jueves":4,"Viernes":5,"Sábado":6,"Domingo":0}'::jsonb;
begin
  for r in select s.id, s.bandejas_mes, s.tamano_huevo, s.valor_mensual, s.dia_planificado, s.frecuencia from public.suscripciones s where estado='activa' loop
    dia_target := coalesce((dias_map ->> r.dia_planificado)::int, 1);
    fecha_entrega := current_date + ((7 + dia_target - extract(dow from current_date)::int) % 7);
    for i in 1..4 loop
      insert into public.entregas (suscripcion_id, fecha_planificada, n_bandejas, tamano_huevo, monto, estado, estado_pago) values
        (r.id, fecha_entrega, 1, r.tamano_huevo,
         case when r.frecuencia='semanal' then r.valor_mensual/4 else r.valor_mensual/2 end,
         'planificada', 'pendiente');
      fecha_entrega := fecha_entrega + case when r.frecuencia='semanal' then interval '7 days' else interval '14 days' end;
    end loop;
  end loop;
end $$;

-- ============== ALERTAS DE STOCK (semáforo activo) ==============
update public.insumos set stock_actual = 0 where nombre = 'Etiqueta envoltura bandeja 30';  -- rojo total
update public.insumos set stock_actual = 8 where nombre = 'Alimento inicial (saco 25kg)';  -- rojo
update public.insumos set stock_actual = 40 where nombre = 'Etiqueta grande (caja 12)';  -- amarillo

-- ============== VERIFICACIÓN ==============
select
  (select count(*) from public.ventas) as ventas,
  (select count(distinct cliente_id) from public.ventas) as clientes_con_ventas,
  (select sum(total) from public.ventas where estado_pago != 'anulado') as total_ventas,
  (select count(*) from public.entregas where fecha_planificada >= current_date) as entregas_proximas,
  (select sum(huevos_enteros) from public.produccion_diaria where fecha = current_date) as huevos_hoy,
  (select count(*) from public.produccion_diaria) as registros_produccion;
