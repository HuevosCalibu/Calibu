-- =====================================================================
-- CALIBÚ ERP — ROW LEVEL SECURITY (RLS)
-- =====================================================================
-- Lógica general:
--   - ADMIN: acceso total (lectura/escritura/borrado) a todas las tablas
--   - TRABAJADOR: solo puede ver/editar sus propios registros en RRHH,
--     y solo puede CARGAR producción diaria (no editar ni borrar histórico)
-- =====================================================================

-- Helper: ¿el usuario actual es admin?
create or replace function public.is_admin()
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and rol = 'admin' and activo = true
  );
$$;

-- Helper: empleado_id del usuario actual (si es trabajador)
create or replace function public.current_empleado_id()
returns uuid language sql security definer stable as $$
  select empleado_id from public.profiles where id = auth.uid();
$$;

-- ---------------------------------------------------------------------
-- profiles
-- ---------------------------------------------------------------------
create policy "profiles: usuario ve su propio profile"
  on public.profiles for select
  using (id = auth.uid() or public.is_admin());

create policy "profiles: admin gestiona profiles"
  on public.profiles for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------------------------------------------------------------------
-- empleados
-- ---------------------------------------------------------------------
create policy "empleados: admin gestiona todo"
  on public.empleados for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "empleados: trabajador ve sólo sus datos"
  on public.empleados for select
  using (id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- vacaciones
-- ---------------------------------------------------------------------
create policy "vacaciones: admin gestiona todo"
  on public.vacaciones for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "vacaciones: trabajador ve sus vacaciones"
  on public.vacaciones for select
  using (empleado_id = public.current_empleado_id());

create policy "vacaciones: trabajador solicita (insert)"
  on public.vacaciones for insert
  with check (
    empleado_id = public.current_empleado_id()
    and estado = 'solicitada'
  );

create policy "vacaciones: trabajador cancela su solicitud"
  on public.vacaciones for update
  using (empleado_id = public.current_empleado_id() and estado = 'solicitada')
  with check (empleado_id = public.current_empleado_id() and estado in ('solicitada','cancelada'));

-- ---------------------------------------------------------------------
-- anticipos — solo admin gestiona, trabajador lee los propios
-- ---------------------------------------------------------------------
create policy "anticipos: admin gestiona todo"
  on public.anticipos for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "anticipos: trabajador ve los suyos"
  on public.anticipos for select
  using (empleado_id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- liquidaciones — solo admin escribe, trabajador lee propias
-- ---------------------------------------------------------------------
create policy "liquidaciones: admin gestiona todo"
  on public.liquidaciones for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "liquidaciones: trabajador ve las suyas"
  on public.liquidaciones for select
  using (empleado_id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- finiquitos — solo admin
-- ---------------------------------------------------------------------
create policy "finiquitos: admin gestiona todo"
  on public.finiquitos for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "finiquitos: trabajador ve los suyos"
  on public.finiquitos for select
  using (empleado_id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- documentos_empleado
-- ---------------------------------------------------------------------
create policy "documentos: admin gestiona todo"
  on public.documentos_empleado for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "documentos: trabajador ve los suyos"
  on public.documentos_empleado for select
  using (empleado_id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- asistencia — trabajador marca su entrada/salida
-- ---------------------------------------------------------------------
create policy "asistencia: admin gestiona todo"
  on public.asistencia for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "asistencia: trabajador ve sus marcas"
  on public.asistencia for select
  using (empleado_id = public.current_empleado_id());

create policy "asistencia: trabajador inserta sus marcas"
  on public.asistencia for insert
  with check (empleado_id = public.current_empleado_id());

create policy "asistencia: trabajador actualiza sus marcas del día"
  on public.asistencia for update
  using (empleado_id = public.current_empleado_id() and fecha = current_date)
  with check (empleado_id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- evaluaciones_desempeno — solo admin
-- ---------------------------------------------------------------------
create policy "evaluaciones: admin gestiona todo"
  on public.evaluaciones_desempeno for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "evaluaciones: trabajador ve las suyas"
  on public.evaluaciones_desempeno for select
  using (empleado_id = public.current_empleado_id());

-- ---------------------------------------------------------------------
-- PRODUCCIÓN
-- ---------------------------------------------------------------------
-- galpones, lotes: solo admin gestiona; cualquier autenticado lee (para cargar producción)
create policy "galpones: admin gestiona"
  on public.galpones for all
  using (public.is_admin()) with check (public.is_admin());
create policy "galpones: autenticado lee"
  on public.galpones for select
  using (auth.uid() is not null);

create policy "lotes: admin gestiona"
  on public.lotes for all
  using (public.is_admin()) with check (public.is_admin());
create policy "lotes: autenticado lee"
  on public.lotes for select
  using (auth.uid() is not null);

-- produccion_diaria: cualquier autenticado puede insertar y leer, solo admin edita/borra
create policy "produccion: admin gestiona"
  on public.produccion_diaria for all
  using (public.is_admin()) with check (public.is_admin());
create policy "produccion: autenticado lee"
  on public.produccion_diaria for select
  using (auth.uid() is not null);
create policy "produccion: autenticado inserta"
  on public.produccion_diaria for insert
  with check (auth.uid() is not null);

-- ---------------------------------------------------------------------
-- VENTAS, CLIENTES, PLANES, SUSCRIPCIONES, ENTREGAS — solo admin por defecto
-- (cuando se cree el rol "vendedor" en el futuro se amplía aquí)
-- ---------------------------------------------------------------------
create policy "clientes: admin gestiona"  on public.clientes for all
  using (public.is_admin()) with check (public.is_admin());

create policy "planes: admin gestiona"  on public.planes for all
  using (public.is_admin()) with check (public.is_admin());
create policy "planes: autenticado lee" on public.planes for select
  using (auth.uid() is not null);

create policy "ventas: admin gestiona"  on public.ventas for all
  using (public.is_admin()) with check (public.is_admin());

create policy "suscripciones: admin gestiona" on public.suscripciones for all
  using (public.is_admin()) with check (public.is_admin());

create policy "entregas: admin gestiona" on public.entregas for all
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------
-- COMPRAS, INSUMOS, STOCK — solo admin
-- ---------------------------------------------------------------------
create policy "proveedores: admin gestiona" on public.proveedores for all
  using (public.is_admin()) with check (public.is_admin());

create policy "compras: admin gestiona" on public.compras for all
  using (public.is_admin()) with check (public.is_admin());

create policy "insumos: admin gestiona" on public.insumos for all
  using (public.is_admin()) with check (public.is_admin());
create policy "insumos: autenticado lee" on public.insumos for select
  using (auth.uid() is not null);

create policy "movs_stock: admin gestiona" on public.movimientos_stock for all
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------
-- MODELO FINANCIERO — solo admin
-- ---------------------------------------------------------------------
create policy "supuestos: admin gestiona" on public.supuestos_mensuales for all
  using (public.is_admin()) with check (public.is_admin());
create policy "ingresos_proy: admin gestiona" on public.ingresos_proyectados for all
  using (public.is_admin()) with check (public.is_admin());
create policy "costos: admin gestiona" on public.costos_mensuales for all
  using (public.is_admin()) with check (public.is_admin());
