-- =====================================================================
-- CALIBÚ ERP — Checklist operativo (tablas faltantes en schema)
-- Ejecutar en Supabase SQL Editor DESPUÉS de 01-schema.sql
-- =====================================================================

-- Plantilla de tareas del checklist
create table if not exists public.checklist_template (
  id      uuid primary key default gen_random_uuid(),
  orden   integer not null default 0,
  titulo  text not null,
  descripcion text,
  turno   text not null default 'cualquiera'
            check (turno in ('mañana','tarde','noche','cualquiera')),
  activo  boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_checklist_template_orden on public.checklist_template(orden);
create index if not exists idx_checklist_template_activo on public.checklist_template(activo);

-- Log diario de cumplimiento por empleado
create table if not exists public.checklist_log (
  id          uuid primary key default gen_random_uuid(),
  fecha       date not null default current_date,
  empleado_id uuid not null references public.empleados(id) on delete cascade,
  tarea_id    uuid not null references public.checklist_template(id) on delete cascade,
  completada  boolean not null default false,
  hora        timestamptz,
  notas       text,
  created_at  timestamptz not null default now(),
  unique (fecha, empleado_id, tarea_id)
);

create index if not exists idx_checklist_log_fecha       on public.checklist_log(fecha desc);
create index if not exists idx_checklist_log_empleado    on public.checklist_log(empleado_id);

-- RLS
alter table public.checklist_template enable row level security;
alter table public.checklist_log       enable row level security;

-- Admin: acceso total
create policy "admin_checklist_template_all" on public.checklist_template
  for all to authenticated
  using (
    exists (select 1 from public.profiles where id = auth.uid() and rol = 'admin')
  );

-- Trabajadora: solo lectura en template
create policy "trabajador_checklist_template_read" on public.checklist_template
  for select to authenticated
  using (activo = true);

-- Log: admin ve todo, trabajadora solo los suyos
create policy "admin_checklist_log_all" on public.checklist_log
  for all to authenticated
  using (
    exists (select 1 from public.profiles where id = auth.uid() and rol = 'admin')
  );

create policy "trabajador_checklist_log_own" on public.checklist_log
  for all to authenticated
  using  (empleado_id = public.current_empleado_id())
  with check (empleado_id = public.current_empleado_id());

-- =====================================================================
-- Datos semilla: 15 tareas operativas reales de Calibú
-- =====================================================================
insert into public.checklist_template (orden, titulo, descripcion, turno) values
  (1,  'Revisión estado general del galpón',        'Verificar temperatura, ventilación y estado de las aves', 'mañana'),
  (2,  'Recolección de huevos — Turno mañana',      'Recoger y clasificar huevos por tamaño y estado', 'mañana'),
  (3,  'Alimentación turno mañana',                 'Verificar comederos llenos y funcionando correctamente', 'mañana'),
  (4,  'Revisión bebederos y agua',                 'Asegurar agua limpia y flujo correcto en todos los bebederos', 'mañana'),
  (5,  'Conteo de mortalidades',                    'Registrar bajas y separar aves enfermas si las hay', 'mañana'),
  (6,  'Registro diario de producción',             'Ingresar huevos enteros, rotos y mortalidades en el sistema', 'mañana'),
  (7,  'Limpieza de pasillos',                      'Barrer y limpiar pasillo principal del galpón', 'mañana'),
  (8,  'Recolección de huevos — Turno tarde',       'Segunda recolección y clasificación del día', 'tarde'),
  (9,  'Alimentación turno tarde',                  'Completar comederos para la noche', 'tarde'),
  (10, 'Revisión sistema de luz artificial',        'Verificar que temporizadores y luminarias funcionen', 'tarde'),
  (11, 'Limpieza de huevos',                        'Limpiar y seleccionar huevos para despacho', 'tarde'),
  (12, 'Preparar pedidos del día siguiente',        'Revisar suscripciones y empacar bandejas pendientes', 'tarde'),
  (13, 'Revisión stock de alimento',                'Verificar nivel de sacos y avisar si queda menos de 3 días', 'tarde'),
  (14, 'Cierre y aseguramiento del galpón',         'Cerrar accesos, revisar malla antipájaros y seguro principal', 'tarde'),
  (15, 'Asistencia y novedad del día',              'Marcar asistencia y reportar cualquier novedad al administrador', 'cualquiera')
on conflict do nothing;
